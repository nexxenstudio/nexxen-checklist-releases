/**
 * Nexxen Checklist admin dashboard.
 *
 * A React app built on the copy of React WordPress already ships for the block
 * editor (wp.element). No bundler and no npm install: this file is plain ES5
 * calling createElement directly, so the plugin stays a drag-and-drop zip.
 *
 * The whole interface is bilingual. `lang` state drives both the UI strings and
 * the writing direction; in Hebrew the app container flips to RTL and checklist
 * items render their Hebrew titles.
 */
(function () {
	'use strict';

	var wpEl = window.wp && window.wp.element;
	if (!wpEl) { return; }

	var h = wpEl.createElement;
	var Fragment = wpEl.Fragment;
	var useState = wpEl.useState;
	var useEffect = wpEl.useEffect;
	var useCallback = wpEl.useCallback;

	var cfg = window.nexxenChecklist || {};
	var canManage = !!cfg.canManage;
	var mount = document.getElementById('nexxen-checklist-app');
	if (!mount) { return; }

	/* ------------------------------------------------------------------ */
	/* Language                                                            */
	/* ------------------------------------------------------------------ */

	var STRINGS = {
		en: {
			appName: 'Nexxen Checklist',
			tagline: 'Launch checklists',
			dashboard: 'Dashboard',
			checklists: 'Checklists',
			runs: 'Runs',
			loading: 'Loading…',
			notFound: 'Not found.',
			checklistsReady: 'Checklists ready to run',
			runsRecorded: 'Runs recorded',
			recentHistory: 'recent history',
			readyToRun: 'ready to run',
			readiness: 'Readiness',
			noCompletedRun: 'no completed run yet',
			lastReadiness: 'Last readiness',
			recentRuns: 'Recent runs',
			viewAll: 'View all',
			driftTitle: 'Site health drift',
			driftIntro: 'Re-checks indexing, SSL, debug output, robots, sitemap, caching, 404s and the Hebrew/RTL html attributes every week. No scan recorded yet.',
			scanNow: 'Scan now',
			rescan: 'Re-scan',
			allClear: 'All clear',
			issue: 'issue',
			issues: 'issues',
			lastScan: 'Last scan',
			restoreLibrary: 'Restore built-in library',
			newChecklist: '+ New checklist',
			startRun: 'Start run',
			startNewRun: 'Start a new run',
			activeItems: 'active items',
			auto: 'auto',
			builtIn: 'built-in',
			addItem: '+ Add item',
			back: 'Back',
			deleteLabel: 'Delete',
			noRuns: 'No runs yet. Open a checklist and press "Start run" — or let the agent run it over MCP.',
			colChecklist: 'Checklist',
			colLabel: 'Label',
			colProgress: 'Progress',
			colStatus: 'Status',
			colScore: 'Score',
			colStarted: 'Started',
			pass: 'Pass',
			fail: 'Fail',
			na: 'N/A',
			skip: 'Skip',
			skipped: 'Skipped',
			pending: 'Pending',
			inProgress: 'In progress',
			completed: 'Completed',
			ready: 'Ready',
			review: 'Review',
			notReady: 'Not ready',
			completeRun: 'Complete run',
			viewReport: 'View report',
			autoCheck: 'Auto-check',
			items: 'items',
			item: 'item',
			checkedBy: 'checked by',
			startedAt: 'started',
			by: 'by',
			engineScope: 'The engine can check %1$s of %2$s items here',
			engineStillPending: '%s still pending',
			engineAllDone: 'all done',
			engineRest: 'The rest need a browser or your judgement.',
			engineNone: 'No items on this checklist can be checked automatically — it is a visual checklist, so every item needs a browser or your judgement.',
			cancel: 'Cancel',
			create: 'Create',
			save: 'Save',
			name: 'Name',
			category: 'Category',
			description: 'Description',
			title: 'Title',
			titleHe: 'Title (Hebrew)',
			nameHe: 'Name (Hebrew)',
			newChecklistTitle: 'New checklist',
			section: 'Section',
			sectionHe: 'Section (Hebrew)',
			howToCheck: 'How to check (instructions for the agent)',
			severity: 'Severity',
			checkType: 'Check type',
			addItemTitle: 'Add item',
			editItem: 'Edit item',
			itemAdded: 'Item added',
			itemUpdated: 'Item updated',
			itemRemoved: 'Item removed',
			deleteItem: 'Delete item',
			deleteItemBody: 'Remove "%s" from this checklist?',
			deleteChecklist: 'Delete checklist',
			deleteChecklistBody: 'Delete "%s"? Runs already recorded are kept.',
			checklistDeleted: 'Checklist deleted',
			libraryRestored: 'Built-in library restored',
			checklistCreated: 'Checklist created',
			nameRequired: 'A name is required',
			titleRequired: 'A title is required',
			deleteRun: 'Delete run',
			deleteRunBody: 'Delete this run of "%s" and all its recorded results? This cannot be undone.',
			runDeleted: 'Run deleted',
			startRunTitle: 'Start run',
			labelField: 'Label',
			labelPlaceholder: 'e.g. Pre-launch %s (optional)',
			autoFirst: 'Run automatic checks first',
			autoFirstHelp: 'The engine settles the mechanical items (settings, SSL, sitemap, meta tags, Hebrew/RTL, legal pages…) in seconds; visual items stay open for review.',
			runStarted: 'Run started',
			runStartedAuto: 'Run started — running automatic checks…',
			runningChecks: 'Running automatic checks…',
			checksRecorded: 'Automatic checks recorded',
			runCompleted: 'Run completed',
			itemsPending: 'Items still pending',
			completeAnyway: 'Complete anyway',
			pendingSkipped: 'Pending items will be counted as skipped.',
			runReport: 'Run report',
			copyMarkdown: 'Copy Markdown',
			reportCopied: 'Report copied as Markdown',
			markFailed: 'Mark as failed',
			markFailedBtn: 'Mark failed',
			failNote: 'Note (stored with the result)',
			failPlaceholder: 'What failed, where, and what should happen instead?',
			itemEnabled: 'Item enabled',
			itemDisabled: 'Item disabled',
			enabledHint: 'Enabled — click to disable',
			disabledHint: 'Disabled — click to enable',
			autoHint: 'The engine can check this item automatically',
			somethingWrong: 'Something went wrong.',
			blocker: 'blocker',
			major: 'major',
			minor: 'minor',
			agent: 'agent',
			browser: 'browser',
			manual: 'manual',
			needsAttention: 'Needs attention',
			showAll: 'All items',
			assign: 'Assign',
			assignTitle: 'Assign item',
			assignPlaceholder: 'Name of the person responsible (empty to unassign)',
			assigned: 'Assignment saved',
			shareLink: 'Copy share link',
			linkCopied: 'Share link copied — anyone with it can read this report',
			exportBtn: 'Export',
			importBtn: 'Import',
			imported: 'Checklist imported',
			importInvalid: 'That file is not a checklist export',
			reports: 'Reports',
			noReports: 'No completed runs yet. Reports appear here as soon as a run is completed.',
			langName: 'English'
		},
		he: {
			appName: 'צ׳קליסט Nexxen',
			tagline: 'רשימות בדיקה להשקה',
			dashboard: 'לוח בקרה',
			checklists: 'רשימות בדיקה',
			runs: 'הרצות',
			loading: 'טוען…',
			notFound: 'לא נמצא.',
			checklistsReady: 'רשימות בדיקה מוכנות',
			runsRecorded: 'הרצות שנרשמו',
			recentHistory: 'היסטוריה אחרונה',
			readyToRun: 'מוכנות להרצה',
			readiness: 'מוכנות',
			noCompletedRun: 'טרם הושלמה הרצה',
			lastReadiness: 'מוכנות אחרונה',
			recentRuns: 'הרצות אחרונות',
			viewAll: 'הצג הכל',
			driftTitle: 'סטיית תקינות האתר',
			driftIntro: 'בודק מדי שבוע אינדוקס, SSL, שגיאות PHP, robots, מפת אתר, מטמון, עמודי 404 ותגיות עברית ו-RTL. טרם בוצעה סריקה.',
			scanNow: 'סרוק עכשיו',
			rescan: 'סרוק מחדש',
			allClear: 'הכל תקין',
			issue: 'תקלה',
			issues: 'תקלות',
			lastScan: 'סריקה אחרונה',
			restoreLibrary: 'שחזור הספרייה המובנית',
			newChecklist: '+ רשימה חדשה',
			startRun: 'התחל הרצה',
			startNewRun: 'התחל הרצה חדשה',
			activeItems: 'פריטים פעילים',
			auto: 'אוטומטי',
			builtIn: 'מובנה',
			addItem: '+ הוסף פריט',
			back: 'חזרה',
			deleteLabel: 'מחק',
			noRuns: 'עדיין אין הרצות. פתחו רשימת בדיקה ולחצו "התחל הרצה" — או תנו לסוכן להריץ אותה דרך MCP.',
			colChecklist: 'רשימת בדיקה',
			colLabel: 'תווית',
			colProgress: 'התקדמות',
			colStatus: 'סטטוס',
			colScore: 'ציון',
			colStarted: 'התחלה',
			pass: 'עבר',
			fail: 'נכשל',
			na: 'לא רלוונטי',
			skip: 'דלג',
			skipped: 'דולג',
			pending: 'ממתין',
			inProgress: 'בתהליך',
			completed: 'הושלם',
			ready: 'מוכן',
			review: 'לבדיקה',
			notReady: 'לא מוכן',
			completeRun: 'סיים הרצה',
			viewReport: 'הצג דוח',
			autoCheck: 'בדיקה אוטומטית',
			items: 'פריטים',
			item: 'פריט',
			checkedBy: 'נבדק על ידי',
			startedAt: 'התחיל',
			by: 'על ידי',
			engineScope: 'המנוע יכול לבדוק %1$s מתוך %2$s פריטים כאן',
			engineStillPending: '%s עדיין ממתינים',
			engineAllDone: 'הכל הושלם',
			engineRest: 'השאר דורשים דפדפן או שיקול דעת שלכם.',
			engineNone: 'אף פריט ברשימה זו אינו ניתן לבדיקה אוטומטית — זו רשימה חזותית, וכל פריט דורש דפדפן או שיקול דעת שלכם.',
			cancel: 'ביטול',
			create: 'צור',
			save: 'שמור',
			name: 'שם',
			category: 'קטגוריה',
			description: 'תיאור',
			title: 'כותרת',
			titleHe: 'כותרת (עברית)',
			nameHe: 'שם (עברית)',
			newChecklistTitle: 'רשימת בדיקה חדשה',
			section: 'מקטע',
			sectionHe: 'מקטע (עברית)',
			howToCheck: 'איך לבדוק (הוראות לסוכן)',
			severity: 'חומרה',
			checkType: 'סוג בדיקה',
			addItemTitle: 'הוספת פריט',
			editItem: 'עריכת פריט',
			itemAdded: 'הפריט נוסף',
			itemUpdated: 'הפריט עודכן',
			itemRemoved: 'הפריט הוסר',
			deleteItem: 'מחיקת פריט',
			deleteItemBody: 'להסיר את "%s" מרשימה זו?',
			deleteChecklist: 'מחיקת רשימה',
			deleteChecklistBody: 'למחוק את "%s"? הרצות שכבר נרשמו יישמרו.',
			checklistDeleted: 'הרשימה נמחקה',
			libraryRestored: 'הספרייה המובנית שוחזרה',
			checklistCreated: 'הרשימה נוצרה',
			nameRequired: 'חובה להזין שם',
			titleRequired: 'חובה להזין כותרת',
			deleteRun: 'מחיקת הרצה',
			deleteRunBody: 'למחוק את ההרצה של "%s" ואת כל התוצאות שנרשמו? לא ניתן לבטל פעולה זו.',
			runDeleted: 'ההרצה נמחקה',
			startRunTitle: 'התחלת הרצה',
			labelField: 'תווית',
			labelPlaceholder: 'לדוגמה: לפני השקה %s (אופציונלי)',
			autoFirst: 'הרץ קודם בדיקות אוטומטיות',
			autoFirstHelp: 'המנוע מסדיר בשניות את הפריטים המכניים (הגדרות, SSL, מפת אתר, תגיות מטא, עברית ו-RTL, עמודי חוק…); הפריטים החזותיים נשארים פתוחים לבדיקה.',
			runStarted: 'ההרצה החלה',
			runStartedAuto: 'ההרצה החלה — מריץ בדיקות אוטומטיות…',
			runningChecks: 'מריץ בדיקות אוטומטיות…',
			checksRecorded: 'הבדיקות האוטומטיות נרשמו',
			runCompleted: 'ההרצה הושלמה',
			itemsPending: 'פריטים עדיין ממתינים',
			completeAnyway: 'סיים בכל זאת',
			pendingSkipped: 'פריטים ממתינים ייחשבו כדולגו.',
			runReport: 'דוח הרצה',
			copyMarkdown: 'העתק כ-Markdown',
			reportCopied: 'הדוח הועתק כ-Markdown',
			markFailed: 'סימון ככישלון',
			markFailedBtn: 'סמן כנכשל',
			failNote: 'הערה (נשמרת עם התוצאה)',
			failPlaceholder: 'מה נכשל, היכן, ומה אמור לקרות במקום?',
			itemEnabled: 'הפריט הופעל',
			itemDisabled: 'הפריט בוטל',
			enabledHint: 'פעיל — לחצו כדי לבטל',
			disabledHint: 'מבוטל — לחצו כדי להפעיל',
			autoHint: 'המנוע יכול לבדוק פריט זה אוטומטית',
			somethingWrong: 'משהו השתבש.',
			blocker: 'חוסם',
			major: 'משמעותי',
			minor: 'קל',
			agent: 'סוכן',
			browser: 'דפדפן',
			manual: 'ידני',
			needsAttention: 'דורש טיפול',
			showAll: 'כל הפריטים',
			assign: 'שיוך',
			assignTitle: 'שיוך פריט',
			assignPlaceholder: 'שם האחראי (ריק לביטול השיוך)',
			assigned: 'השיוך נשמר',
			shareLink: 'העתק קישור לדוח',
			linkCopied: 'הקישור הועתק — כל מי שמחזיק בו יכול לקרוא את הדוח',
			exportBtn: 'ייצוא',
			importBtn: 'ייבוא',
			imported: 'הרשימה יובאה',
			importInvalid: 'הקובץ אינו ייצוא של רשימת בדיקה',
			reports: 'דוחות',
			noReports: 'אין עדיין הרצות שהושלמו. דוחות יופיעו כאן ברגע שהרצה תושלם.',
			langName: 'עברית'
		}
	};

	var LANG_KEY = 'nexxenChecklistLang';

	function initialLang() {
		try {
			var stored = window.localStorage.getItem(LANG_KEY);
			if (stored === 'he' || stored === 'en') { return stored; }
		} catch (e) { /* private mode */ }
		// English by default everywhere; Hebrew is a per-person choice that sticks.
		return 'en';
	}

	function makeT(lang) {
		var dict = STRINGS[lang] || STRINGS.en;
		return function (key) {
			var text = dict[key] !== undefined ? dict[key] : (STRINGS.en[key] !== undefined ? STRINGS.en[key] : key);
			var args = Array.prototype.slice.call(arguments, 1);
			if (!args.length) { return text; }
			// Supports both %s (in order) and %1$s positional placeholders.
			var index = 0;
			return text.replace(/%(\d+\$)?s/g, function (match, position) {
				if (position) { return String(args[parseInt(position, 10) - 1]); }
				return String(args[index++]);
			});
		};
	}

	/* ------------------------------------------------------------------ */
	/* API + toasts                                                        */
	/* ------------------------------------------------------------------ */

	function api(path, body, method) {
		var opts = {
			method: method || (body ? 'POST' : 'GET'),
			headers: { 'X-WP-Nonce': cfg.nonce, 'Content-Type': 'application/json' },
			credentials: 'same-origin'
		};
		if (body) { opts.body = JSON.stringify(body); }
		return fetch(cfg.restUrl + '/' + path, opts).then(function (res) {
			return res.json().catch(function () {
				return { success: false, status: 'bad-json', data: { message: 'Invalid server response (HTTP ' + res.status + ')' } };
			});
		}).then(function (out) {
			if (out && out.success === false) { throw out; }
			return out;
		});
	}

	function toast(message, kind) {
		var el = document.createElement('div');
		el.className = 'nxnc-toast ' + (kind || 'ok');
		el.textContent = message;
		document.body.appendChild(el);
		setTimeout(function () { el.classList.add('show'); }, 20);
		setTimeout(function () {
			el.classList.remove('show');
			setTimeout(function () { el.remove(); }, 300);
		}, 3500);
	}

	/* ------------------------------------------------------------------ */
	/* Small presentational pieces                                         */
	/* ------------------------------------------------------------------ */

	function fmtDate(mysql) {
		if (!mysql) { return ''; }
		return mysql.replace(/:\d{2}$/, '') + ' UTC';
	}

	/**
	 * Hebrew title when the interface is Hebrew and one exists, English
	 * otherwise. Falls back rather than showing an empty row.
	 */
	function localized(entity, field, lang) {
		if (!entity) { return ''; }
		if (lang === 'he' && entity[field + '_he']) { return entity[field + '_he']; }
		return entity[field] || '';
	}

	function Chip(props) {
		return h('span', { className: 'nxnc-chip ' + (props.kind || ''), title: props.title || null }, props.children);
	}

	function StatusChip(props) {
		var t = props.t;
		var labels = {
			pass: t('pass'), fail: t('fail'), na: t('na'), skipped: t('skipped'),
			pending: t('pending'), 'in-progress': t('inProgress'), completed: t('completed')
		};
		return h('span', { className: 'nxnc-chip st-' + props.status }, labels[props.status] || props.status);
	}

	function SeverityChip(props) {
		return h('span', { className: 'nxnc-chip sev-' + props.severity }, props.t(props.severity));
	}

	function Ring(props) {
		return h('div', { className: 'nxnc-ring', style: { '--p': props.percent } },
			h('div', { className: 'nxnc-ring-inner' },
				h('strong', null, String(props.percent) + '%'),
				props.label ? h('span', null, props.label) : null
			)
		);
	}

	function Bar(props) {
		return h('div', { className: 'nxnc-bar' + (props.big ? ' big' : '') },
			h('div', { className: 'nxnc-bar-fill', style: { transform: 'scaleX(' + ((props.percent || 0) / 100) + ')' } })
		);
	}

	function verdictLabel(verdict, t) {
		return { ready: t('ready'), review: t('review'), 'not-ready': t('notReady') }[verdict] || verdict || '';
	}

	/* ------------------------------------------------------------------ */
	/* Modal                                                               */
	/* ------------------------------------------------------------------ */

	function Modal(props) {
		useEffect(function () {
			function onKey(event) { if (event.key === 'Escape') { props.onClose(); } }
			document.addEventListener('keydown', onKey);
			return function () { document.removeEventListener('keydown', onKey); };
		}, [props.onClose]);

		return h('div', {
			className: 'nxnc-overlay',
			onClick: function (event) { if (event.target === event.currentTarget) { props.onClose(); } }
		},
			h('div', { className: 'nxnc-modal' + (props.wide ? ' wide' : '') },
				h('div', { className: 'nxnc-modal-head' },
					h('h3', null, props.title),
					h('button', { className: 'nxnc-x', onClick: props.onClose, 'aria-label': 'Close' }, '×')
				),
				h('div', { className: 'nxnc-modal-body' }, props.children),
				h('div', { className: 'nxnc-modal-foot' }, props.actions)
			)
		);
	}

	function Field(props) {
		return h('label', { className: 'nxnc-field' },
			h('span', null, props.label),
			props.children
		);
	}

	/* ------------------------------------------------------------------ */
	/* Header                                                              */
	/* ------------------------------------------------------------------ */

	function Header(props) {
		var t = props.t;
		function tab(id, label, matches) {
			var active = matches.indexOf(props.view) !== -1;
			return h('button', {
				className: 'nxnc-tab' + (active ? ' active' : ''),
				onClick: function () { props.onNavigate(id); }
			}, label);
		}

		return h('header', { className: 'nxnc-header' },
			h('div', { className: 'nxnc-brand' },
				h('div', { className: 'nxnc-mark', 'aria-hidden': 'true' },
					h('svg', { viewBox: '0 0 24 24', width: '20', height: '20' },
						h('path', {
							d: 'M4 12.5 9.5 18 20 6.5',
							fill: 'none',
							stroke: 'currentColor',
							strokeWidth: '3',
							strokeLinecap: 'round',
							strokeLinejoin: 'round'
						})
					)
				),
				h('div', { className: 'nxnc-brand-title' },
					h('div', { className: 'nxnc-title' }, t('appName')),
					h('p', null, t('tagline') + ' \u00b7 ' + String(cfg.site || '').replace(/^https?:\/\//, ''))
				)
			),
			h('nav', { className: 'nxnc-tabs' },
				tab('dashboard', t('dashboard'), ['dashboard']),
				tab('checklists', t('checklists'), ['checklists', 'checklist']),
				tab('runs', t('runs'), ['runs', 'run']),
				tab('reports', t('reports'), ['reports'])
			),
			h('div', { className: 'nxnc-header-side' },
				h('div', { className: 'nxnc-lang' },
					h('button', {
						className: 'nxnc-lang-btn' + (props.lang === 'en' ? ' on' : ''),
						onClick: function () { props.onLang('en'); }
					}, 'EN'),
					h('button', {
						className: 'nxnc-lang-btn' + (props.lang === 'he' ? ' on' : ''),
						onClick: function () { props.onLang('he'); }
					}, '\u05e2\u05d1')
				),
				h('span', { className: 'nxnc-version' }, 'v' + (cfg.version || ''))
			)
		);
	}

	/* ------------------------------------------------------------------ */
	/* Dashboard                                                           */
	/* ------------------------------------------------------------------ */

	function StatCard(props) {
		return h('div', {
			className: 'nxnc-card' + (props.onClick ? ' clickable' : ''),
			onClick: props.onClick || null
		},
			h('span', { className: 'nxnc-card-title' }, props.title),
			props.children ? props.children : h('strong', { className: 'nxnc-card-big' }, props.big),
			props.sub ? h('span', { className: 'nxnc-card-sub' }, props.sub) : null
		);
	}

	function DriftPanel(props) {
		var t = props.t;
		var drift = props.drift;

		var scanButton = h('button', {
			className: 'nxnc-btn',
			onClick: function () {
				toast(t('runningChecks'));
				api('drift/run', {}).then(props.onScanned).catch(props.onError);
			}
		}, drift ? t('rescan') : t('scanNow'));

		if (!drift) {
			return h('div', { className: 'nxnc-panel nxnc-drift' },
				h('div', { className: 'nxnc-panel-head' },
					h('div', null,
						h('h2', null, t('driftTitle')),
						h('p', { className: 'nxnc-muted' }, t('driftIntro'))
					),
					scanButton
				)
			);
		}

		var failures = drift.failures || [];
		return h('div', { className: 'nxnc-panel nxnc-drift' + (failures.length ? ' has-fails' : '') },
			h('div', { className: 'nxnc-panel-head' },
				h('div', null,
					h('h2', null,
						t('driftTitle'), ' ',
						failures.length
							? h('span', { className: 'nxnc-chip st-fail' }, failures.length + ' ' + (failures.length > 1 ? t('issues') : t('issue')))
							: h('span', { className: 'nxnc-chip st-pass' }, t('allClear'))
					),
					h('p', { className: 'nxnc-muted' }, t('lastScan') + ': ' + fmtDate(drift.scanned_at) + ' (' + (drift.trigger || 'manual') + ')')
				),
				scanButton
			),
			failures.map(function (failure) {
				return h('div', { className: 'nxnc-drift-row', key: failure.item_id },
					h('span', { className: 'nxnc-chip st-fail' }, t('fail')),
					h('span', null, failure.notes || failure.item_id)
				);
			})
		);
	}

	function RunTable(props) {
		var t = props.t;
		if (!props.runs || !props.runs.length) {
			return h('div', { className: 'nxnc-empty' }, t('noRuns'));
		}
		// Wrapped so a 7-column table scrolls inside the panel instead of
		// pushing the whole admin page sideways on narrow screens.
		return h('div', { className: 'nxnc-table-scroll' },
			h('table', { className: 'nxnc-table' },
				h('thead', null,
					h('tr', null,
						h('th', null, t('colChecklist')),
						h('th', null, t('colLabel')),
						h('th', null, t('colProgress')),
						h('th', null, t('colStatus')),
						h('th', null, t('colScore')),
						h('th', null, t('colStarted')),
						h('th', null, '')
					)
				),
				h('tbody', null, props.runs.map(function (run) {
					var progress = run.progress || { percent: 0, done: 0, total: 0 };
					var score = run.summary && run.summary.readiness_score !== undefined
						? run.summary.readiness_score + ' · ' + verdictLabel(run.summary.verdict, t)
						: '—';
					return h('tr', { key: run.run_id, onClick: function () { props.onOpen(run.run_id); } },
						h('td', null, h('strong', null, run.checklist_name)),
						h('td', null, run.label || '—'),
						h('td', null,
							h(Bar, { percent: progress.percent }),
							h('span', { className: 'nxnc-muted small' }, progress.done + '/' + progress.total)
						),
						h('td', null, h(StatusChip, { status: run.status, t: t })),
						h('td', null, score),
						h('td', null, fmtDate(run.started_at)),
						h('td', null, canManage ? h('button', {
							className: 'nxnc-btn danger small',
							onClick: function (event) {
								event.stopPropagation();
								props.onDelete(run);
							}
						}, t('deleteLabel')) : null)
					);
				}))
			)
		);
	}

	function Dashboard(props) {
		var t = props.t;
		var ov = props.overview || {};
		var last = ov.last_completed;

		var readinessCard = (last && last.summary && last.summary.readiness_score !== undefined)
			? h(StatCard, {
				title: t('lastReadiness') + ' — ' + last.name,
				onClick: function () { props.onOpenRun(last.run_id); }
			}, h(Ring, { percent: last.summary.readiness_score, label: verdictLabel(last.summary.verdict, t) }))
			: h(StatCard, { title: t('readiness'), big: '—', sub: t('noCompletedRun') });

		return h(Fragment, null,
			h('div', { className: 'nxnc-cards' },
				h(StatCard, {
					title: t('checklists'),
					big: String(ov.checklist_count || 0),
					sub: t('readyToRun'),
					onClick: function () { props.onNavigate('checklists'); }
				}),
				h(StatCard, {
					title: t('runsRecorded'),
					big: String((ov.recent_runs || []).length),
					sub: t('recentHistory'),
					onClick: function () { props.onNavigate('runs'); }
				}),
				readinessCard
			),
			h(DriftPanel, { t: t, drift: ov.drift, onScanned: props.onRefresh, onError: props.onError }),
			h('div', { className: 'nxnc-panel' },
				h('div', { className: 'nxnc-panel-head' },
					h('h2', null, t('recentRuns')),
					h('button', { className: 'nxnc-btn', onClick: function () { props.onNavigate('runs'); } }, t('viewAll'))
				),
				h(RunTable, {
					t: t,
					runs: (ov.recent_runs || []).slice(0, 5),
					onOpen: props.onOpenRun,
					onDelete: props.onDeleteRun
				})
			)
		);
	}

	/* ------------------------------------------------------------------ */
	/* Checklists                                                          */
	/* ------------------------------------------------------------------ */

	function ChecklistGrid(props) {
		var t = props.t;
		return h('div', { className: 'nxnc-panel' },
			h('div', { className: 'nxnc-panel-head' },
				h('h2', null, t('checklists')),
				h('div', { className: 'nxnc-actions' },
					canManage ? h('button', { className: 'nxnc-btn', onClick: props.onRestore }, t('restoreLibrary')) : null,
					canManage ? h('button', { className: 'nxnc-btn', onClick: props.onImport }, t('importBtn')) : null,
					canManage ? h('button', { className: 'nxnc-btn primary', onClick: props.onNew }, t('newChecklist')) : null
				)
			),
			h('div', { className: 'nxnc-grid' }, props.checklists.map(function (checklist) {
				return h('div', {
					className: 'nxnc-list-card',
					key: checklist.slug,
					onClick: function () { props.onOpen(checklist.slug); }
				},
					h('div', { className: 'nxnc-list-card-top' },
						h(Chip, { kind: 'cat' }, checklist.category),
						checklist.source === 'builtin' ? h(Chip, { kind: 'src' }, t('builtIn')) : null
					),
					h('h3', null, localized(checklist, 'name', props.lang)),
					h('p', null, checklist.description || ''),
					h('div', { className: 'nxnc-list-card-foot' },
						h('span', null, checklist.enabled_count + ' ' + t('activeItems') + (checklist.auto_count ? ' · ' + checklist.auto_count + ' ' + t('auto') : '')),
						h('span', { className: 'nxnc-actions' },
							h('button', {
								className: 'nxnc-btn small',
								onClick: function (event) {
									event.stopPropagation();
									props.onExport(checklist.slug);
								}
							}, t('exportBtn')),
							h('button', {
								className: 'nxnc-btn small',
								onClick: function (event) {
									event.stopPropagation();
									props.onStartRun(checklist.slug);
								}
							}, t('startRun'))
						)
					)
				);
			}))
		);
	}

	function groupBySection(entries, lang) {
		var order = [];
		var groups = {};
		entries.forEach(function (entry) {
			var label = (lang === 'he' && entry.section_he) ? entry.section_he : (entry.section || 'General');
			if (!groups[label]) { groups[label] = []; order.push(label); }
			groups[label].push(entry);
		});
		return order.map(function (label) { return { label: label, entries: groups[label] }; });
	}

	function ChecklistEditor(props) {
		var t = props.t;
		var checklist = props.checklist;
		if (!checklist) { return h('div', { className: 'nxnc-panel' }, t('notFound')); }

		return h('div', { className: 'nxnc-panel' },
			h('div', { className: 'nxnc-panel-head' },
				h('div', null,
					h('button', { className: 'nxnc-back', onClick: function () { props.onNavigate('checklists'); } }, '← ' + t('checklists')),
					h('h2', null, localized(checklist, 'name', props.lang)),
					h('p', { className: 'nxnc-muted' }, checklist.description || '')
				),
				h('div', { className: 'nxnc-actions' },
					canManage ? h('button', { className: 'nxnc-btn', onClick: function () { props.onEditItem(null); } }, t('addItem')) : null,
					h('button', { className: 'nxnc-btn primary', onClick: function () { props.onStartRun(checklist.slug); } }, t('startRun')),
					canManage && checklist.source !== 'builtin'
						? h('button', { className: 'nxnc-btn danger', onClick: props.onDelete }, t('deleteLabel'))
						: null
				)
			),
			groupBySection(checklist.items, props.lang).map(function (group) {
				return h('div', { className: 'nxnc-section', key: group.label },
					h('h3', null, group.label, h('span', { className: 'nxnc-count' }, String(group.entries.length))),
					group.entries.map(function (item) {
						return h('div', { className: 'nxnc-item' + (item.enabled ? '' : ' disabled'), key: item.id },
							canManage ? h('label', {
								className: 'nxnc-switch',
								title: item.enabled ? t('enabledHint') : t('disabledHint')
							},
								h('input', {
									type: 'checkbox',
									checked: !!item.enabled,
									onChange: function (event) { props.onToggleItem(item, event.target.checked); }
								}),
								h('span', { className: 'nxnc-slider' })
							) : null,
							h('div', {
								className: 'nxnc-item-body' + (canManage ? ' clickable' : ''),
								onClick: canManage ? function () { props.onEditItem(item); } : null
							},
								h('strong', null, localized(item, 'title', props.lang)),
								item.how_to_check ? h('p', null, item.how_to_check) : null
							),
							h('div', { className: 'nxnc-item-meta' },
								props.autoIds.indexOf(item.id) !== -1 ? h(Chip, { kind: 'auto', title: t('autoHint') }, t('auto')) : null,
								h(SeverityChip, { severity: item.severity, t: t }),
								h(Chip, { kind: 'type' }, t(item.check_type))
							)
						);
					})
				);
			})
		);
	}

	/* ------------------------------------------------------------------ */
	/* Run view                                                            */
	/* ------------------------------------------------------------------ */

	function RunItemRow(props) {
		var t = props.t;
		var result = props.result;
		var editable = props.editable;

		function pill(status, label) {
			return h('button', {
				className: 'nxnc-pill' + (result.status === status ? ' on st-' + status : ''),
				onClick: function () { props.onSetStatus(result, status); }
			}, label);
		}

		return h('div', { className: 'nxnc-item run st-border-' + result.status },
			h('div', { className: 'nxnc-item-body' },
				h('strong', null,
					localized(result, 'title', props.lang) || result.item_id, ' ',
					result.severity ? h(SeverityChip, { severity: result.severity, t: t }) : null,
					props.autoIds.indexOf(result.item_id) !== -1 ? h(Chip, { kind: 'auto', title: t('autoHint') }, t('auto')) : null
				),
				result.notes ? h('p', { className: 'nxnc-note' }, result.notes) : null,
				result.evidence ? h('p', { className: 'nxnc-evidence' }, result.evidence) : null,
				result.checked_by
					? h('p', { className: 'nxnc-muted small' }, t('checkedBy') + ' ' + result.checked_by + ' · ' + fmtDate(result.checked_at))
					: null
			),
			h('div', { className: 'nxnc-item-actions' }, editable
				? [
					h(Fragment, { key: 'pills' },
						pill('pass', '✓ ' + t('pass')),
						pill('fail', '✕ ' + t('fail')),
						pill('na', t('na')),
						pill('skipped', t('skip'))
					)
				]
				: h(StatusChip, { status: result.status, t: t })
			)
		);
	}

	function RunView(props) {
		var t = props.t;
		var run = props.run;
		var filterState = useState('all');
		var filter = filterState[0];
		var setFilter = filterState[1];
		if (!run) { return h('div', { className: 'nxnc-panel' }, t('notFound')); }
		var visible = (run.results || []).filter(function (result) {
			return filter === 'all' || result.status === 'fail' || result.status === 'pending';
		});
		var attentionCount = (run.results || []).filter(function (result) {
			return result.status === 'fail' || result.status === 'pending';
		}).length;

		var progress = run.progress || { percent: 0, counts: {}, total: 0 };
		var counts = progress.counts || {};
		var autoTotal = props.autoIds.length;

		var scopeText;
		if (autoTotal) {
			scopeText = t('engineScope', autoTotal, progress.total)
				+ ' (' + (props.autoPending ? t('engineStillPending', props.autoPending) : t('engineAllDone')) + '). '
				+ t('engineRest');
		} else {
			scopeText = t('engineNone');
		}

		return h('div', { className: 'nxnc-panel' },
			h('div', { className: 'nxnc-panel-head' },
				h('div', null,
					h('button', { className: 'nxnc-back', onClick: function () { props.onNavigate('runs'); } }, '← ' + t('runs')),
					h('h2', null, run.checklist_name, ' ', h(StatusChip, { status: run.status, t: t })),
					h('p', { className: 'nxnc-muted' },
						(run.label ? run.label + ' · ' : '') + t('startedAt') + ' ' + fmtDate(run.started_at)
						+ (run.created_by ? ' ' + t('by') + ' ' + run.created_by : '')
					)
				),
				h('div', { className: 'nxnc-actions' },
					h('span', { className: 'nxnc-mini-counts' },
						h('b', { className: 'c-pass' }, String(counts.pass || 0)), ' ' + t('pass') + ' · ',
						h('b', { className: 'c-fail' }, String(counts.fail || 0)), ' ' + t('fail') + ' · ',
						h('b', null, String(counts.pending || 0)), ' ' + t('pending')
					),
					(run.status === 'in-progress' && props.autoPending > 0)
						? h('button', { className: 'nxnc-btn', onClick: props.onAutoCheck },
							t('autoCheck') + ' ' + props.autoPending + ' ' + (props.autoPending > 1 ? t('items') : t('item')))
						: null,
					run.status === 'completed'
						? h('button', { className: 'nxnc-btn', onClick: props.onShare }, t('shareLink'))
						: null,
					run.status === 'in-progress'
						? h('button', { className: 'nxnc-btn primary', onClick: props.onComplete }, t('completeRun'))
						: h('button', { className: 'nxnc-btn primary', onClick: props.onReport }, t('viewReport'))
				)
			),
			h(Bar, { percent: progress.percent, big: true }),
			h('div', { className: 'nxnc-filter' },
				h('button', { className: 'nxnc-pill' + (filter === 'all' ? ' on st-pending' : ''), onClick: function () { setFilter('all'); } }, t('showAll') + ' · ' + (run.results || []).length),
				h('button', { className: 'nxnc-pill' + (filter === 'attention' ? ' on st-fail' : ''), onClick: function () { setFilter('attention'); } }, t('needsAttention') + ' · ' + attentionCount)
			),
			h('p', { className: 'nxnc-scope' }, scopeText),
			groupBySection(visible, props.lang).map(function (group) {
				return h('div', { className: 'nxnc-section', key: group.label },
					h('h3', null, group.label),
					group.entries.map(function (result) {
						return h(RunItemRow, {
							key: result.item_id,
							t: t,
							lang: props.lang,
							result: result,
							editable: run.status === 'in-progress',
							autoIds: props.autoIds,
							onSetStatus: props.onSetStatus,
							onAssign: props.onAssign
						});
					})
				);
			})
		);
	}

	function ReportsView(props) {
		var t = props.t;
		var completed = (props.runs || []).filter(function (run) { return run.status === 'completed'; });
		return h('div', { className: 'nxnc-panel' },
			h('div', { className: 'nxnc-panel-head' },
				h('h2', null, t('reports'))
			),
			completed.length
				? completed.map(function (run) {
					var summary = run.summary || {};
					return h('div', { className: 'nxnc-report-row', key: run.run_id, onClick: function () { props.onOpenRun(run.run_id); } },
						h('div', { className: 'nxnc-report-score sc-' + (summary.verdict || 'none') },
							summary.readiness_score !== undefined ? String(summary.readiness_score) : '—'
						),
						h('div', { className: 'nxnc-report-main' },
							h('strong', null, run.checklist_name),
							h('span', { className: 'nxnc-muted small' },
								(run.label ? run.label + ' · ' : '') + fmtDate(run.completed_at || run.started_at)
								+ (summary.verdict ? ' · ' + verdictLabel(summary.verdict, t) : '')
							)
						),
						h('div', { className: 'nxnc-actions' },
							h('button', {
								className: 'nxnc-btn small',
								onClick: function (event) { event.stopPropagation(); props.onShareRun(run.run_id); }
							}, t('shareLink')),
							h('button', {
								className: 'nxnc-btn small primary',
								onClick: function (event) { event.stopPropagation(); props.onShowReport(run.run_id); }
							}, t('viewReport'))
						)
					);
				})
				: h('div', { className: 'nxnc-empty' }, t('noReports'))
		);
	}

	/* ------------------------------------------------------------------ */
	/* Modals as components                                                */
	/* ------------------------------------------------------------------ */

	function ConfirmModal(props) {
		var t = props.t;
		return h(Modal, {
			title: props.title,
			onClose: props.onClose,
			actions: [
				h('button', { className: 'nxnc-btn', key: 'cancel', onClick: props.onClose }, t('cancel')),
				h('button', {
					className: 'nxnc-btn ' + (props.danger ? 'danger-solid' : 'primary'),
					key: 'ok',
					onClick: function () { props.onClose(); props.onConfirm(); }
				}, props.confirmLabel)
			]
		}, h('p', { className: 'nxnc-modal-text' }, props.message));
	}

	function NewChecklistModal(props) {
		var t = props.t;
		var state = useState({ name: '', name_he: '', category: '', description: '' });
		var values = state[0];
		var setValues = state[1];

		function set(key) {
			return function (event) {
				var next = {};
				next[key] = event.target.value;
				setValues(Object.assign({}, values, next));
			};
		}

		return h(Modal, {
			title: t('newChecklistTitle'),
			onClose: props.onClose,
			actions: [
				h('button', { className: 'nxnc-btn', key: 'cancel', onClick: props.onClose }, t('cancel')),
				h('button', {
					className: 'nxnc-btn primary',
					key: 'create',
					onClick: function () {
						if (!values.name.trim()) { toast(t('nameRequired'), 'err'); return; }
						props.onCreate(values);
					}
				}, t('create'))
			]
		},
			h(Field, { label: t('name') }, h('input', { type: 'text', value: values.name, onChange: set('name') })),
			h(Field, { label: t('nameHe') }, h('input', { type: 'text', dir: 'rtl', value: values.name_he, onChange: set('name_he') })),
			h(Field, { label: t('category') }, h('input', { type: 'text', value: values.category, onChange: set('category') })),
			h(Field, { label: t('description') }, h('textarea', { rows: 3, value: values.description, onChange: set('description') }))
		);
	}

	function ItemModal(props) {
		var t = props.t;
		var item = props.item || {};
		var isNew = !props.item;
		var state = useState({
			title: item.title || '',
			title_he: item.title_he || '',
			section: item.section || 'General',
			section_he: item.section_he || '',
			how_to_check: item.how_to_check || '',
			severity: item.severity || 'major',
			check_type: item.check_type || 'agent'
		});
		var values = state[0];
		var setValues = state[1];

		function set(key) {
			return function (event) {
				var next = {};
				next[key] = event.target.value;
				setValues(Object.assign({}, values, next));
			};
		}

		var actions = [
			h('button', { className: 'nxnc-btn', key: 'cancel', onClick: props.onClose }, t('cancel')),
			h('button', {
				className: 'nxnc-btn primary',
				key: 'save',
				onClick: function () {
					if (!values.title.trim()) { toast(t('titleRequired'), 'err'); return; }
					props.onSave(values, isNew, item);
				}
			}, isNew ? t('addItemTitle') : t('save'))
		];
		if (!isNew) {
			actions.unshift(h('button', {
				className: 'nxnc-btn danger',
				key: 'delete',
				onClick: function () { props.onDelete(item); }
			}, t('deleteLabel')));
		}

		return h(Modal, {
			title: isNew ? t('addItemTitle') : t('editItem'),
			onClose: props.onClose,
			actions: actions
		},
			h(Field, { label: t('title') }, h('input', { type: 'text', value: values.title, onChange: set('title') })),
			h(Field, { label: t('titleHe') }, h('input', { type: 'text', dir: 'rtl', value: values.title_he, onChange: set('title_he') })),
			h('div', { className: 'nxnc-field-row' },
				h(Field, { label: t('section') }, h('input', { type: 'text', value: values.section, onChange: set('section') })),
				h(Field, { label: t('sectionHe') }, h('input', { type: 'text', dir: 'rtl', value: values.section_he, onChange: set('section_he') }))
			),
			h(Field, { label: t('howToCheck') }, h('textarea', { rows: 5, value: values.how_to_check, onChange: set('how_to_check') })),
			h('div', { className: 'nxnc-field-row' },
				h(Field, { label: t('severity') },
					h('select', { value: values.severity, onChange: set('severity') },
						['blocker', 'major', 'minor'].map(function (level) {
							return h('option', { value: level, key: level }, t(level));
						})
					)
				),
				h(Field, { label: t('checkType') },
					h('select', { value: values.check_type, onChange: set('check_type') },
						['agent', 'browser', 'manual'].map(function (kind) {
							return h('option', { value: kind, key: kind }, t(kind));
						})
					)
				)
			)
		);
	}

	function FailNoteModal(props) {
		var t = props.t;
		var state = useState(props.result.notes || '');
		var notes = state[0];
		var setNotes = state[1];

		return h(Modal, {
			title: t('markFailed'),
			onClose: props.onClose,
			actions: [
				h('button', { className: 'nxnc-btn', key: 'cancel', onClick: props.onClose }, t('cancel')),
				h('button', {
					className: 'nxnc-btn danger-solid',
					key: 'fail',
					onClick: function () { props.onClose(); props.onConfirm(notes); }
				}, t('markFailedBtn'))
			]
		},
			h('p', { className: 'nxnc-modal-text' }, props.result.title || props.result.item_id),
			h(Field, { label: t('failNote') },
				h('textarea', {
					rows: 4,
					placeholder: t('failPlaceholder'),
					value: notes,
					onChange: function (event) { setNotes(event.target.value); }
				})
			)
		);
	}

	function AssignModal(props) {
		var t = props.t;
		var state = useState(props.result.assignee || '');
		return h(Modal, {
			title: t('assignTitle'),
			onClose: props.onClose,
			actions: [
				h('button', { className: 'nxnc-btn', key: 'cancel', onClick: props.onClose }, t('cancel')),
				h('button', {
					className: 'nxnc-btn primary',
					key: 'save',
					onClick: function () { props.onClose(); props.onConfirm(state[0]); }
				}, t('save'))
			]
		},
			h('p', { className: 'nxnc-modal-text' }, props.result.title || props.result.item_id),
			h(Field, { label: t('assign') },
				h('input', {
					type: 'text',
					placeholder: t('assignPlaceholder'),
					value: state[0],
					onChange: function (event) { state[1](event.target.value); }
				})
			)
		);
	}

	function StartRunModal(props) {
		var t = props.t;
		var today = new Date().toISOString().slice(0, 10);
		var labelState = useState('');
		var autoState = useState(true);

		return h(Modal, {
			title: t('startRunTitle'),
			onClose: props.onClose,
			actions: [
				h('button', { className: 'nxnc-btn', key: 'cancel', onClick: props.onClose }, t('cancel')),
				h('button', {
					className: 'nxnc-btn primary',
					key: 'start',
					onClick: function () { props.onClose(); props.onStart(labelState[0], autoState[0]); }
				}, t('startRun'))
			]
		},
			h(Field, { label: t('labelField') },
				h('input', {
					type: 'text',
					placeholder: t('labelPlaceholder', today),
					value: labelState[0],
					onChange: function (event) { labelState[1](event.target.value); }
				})
			),
			h('label', { className: 'nxnc-check-row' },
				h('input', {
					type: 'checkbox',
					checked: autoState[0],
					onChange: function (event) { autoState[1](event.target.checked); }
				}),
				h('span', null,
					h('strong', null, t('autoFirst')),
					h('em', null, t('autoFirstHelp'))
				)
			)
		);
	}

	function ReportModal(props) {
		var t = props.t;
		return h(Modal, {
			title: t('runReport'),
			onClose: props.onClose,
			wide: true,
			actions: [
				h('button', {
					className: 'nxnc-btn primary',
					key: 'copy',
					onClick: function () {
						navigator.clipboard.writeText(props.markdown).then(function () { toast(t('reportCopied')); });
					}
				}, t('copyMarkdown'))
			]
		}, h('pre', { className: 'nxnc-report' }, props.markdown));
	}

	/* ------------------------------------------------------------------ */
	/* App                                                                 */
	/* ------------------------------------------------------------------ */

	function App() {
		var langState = useState(initialLang);
		var lang = langState[0];
		var setLang = langState[1];
		var t = makeT(lang);
		var rtl = lang === 'he';

		var viewState = useState('dashboard');
		var view = viewState[0];
		var setView = viewState[1];

		var loadingState = useState(false);
		var loading = loadingState[0];
		var setLoading = loadingState[1];

		var dataState = useState({
			overview: null, checklists: [], checklist: null, runs: [], run: null,
			autoIds: [], autoPending: 0
		});
		var data = dataState[0];
		var setData = dataState[1];

		var modalState = useState(null);
		var modal = modalState[0];
		var setModal = modalState[1];

		function patch(next) {
			setData(function (current) { return Object.assign({}, current, next); });
		}

		var fail = useCallback(function (err) {
			var msg = (err && err.data && err.data.message) ? err.data.message : t('somethingWrong');
			toast(msg, 'err');
		}, [lang]);

		function chooseLang(next) {
			setLang(next);
			try { window.localStorage.setItem(LANG_KEY, next); } catch (e) { /* private mode */ }
		}

		var navigate = useCallback(function (target) {
			setView(target);
			setLoading(true);
			var load;
			if (target === 'dashboard') {
				load = api('overview').then(function (out) { patch({ overview: out.data }); });
			} else if (target === 'checklists') {
				load = api('checklists').then(function (out) { patch({ checklists: out.data.checklists }); });
			} else if (target === 'runs' || target === 'reports') {
				load = api('runs?limit=100').then(function (out) { patch({ runs: out.data.runs }); });
			} else {
				load = Promise.resolve();
			}
			load.then(function () { setLoading(false); }).catch(function (err) { setLoading(false); fail(err); });
		}, [fail]);

		var openChecklist = useCallback(function (ref) {
			setView('checklist');
			setLoading(true);
			api('checklists/detail', { checklist: ref }).then(function (out) {
				patch({ checklist: out.data.checklist, autoIds: out.data.auto_checkable || [] });
				setLoading(false);
			}).catch(function (err) { setLoading(false); fail(err); });
		}, [fail]);

		var openRun = useCallback(function (runId) {
			setView('run');
			setLoading(true);
			return api('runs/detail', { run_id: runId }).then(function (out) {
				patch({
					run: out.data.run,
					autoIds: out.data.auto_checkable || [],
					autoPending: out.data.auto_pending || 0
				});
				setLoading(false);
			}).catch(function (err) { setLoading(false); fail(err); });
		}, [fail]);

		useEffect(function () { navigate('dashboard'); }, []);

		/* ---------------------------- actions -------------------------- */

		function closeModal() { setModal(null); }

		function askDeleteRun(run) {
			setModal({
				kind: 'confirm',
				title: t('deleteRun'),
				message: t('deleteRunBody', run.checklist_name),
				confirmLabel: t('deleteRun'),
				danger: true,
				onConfirm: function () {
					api('runs/delete', { run_id: run.run_id }).then(function () {
						toast(t('runDeleted'));
						navigate(view === 'runs' ? 'runs' : 'dashboard');
					}).catch(fail);
				}
			});
		}

		function startRun(slug) {
			setModal({
				kind: 'start-run',
				onStart: function (label, withAuto) {
					api('runs/start', { checklist: slug, label: label || '' }).then(function (out) {
						var runId = out.data.run.run_id;
						if (!withAuto) {
							toast(t('runStarted'));
							openRun(runId);
							return;
						}
						toast(t('runStartedAuto'));
						openRun(runId).then(function () {
							return api('runs/auto-check', { run_id: runId }).then(function (checked) {
								toast(checked.data.message || t('checksRecorded'));
								openRun(runId);
							});
						}).catch(function (err) { fail(err); openRun(runId); });
					}).catch(fail);
				}
			});
		}

		function recordResult(result, status, notes) {
			api('runs/record', {
				run_id: data.run.run_id,
				item_id: result.item_id,
				status: status,
				notes: notes !== undefined ? notes : (result.notes || ''),
				checked_by: 'dashboard'
			}).then(function () { return openRun(data.run.run_id); }).catch(fail);
		}

		function setItemStatus(result, status) {
			if (status !== 'fail') {
				recordResult(result, status);
				return;
			}
			setModal({
				kind: 'fail-note',
				result: result,
				onConfirm: function (notes) { recordResult(result, 'fail', notes); }
			});
		}

		function completeRun() {
			api('runs/complete', { run_id: data.run.run_id }).then(function () {
				toast(t('runCompleted'));
				openRun(data.run.run_id);
			}).catch(function (err) {
				if (err && err.status === 'items-pending') {
					setModal({
						kind: 'confirm',
						title: t('itemsPending'),
						message: err.data.message + ' ' + t('pendingSkipped'),
						confirmLabel: t('completeAnyway'),
						danger: false,
						onConfirm: function () {
							api('runs/complete', { run_id: data.run.run_id, force: true }).then(function () {
								toast(t('runCompleted'));
								openRun(data.run.run_id);
							}).catch(fail);
						}
					});
					return;
				}
				fail(err);
			});
		}

		function assignItem(result) {
			setModal({
				kind: 'assign',
				result: result,
				onConfirm: function (assignee) {
					api('runs/assign', { run_id: data.run.run_id, item_id: result.item_id, assignee: assignee })
						.then(function () { toast(t('assigned')); openRun(data.run.run_id); })
						.catch(fail);
				}
			});
		}

		function shareRun(runId) {
			api('runs/share', { run_id: typeof runId === 'string' ? runId : data.run.run_id }).then(function (out) {
				var url = out.data.share_url;
				navigator.clipboard.writeText(url).then(function () { toast(t('linkCopied')); });
			}).catch(fail);
		}

		function exportChecklist(slug) {
			api('checklists/export', { checklist: slug }).then(function (out) {
				var blob = new Blob([JSON.stringify(out.data.checklist, null, 2)], { type: 'application/json' });
				var a = document.createElement('a');
				a.href = URL.createObjectURL(blob);
				a.download = slug + '.nexxen-checklist.json';
				document.body.appendChild(a);
				a.click();
				setTimeout(function () { URL.revokeObjectURL(a.href); a.remove(); }, 500);
			}).catch(fail);
		}

		function importChecklist() {
			var input = document.createElement('input');
			input.type = 'file';
			input.accept = 'application/json,.json';
			input.onchange = function () {
				var file = input.files && input.files[0];
				if (!file) { return; }
				var reader = new FileReader();
				reader.onload = function () {
					var parsed;
					try { parsed = JSON.parse(String(reader.result)); } catch (e) { toast(t('importInvalid'), 'err'); return; }
					api('checklists/import', { checklist: parsed }).then(function (out) {
						toast(t('imported'));
						openChecklist(out.data.checklist.slug);
					}).catch(fail);
				};
				reader.readAsText(file);
			};
			input.click();
		}

		function runAutoChecks() {
			toast(t('runningChecks'));
			api('runs/auto-check', { run_id: data.run.run_id }).then(function (out) {
				toast(out.data.message || t('checksRecorded'));
				openRun(data.run.run_id);
			}).catch(fail);
		}

		function showReport(runId) {
			api('runs/report', { run_id: typeof runId === 'string' ? runId : data.run.run_id }).then(function (out) {
				setModal({ kind: 'report', markdown: out.data.markdown || '' });
			}).catch(fail);
		}

		function toggleItem(item, enabled) {
			api('checklists/update', {
				checklist: data.checklist.slug,
				update_item: { id: item.id, enabled: enabled }
			}).then(function () {
				toast(enabled ? t('itemEnabled') : t('itemDisabled'));
				openChecklist(data.checklist.slug);
			}).catch(fail);
		}

		function saveItem(values, isNew, item) {
			var payload = { checklist: data.checklist.slug };
			var itemData = {
				section: values.section || 'General',
				section_he: values.section_he,
				title: values.title,
				title_he: values.title_he,
				how_to_check: values.how_to_check,
				severity: values.severity,
				check_type: values.check_type
			};
			if (isNew) {
				payload.add_items = [itemData];
			} else {
				itemData.id = item.id;
				payload.update_item = itemData;
			}
			api('checklists/update', payload).then(function () {
				closeModal();
				toast(isNew ? t('itemAdded') : t('itemUpdated'));
				openChecklist(data.checklist.slug);
			}).catch(fail);
		}

		function deleteItem(item) {
			setModal({
				kind: 'confirm',
				title: t('deleteItem'),
				message: t('deleteItemBody', item.title || item.id),
				confirmLabel: t('deleteItem'),
				danger: true,
				onConfirm: function () {
					api('checklists/update', {
						checklist: data.checklist.slug,
						remove_item_ids: [item.id]
					}).then(function () {
						toast(t('itemRemoved'));
						openChecklist(data.checklist.slug);
					}).catch(fail);
				}
			});
		}

		function deleteChecklist() {
			setModal({
				kind: 'confirm',
				title: t('deleteChecklist'),
				message: t('deleteChecklistBody', localized(data.checklist, 'name', lang)),
				confirmLabel: t('deleteChecklist'),
				danger: true,
				onConfirm: function () {
					api('checklists/delete', { checklist: data.checklist.slug }).then(function () {
						toast(t('checklistDeleted'));
						navigate('checklists');
					}).catch(fail);
				}
			});
		}

		function restoreBuiltin() {
			api('checklists/restore-builtin', {}).then(function () {
				toast(t('libraryRestored'));
				navigate('checklists');
			}).catch(fail);
		}

		/* ---------------------------- rendering ------------------------ */

		var body;
		if (loading) {
			body = h('div', { className: 'nxnc-loading' }, t('loading'));
		} else if (view === 'dashboard') {
			body = h(Dashboard, {
				t: t, overview: data.overview, onNavigate: navigate, onOpenRun: openRun,
				onDeleteRun: askDeleteRun, onRefresh: function () { navigate('dashboard'); }, onError: fail
			});
		} else if (view === 'checklists') {
			body = h(ChecklistGrid, {
				t: t, lang: lang, checklists: data.checklists, onOpen: openChecklist,
				onStartRun: startRun, onRestore: restoreBuiltin,
				onExport: exportChecklist, onImport: importChecklist,
				onNew: function () {
					setModal({
						kind: 'new-checklist',
						onCreate: function (values) {
							api('checklists', {
								name: values.name,
								name_he: values.name_he,
								category: values.category || 'general',
								description: values.description
							}).then(function (out) {
								closeModal();
								toast(t('checklistCreated'));
								openChecklist(out.data.checklist.slug);
							}).catch(fail);
						}
					});
				}
			});
		} else if (view === 'checklist') {
			body = h(ChecklistEditor, {
				t: t, lang: lang, checklist: data.checklist, autoIds: data.autoIds,
				onNavigate: navigate, onStartRun: startRun, onDelete: deleteChecklist,
				onToggleItem: toggleItem,
				onEditItem: function (item) {
					setModal({ kind: 'item', item: item });
				}
			});
		} else if (view === 'reports') {
			body = h(ReportsView, {
				t: t, runs: data.runs, onOpenRun: openRun,
				onShareRun: function (id) { shareRun(id); },
				onShowReport: function (id) { showReport(id); }
			});
		} else if (view === 'runs') {
			body = h('div', { className: 'nxnc-panel' },
				h('div', { className: 'nxnc-panel-head' },
					h('h2', null, t('runs')),
					h('button', { className: 'nxnc-btn primary', onClick: function () { navigate('checklists'); } }, t('startNewRun'))
				),
				h(RunTable, { t: t, runs: data.runs, onOpen: openRun, onDelete: askDeleteRun })
			);
		} else {
			body = h(RunView, {
				t: t, lang: lang, run: data.run, autoIds: data.autoIds, autoPending: data.autoPending,
				onNavigate: navigate, onSetStatus: setItemStatus, onComplete: completeRun,
				onAutoCheck: runAutoChecks, onReport: showReport,
				onShare: shareRun, onAssign: assignItem
			});
		}

		var modalNode = null;
		if (modal) {
			if (modal.kind === 'confirm') {
				modalNode = h(ConfirmModal, {
					t: t, title: modal.title, message: modal.message, confirmLabel: modal.confirmLabel,
					danger: modal.danger, onClose: closeModal, onConfirm: modal.onConfirm
				});
			} else if (modal.kind === 'new-checklist') {
				modalNode = h(NewChecklistModal, { t: t, onClose: closeModal, onCreate: modal.onCreate });
			} else if (modal.kind === 'item') {
				modalNode = h(ItemModal, {
					t: t, item: modal.item, onClose: closeModal, onSave: saveItem,
					onDelete: function (item) { closeModal(); deleteItem(item); }
				});
			} else if (modal.kind === 'assign') {
				modalNode = h(AssignModal, { t: t, result: modal.result, onClose: closeModal, onConfirm: modal.onConfirm });
			} else if (modal.kind === 'fail-note') {
				modalNode = h(FailNoteModal, { t: t, result: modal.result, onClose: closeModal, onConfirm: modal.onConfirm });
			} else if (modal.kind === 'start-run') {
				modalNode = h(StartRunModal, { t: t, onClose: closeModal, onStart: modal.onStart });
			} else if (modal.kind === 'report') {
				modalNode = h(ReportModal, { t: t, markdown: modal.markdown, onClose: closeModal });
			}
		}

		return h('div', { className: 'nxnc-app', dir: rtl ? 'rtl' : 'ltr', lang: rtl ? 'he' : 'en' },
			h(Header, { t: t, view: view, lang: lang, onNavigate: navigate, onLang: chooseLang }),
			h('main', { className: 'nxnc-main' }, body),
			modalNode
		);
	}

	/* Mount with the modern root API where WordPress ships it. */
	if (wpEl.createRoot) {
		wpEl.createRoot(mount).render(h(App));
	} else {
		wpEl.render(h(App), mount);
	}
})();
