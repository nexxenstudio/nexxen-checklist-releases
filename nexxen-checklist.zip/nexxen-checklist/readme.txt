=== Nexxen Checklist ===
Contributors: nexxenstudio
Tags: checklist, qa, launch, rtl, hebrew, accessibility, preflight
Requires at least: 6.5
Tested up to: 6.8
Requires PHP: 7.4
Stable tag: 1.2.2
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Bilingual Hebrew/English launch checklists for Nexxen Studio sites: RTL-aware QA runs, readiness scoring, a deterministic auto-check engine and full MCP automation.

== Description ==

Nexxen Checklist turns the Nexxen Studio build standard into structured, repeatable checklist runs that both people (through the dashboard) and AI agents (through the WordPress Abilities API / MCP adapter) can execute.

The whole interface is bilingual. A language switch in the sidebar moves the dashboard between English and Hebrew, flipping the layout to right-to-left and showing the Hebrew title of every checklist item. Checklist content is stored in both languages, so the same run reads correctly to a Hebrew-speaking client and to an English-speaking developer.

**Built-in checklist library — ten checklists, around 130 items**

Nexxen process checklists, taken from the studio's written build standard:

* Mockup & Content Prep — metadata from the content document, translated copy, WebP images, site-wide details.
* Initial Development — Hebrew RTL builder setup, editable structure, specific class names, form behaviour and required fields, no auto-movement, Hebrew CPT labels.
* Final Check Before Delivery — offcanvas menu, policy and utility pages, the agreed Hebrew copyright line, RTL layout review, full incognito pass.
* E-commerce (WooCommerce) — cart reveal, AJAX mini-cart, quantity controls positioned for RTL, shekel formatting, and the three pages every Israeli store must publish.
* Legal & Accessibility Pages — accessibility statement, privacy policy (Amendment 13) and site terms, with real contact details and no leftover placeholders.

General QA checklists that apply to any site:

* Front-end Design QA, Plugins & Backend QA, Go-Live / Launch, SEO & Content QA, Accessibility Basics.

Every item carries written how-to-check instructions, a severity (blocker, major, minor) and a check type (agent, browser, manual), so nobody has to guess what "checked" means.

**Automatic checks**

A deterministic PHP engine settles the mechanical items in seconds — no AI and no external services. It reads WordPress options, makes HTTP requests to the site's own URLs and searches the database. It can decide roughly 50 item types, including:

* Hebrew locale and RTL, plus the html lang and dir attributes.
* Environment-aware indexing: staging domains should be hidden, live domains should not.
* Accessibility statement, privacy policy and site terms — published, long enough to be real, free of unresolved placeholder tokens, and linked from the homepage.
* The agreed footer copyright line and its 1000shekel.com link.
* WebP media coverage, unused themes, an active Advanced Themer, external links opening in a new tab, Hebrew CPT labels, shekel currency position.
* SSL and HTTPS forcing, canonical host, staging URLs left in content, sitemap, robots.txt, meta titles and descriptions, Open Graph, placeholder content, H1 counts, dead links, image alt text, heading hierarchy and structured data.

Anything the engine cannot decide conclusively is left pending with a note, never guessed as a pass.

**Runs, scoring and reports**

Each run records a status, notes, evidence and who checked it, per item. Completing a run produces a weighted readiness score out of 100 and a verdict: ready, review, or not ready. Any failed blocker caps the verdict at not-ready regardless of the score. Reports export as copy-ready Markdown with failures ranked first.

**Weekly drift scan**

A cron job re-runs the live-site safety subset every week — indexing, SSL, debug output, robots, sitemap, caching, 404s and the Hebrew/RTL html attributes — and surfaces regressions on the dashboard.

**Built for agents**

Every operation is registered on the WordPress Abilities API, so an MCP-connected agent can list checklists, start a run, run the automatic checks, loop through the remaining items with their instructions, record results with evidence, and produce the final report.

== Installation ==

1. Upload the plugin folder to `/wp-content/plugins/`, or install the zip through Plugins > Add New > Upload.
2. Activate it. Two tables are created and the built-in library is seeded automatically.
3. Open **Nexxen Checklist** in the admin menu.

The dashboard is React, built on the copy of React WordPress already ships for the block editor. There is no build step and nothing loads on the front end — the interface exists only inside wp-admin.

== Frequently Asked Questions ==

= Does this slow the site down? =

No. Nothing in this plugin loads for site visitors. The dashboard, its styles and its scripts are enqueued only on the plugin's own admin screen.

= Can I edit the built-in checklists? =

Yes. Disable items you do not need, edit their text or severity, and add your own. Updating the plugin refreshes the built-in wording but keeps your customisations, and `Restore built-in library` brings back anything you deleted without touching custom checklists.

= What happens to my data if I uninstall? =

Both tables and all options are dropped on uninstall. To keep them, set the `nexxen_checklist_preserve_data` option to a truthy value before deleting.

== Changelog ==

= 1.2.2 =
* Fix: other plugins' admin notices no longer get injected into the dashboard header — WordPress now places them above the app.
* Fix: run progress bars fill from the start of the track (they grew from the centre due to an invalid CSS keyword); in Hebrew they correctly fill from the right.

= 1.2.1 =
* Fix: update checks now read the release manifest through GitHub's always-current "latest release" path instead of a mirror that could stay stale for several minutes after publishing.

= 1.2.0 =
* Redesigned dashboard: WPD-style top header with tabs (replacing the sidebar), minimal borderless styling, Nexxen colours kept.
* New Reports tab listing every completed run with its score and verdict, plus one-click report view and share-link copy.
* Default interface language is now English; Hebrew remains one click away and the choice is remembered per person.
* Removed email notifications (run completion and drift alerts) — results live in the dashboard and Reports tab instead.

= 1.1.2 =
* New: a "Check for updates" link on the Plugins screen row. It queries the release server immediately, reports the outcome in a notice, and surfaces the standard update link when a new version exists.

= 1.1.1 =
* Fix: pressing "Check again" on the Updates screen now also bypasses the plugin's own update cache, so freshly published releases appear immediately instead of after up to six hours.

= 1.1.0 =
* Assign items: each run item can carry a responsible person, editable from the run view.
* Needs-attention filter: one click shows only failed and pending items.
* Checker role: a new "Nexxen Checker" WordPress role can open the dashboard and work runs, without rights to edit or delete checklists.
* Shareable reports: completed runs get a read-only public link (English and Hebrew) for clients and the delivery group.
* Email notifications when a run completes and when the weekly drift scan finds regressions.
* Export/import: move checklists between sites as JSON files; same slug updates in place.

= 1.0.1 =
* Self-updating: the plugin now checks the public Nexxen Studio releases repository twice a day, so new versions appear on the Plugins screen and work with the standard WordPress auto-update toggle.

= 1.0.0 =
* First release: bilingual Hebrew/English dashboard with RTL support, ten built-in checklists, deterministic auto-check engine with Hebrew/RTL and Israeli legal-page checks, run history, readiness scoring, Markdown reports, weekly drift scan and full Abilities/MCP coverage.
