<?php
/**
 * Nexxen Checklist uninstall. Drops plugin tables and options unless the operator
 * opted to keep data via the nexxen_checklist_preserve_data option.
 */

defined( 'WP_UNINSTALL_PLUGIN' ) || exit;

if ( get_option( 'nexxen_checklist_preserve_data' ) ) {
	return;
}

global $wpdb;

$wpdb->query( "DROP TABLE IF EXISTS {$wpdb->prefix}nexxen_checklist_checklists" ); // phpcs:ignore
$wpdb->query( "DROP TABLE IF EXISTS {$wpdb->prefix}nexxen_checklist_runs" ); // phpcs:ignore

delete_option( 'nexxen_checklist_version' );
delete_option( 'nexxen_checklist_db_version' );
delete_option( 'nexxen_checklist_preserve_data' );
delete_option( 'nexxen_checklist_drift' );
delete_site_transient( 'nexxen_checklist_update_manifest' );

remove_role( 'nexxen_checker' );
$nexxen_admin_role = get_role( 'administrator' );
if ( $nexxen_admin_role ) {
	$nexxen_admin_role->remove_cap( 'nexxen_checklist_check' );
}
