<?php
namespace Nexxen_Checklist;

defined( 'ABSPATH' ) || exit;

final class Installer {

	const DB_VERSION_OPTION = 'nexxen_checklist_db_version';
	const DB_VERSION        = '3';

	/**
	 * Capability that opens the dashboard and allows checking items. Granted
	 * to administrators and to the dedicated checker role, so a project
	 * manager can work runs without full admin rights. Destructive operations
	 * (deleting checklists/runs, editing items) still require manage_options.
	 */
	const CHECK_CAP = 'nexxen_checklist_check';

	public static function activate() {
		self::create_tables();
		self::seed_library();
		self::register_role();
		update_option( self::DB_VERSION_OPTION, self::DB_VERSION );
		update_option( 'nexxen_checklist_version', NEXXEN_CHECKLIST_VERSION );
	}

	public static function register_role() {
		$admin = get_role( 'administrator' );
		if ( $admin && ! $admin->has_cap( self::CHECK_CAP ) ) {
			$admin->add_cap( self::CHECK_CAP );
		}
		if ( ! get_role( 'nexxen_checker' ) ) {
			add_role(
				'nexxen_checker',
				__( 'Nexxen Checker', 'nexxen-checklist' ),
				array(
					'read'          => true,
					self::CHECK_CAP => true,
				)
			);
		}
	}

	public static function deactivate() {
		// Non-destructive: only unschedule our cron. Data removal happens in uninstall.php.
		wp_clear_scheduled_hook( 'nexxen_checklist_drift_scan' );
	}

	public static function maybe_upgrade() {
		if ( get_option( self::DB_VERSION_OPTION ) !== self::DB_VERSION ) {
			self::create_tables();
			self::register_role();
			update_option( self::DB_VERSION_OPTION, self::DB_VERSION );
		}
		if ( get_option( 'nexxen_checklist_version' ) !== NEXXEN_CHECKLIST_VERSION ) {
			self::seed_library();
			update_option( 'nexxen_checklist_version', NEXXEN_CHECKLIST_VERSION );
		}
	}

	public static function create_tables() {
		global $wpdb;
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';

		$charset    = $wpdb->get_charset_collate();
		$checklists = $wpdb->prefix . 'nexxen_checklist_checklists';
		$runs       = $wpdb->prefix . 'nexxen_checklist_runs';

		dbDelta(
			"CREATE TABLE {$checklists} (
				id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
				slug VARCHAR(191) NOT NULL,
				name VARCHAR(191) NOT NULL,
				name_he VARCHAR(191) NULL,
				description TEXT NULL,
				category VARCHAR(100) NOT NULL DEFAULT 'general',
				source VARCHAR(20) NOT NULL DEFAULT 'custom',
				items LONGTEXT NULL,
				sort_order INT NOT NULL DEFAULT 0,
				created_at DATETIME NOT NULL,
				updated_at DATETIME NOT NULL,
				PRIMARY KEY  (id),
				UNIQUE KEY slug (slug)
			) {$charset};"
		);

		dbDelta(
			"CREATE TABLE {$runs} (
				id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
				run_id VARCHAR(40) NOT NULL,
				checklist_id BIGINT UNSIGNED NOT NULL,
				checklist_slug VARCHAR(191) NOT NULL,
				checklist_name VARCHAR(191) NOT NULL,
				label VARCHAR(191) NULL,
				status VARCHAR(20) NOT NULL DEFAULT 'in-progress',
				results LONGTEXT NULL,
				summary LONGTEXT NULL,
				started_at DATETIME NOT NULL,
				completed_at DATETIME NULL,
				created_by VARCHAR(120) NULL,
				share_token VARCHAR(64) NULL,
				PRIMARY KEY  (id),
				UNIQUE KEY run_id (run_id),
				KEY checklist_id (checklist_id)
			) {$charset};"
		);
	}

	/**
	 * Seeds or refreshes the built-in checklist library. Existing built-in
	 * checklists are updated in place (new items appended, item text
	 * refreshed); custom checklists are never touched.
	 */
	public static function seed_library() {
		$store = new Store();
		foreach ( Library::checklists() as $seed ) {
			$existing = $store->get_checklist( $seed['slug'] );
			if ( ! $existing ) {
				$store->save_checklist( $seed );
				continue;
			}
			if ( 'builtin' !== $existing['source'] ) {
				continue;
			}
			$store->save_checklist( self::merge_builtin( $existing, $seed ) );
		}
	}

	/**
	 * Keeps operator customisations (disabled items, edited severity) while
	 * pulling in new built-in items and refreshed descriptions.
	 */
	private static function merge_builtin( array $existing, array $seed ) {
		$current = array();
		foreach ( (array) $existing['items'] as $item ) {
			if ( isset( $item['id'] ) ) {
				$current[ $item['id'] ] = $item;
			}
		}
		$merged = array();
		foreach ( $seed['items'] as $item ) {
			if ( isset( $current[ $item['id'] ] ) ) {
				$kept                 = $current[ $item['id'] ];
				$item['enabled']      = isset( $kept['enabled'] ) ? (bool) $kept['enabled'] : true;
				$item['severity']     = ! empty( $kept['severity'] ) ? $kept['severity'] : $item['severity'];
				if ( ! empty( $kept['custom'] ) ) {
					$item = $kept; // Fully operator-owned copy wins.
				}
				unset( $current[ $item['id'] ] );
			}
			$merged[] = $item;
		}
		// Operator-added items on a built-in checklist stay at the end.
		foreach ( $current as $item ) {
			if ( ! empty( $item['custom'] ) ) {
				$merged[] = $item;
			}
		}
		$existing['name']        = $seed['name'];
		$existing['name_he']     = isset( $seed['name_he'] ) ? $seed['name_he'] : '';
		$existing['description'] = $seed['description'];
		$existing['category']    = $seed['category'];
		$existing['items']       = $merged;
		return $existing;
	}
}
