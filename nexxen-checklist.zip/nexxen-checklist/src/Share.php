<?php
namespace Nexxen_Checklist;

defined( 'ABSPATH' ) || exit;

/**
 * Public read-only report page: ?nexxen-report=<token> on the site root.
 * Tokens are 32 random characters generated when a run completes, so the
 * link works without a WordPress login — for clients and the delivery group.
 * ?lang=he renders the Hebrew titles right-to-left.
 */
final class Share {

	private $store;

	public function __construct( Store $store ) {
		$this->store = $store;
	}

	public function boot() {
		add_action( 'init', array( $this, 'maybe_render' ), 1 );
	}

	public function maybe_render() {
		if ( empty( $_GET['nexxen-report'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			return;
		}
		$run = $this->store->get_run_by_token( (string) $_GET['nexxen-report'] ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		if ( ! $run || 'completed' !== $run['status'] ) {
			status_header( 404 );
			nocache_headers();
			exit( 'Report not found.' );
		}
		$checklist = $this->store->get_checklist( $run['checklist_id'] );
		$hebrew    = isset( $_GET['lang'] ) && 'he' === $_GET['lang']; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		nocache_headers();
		header( 'Content-Type: text/html; charset=utf-8' );
		header( 'X-Robots-Tag: noindex, nofollow' );
		$this->render( $run, $checklist, $hebrew );
		exit;
	}

	private function label( array $item, $field, $hebrew ) {
		if ( $hebrew && ! empty( $item[ $field . '_he' ] ) ) {
			return $item[ $field . '_he' ];
		}
		return isset( $item[ $field ] ) ? $item[ $field ] : '';
	}

	private function render( array $run, $checklist, $hebrew ) {
		$summary = is_array( $run['summary'] ) ? $run['summary'] : array();
		$counts  = isset( $summary['counts'] ) ? $summary['counts'] : array();
		$score   = isset( $summary['readiness_score'] ) ? (int) $summary['readiness_score'] : 0;
		$verdict = isset( $summary['verdict'] ) ? $summary['verdict'] : '';

		$items_by_id = array();
		if ( $checklist ) {
			foreach ( $checklist['items'] as $item ) {
				$items_by_id[ $item['id'] ] = $item;
			}
		}

		$t = $hebrew
			? array(
				'report'   => 'דוח בדיקות',
				'score'    => 'ציון מוכנות',
				'verdicts' => array( 'ready' => 'מוכן', 'review' => 'לבדיקה', 'not-ready' => 'לא מוכן' ),
				'statuses' => array( 'pass' => 'עבר', 'fail' => 'נכשל', 'na' => 'לא רלוונטי', 'skipped' => 'דולג', 'pending' => 'ממתין' ),
				'failures' => 'כשלים לטיפול',
				'results'  => 'כל התוצאות',
				'general'  => 'כללי',
				'other'    => 'English version',
				'otherurl' => remove_query_arg( 'lang' ),
			)
			: array(
				'report'   => 'QA report',
				'score'    => 'Readiness score',
				'verdicts' => array( 'ready' => 'Ready', 'review' => 'Review', 'not-ready' => 'Not ready' ),
				'statuses' => array( 'pass' => 'Pass', 'fail' => 'Fail', 'na' => 'N/A', 'skipped' => 'Skipped', 'pending' => 'Pending' ),
				'failures' => 'Failures to fix',
				'results'  => 'Full results',
				'general'  => 'General',
				'other'    => 'גרסה עברית',
				'otherurl' => add_query_arg( 'lang', 'he' ),
			);

		$verdict_colors = array( 'ready' => '#12855a', 'review' => '#b54708', 'not-ready' => '#d92d20' );
		$verdict_color  = isset( $verdict_colors[ $verdict ] ) ? $verdict_colors[ $verdict ] : '#6b7280';

		$by_section = array();
		foreach ( $run['results'] as $result ) {
			$item    = isset( $items_by_id[ $result['item_id'] ] ) ? $items_by_id[ $result['item_id'] ] : array();
			$section = $this->label( $item, 'section', $hebrew );
			$by_section[ $section ? $section : $t['general'] ][] = array( $result, $item );
		}

		echo '<!DOCTYPE html><html lang="' . ( $hebrew ? 'he' : 'en' ) . '" dir="' . ( $hebrew ? 'rtl' : 'ltr' ) . '"><head><meta charset="utf-8">';
		echo '<meta name="viewport" content="width=device-width, initial-scale=1"><meta name="robots" content="noindex,nofollow">';
		echo '<title>' . esc_html( $run['checklist_name'] . ' — ' . $t['report'] ) . '</title>';
		echo '<style>
			body{margin:0;background:#f5f5f7;font-family:"Inter Tight",Inter,-apple-system,"Segoe UI",Roboto,sans-serif;color:#171717;font-size:15px;line-height:1.55}
			.wrap{max-width:820px;margin:0 auto;padding:28px 18px 60px}
			.head{background:linear-gradient(150deg,#220387,#16025c);color:#fff;border-radius:18px;padding:26px 28px;display:flex;justify-content:space-between;gap:18px;flex-wrap:wrap;align-items:center}
			.head h1{margin:0;font-size:20px;font-weight:600}
			.head p{margin:5px 0 0;font-size:12.5px;color:rgba(255,255,255,.65)}
			.score{text-align:center}
			.score strong{display:block;font-size:34px;line-height:1.1}
			.score span{font-size:12px;padding:3px 12px;border-radius:999px;background:#d7ff52;color:#1b0a52;font-weight:600}
			.panel{background:#fff;border:1px solid #e5e7eb;border-radius:16px;padding:20px 22px;margin-top:16px}
			.panel h2{margin:0 0 12px;font-size:15px}
			h3{font-size:11.5px;text-transform:uppercase;letter-spacing:.06em;color:#6b7280;margin:18px 0 8px}
			.row{display:flex;gap:12px;align-items:flex-start;border-top:1px solid #f0f0f2;padding:9px 0}
			.row:first-of-type{border-top:0}
			.st{flex:none;font-size:10.5px;font-weight:600;text-transform:uppercase;padding:2px 9px;border-radius:999px;min-width:44px;text-align:center}
			.st-pass{background:rgba(18,133,90,.12);color:#12855a}.st-fail{background:rgba(217,45,32,.12);color:#d92d20}
			.st-na,.st-skipped,.st-pending{background:#f0f0f2;color:#6b7280}
			.note{font-size:12.5px;color:#6b7280;margin:3px 0 0}
			.lang{font-size:12.5px;color:#4f2ae0;text-decoration:none}
			.fail-item{border-inline-start:3px solid #d92d20;padding:8px 12px;background:#fdf3f2;border-radius:8px;margin-bottom:7px;font-size:13.5px}
		</style></head><body><div class="wrap">';

		echo '<div class="head"><div>';
		echo '<h1>' . esc_html( ( $hebrew && $checklist && ! empty( $checklist['name_he'] ) ) ? $checklist['name_he'] : $run['checklist_name'] ) . '</h1>';
		echo '<p>' . esc_html( wp_parse_url( home_url(), PHP_URL_HOST ) . ( $run['label'] ? ' · ' . $run['label'] : '' ) . ' · ' . $run['completed_at'] . ' UTC' ) . '</p>';
		echo '<p><a class="lang" style="color:#d7ff52" href="' . esc_url( $t['otherurl'] ) . '">' . esc_html( $t['other'] ) . '</a></p>';
		echo '</div><div class="score"><strong>' . esc_html( $score ) . '/100</strong>';
		echo '<span style="background:' . esc_attr( $verdict_color ) . ';color:#fff">' . esc_html( isset( $t['verdicts'][ $verdict ] ) ? $t['verdicts'][ $verdict ] : $verdict ) . '</span></div></div>';

		if ( ! empty( $summary['failed_items'] ) ) {
			echo '<div class="panel"><h2>' . esc_html( $t['failures'] ) . '</h2>';
			foreach ( $summary['failed_items'] as $failure ) {
				$item  = isset( $items_by_id[ $failure['item_id'] ] ) ? $items_by_id[ $failure['item_id'] ] : array();
				$title = $this->label( $item, 'title', $hebrew );
				echo '<div class="fail-item"><strong>' . esc_html( $title ? $title : $failure['title'] ) . '</strong>';
				if ( ! empty( $failure['notes'] ) ) {
					echo '<p class="note">' . esc_html( $failure['notes'] ) . '</p>';
				}
				echo '</div>';
			}
			echo '</div>';
		}

		echo '<div class="panel"><h2>' . esc_html( $t['results'] ) . '</h2>';
		foreach ( $by_section as $section => $pairs ) {
			echo '<h3>' . esc_html( $section ) . '</h3>';
			foreach ( $pairs as $pair ) {
				list( $result, $item ) = $pair;
				$status = isset( $result['status'] ) ? $result['status'] : 'pending';
				$title  = $this->label( $item, 'title', $hebrew );
				echo '<div class="row"><span class="st st-' . esc_attr( $status ) . '">' . esc_html( isset( $t['statuses'][ $status ] ) ? $t['statuses'][ $status ] : $status ) . '</span>';
				echo '<div><div>' . esc_html( $title ? $title : $result['item_id'] ) . '</div>';
				if ( ! empty( $result['notes'] ) ) {
					echo '<p class="note">' . esc_html( $result['notes'] ) . '</p>';
				}
				echo '</div></div>';
			}
		}
		echo '</div></div></body></html>';
	}
}
