<?php
namespace Nexxen_Checklist\Rest;

use Nexxen_Checklist\Actions;
use Nexxen_Checklist\Installer;

defined( 'ABSPATH' ) || exit;

/**
 * REST API for the admin dashboard. Thin wrapper over Actions; cookie+nonce
 * authenticated. Two tiers: "check" routes (view runs, record results,
 * assign, auto-check, complete) are open to the checker capability so a PM
 * can work runs; "manage" routes (create/edit/delete checklists, delete
 * runs, import) require full admin rights.
 */
final class Controller {

	const NS = 'nexxen-checklist/v1';

	private $actions;

	public function __construct( Actions $actions ) {
		$this->actions = $actions;
	}

	public function boot() {
		add_action( 'rest_api_init', array( $this, 'register_routes' ) );
	}

	public function can_check() {
		$capability = apply_filters( 'nexxen_checklist_dashboard_capability', Installer::CHECK_CAP );
		return current_user_can( $capability ) || current_user_can( 'manage_options' );
	}

	public function can_manage() {
		return current_user_can( 'manage_options' );
	}

	public function register_routes() {
		$routes = array(
			// path, method, action, tier
			array( 'overview', 'GET', 'get_overview', 'check' ),
			array( 'checklists', 'GET', 'list_checklists', 'check' ),
			array( 'checklists', 'POST', 'create_checklist', 'manage' ),
			array( 'checklists/detail', 'POST', 'get_checklist', 'check' ),
			array( 'checklists/update', 'POST', 'update_checklist', 'manage' ),
			array( 'checklists/delete', 'POST', 'delete_checklist', 'manage' ),
			array( 'checklists/restore-builtin', 'POST', 'restore_builtin_checklists', 'manage' ),
			array( 'checklists/export', 'POST', 'export_checklist', 'check' ),
			array( 'checklists/import', 'POST', 'import_checklist', 'manage' ),
			array( 'runs', 'GET', 'list_runs', 'check' ),
			array( 'runs/start', 'POST', 'start_run', 'check' ),
			array( 'runs/detail', 'POST', 'get_run', 'check' ),
			array( 'runs/record', 'POST', 'record_item_result', 'check' ),
			array( 'runs/assign', 'POST', 'assign_item', 'check' ),
			array( 'runs/auto-check', 'POST', 'run_auto_checks', 'check' ),
			array( 'runs/share', 'POST', 'get_share_link', 'check' ),
			array( 'drift', 'GET', 'get_drift_report', 'check' ),
			array( 'drift/run', 'POST', 'run_drift_scan', 'check' ),
			array( 'runs/complete', 'POST', 'complete_run', 'check' ),
			array( 'runs/delete', 'POST', 'delete_run', 'manage' ),
			array( 'runs/report', 'POST', 'get_run_report', 'check' ),
		);
		foreach ( $routes as $route ) {
			list( $path, $method, $action, $tier ) = $route;
			register_rest_route(
				self::NS,
				'/' . $path,
				array(
					'methods'             => $method,
					'permission_callback' => array( $this, 'manage' === $tier ? 'can_manage' : 'can_check' ),
					'callback'            => function ( $request ) use ( $action ) {
						$input = 'GET' === $request->get_method() ? $request->get_query_params() : (array) $request->get_json_params();
						$out   = call_user_func( array( $this->actions, $action ), is_array( $input ) ? $input : array() );
						return rest_ensure_response( $out );
					},
				)
			);
		}
	}
}
