<?php
namespace Nexxen_Checklist;

defined( 'ABSPATH' ) || exit;

/**
 * Built-in Nexxen Studio checklist library.
 *
 * Two families of checklists ship with the plugin:
 *
 * 1. Nexxen process checklists, transcribed from the studio's written build
 *    standard for Hebrew/RTL WordPress sites (mockup, initial build, final
 *    delivery, e-commerce, legal pages).
 * 2. General QA checklists (front-end, backend, go-live, SEO, accessibility)
 *    that apply to any site.
 *
 * Every item carries `how_to_check` instructions written for an agent, so a
 * run can be executed one item at a time without guessing what "checked"
 * means. Items are bilingual: `title`/`section` are English, `title_he` and
 * `section_he` carry the Hebrew the dashboard shows in Hebrew mode.
 *
 * Severities: blocker (must pass before launch), major (should pass), minor
 * (polish). Check types: agent (checkable via MCP/HTTP), browser (needs a real
 * browser/screenshot pass), manual (human judgement).
 *
 * Item ids of the general checklists intentionally match the ids in
 * Engine\AutoCheck::registry() so the deterministic engine can pre-fill them.
 */
final class Library {

	public static function checklists() {
		return array(
			self::mockup_content(),
			self::initial_build(),
			self::final_delivery(),
			self::ecommerce(),
			self::legal_pages(),
			self::frontend_design(),
			self::plugins_backend(),
			self::go_live(),
			self::seo_content(),
			self::accessibility(),
		);
	}

	/**
	 * @param string $id         Stable item id (also the auto-check key).
	 * @param array  $section    array( english, hebrew )
	 * @param array  $title      array( english, hebrew )
	 * @param string $how        How-to-check instructions for the agent.
	 */
	private static function item( $id, array $section, array $title, $how, $severity = 'major', $type = 'agent', $tags = array() ) {
		return array(
			'id'           => $id,
			'section'      => $section[0],
			'section_he'   => isset( $section[1] ) ? $section[1] : '',
			'title'        => $title[0],
			'title_he'     => isset( $title[1] ) ? $title[1] : '',
			'how_to_check' => $how,
			'severity'     => $severity,
			'check_type'   => $type,
			'tags'         => $tags,
			'enabled'      => true,
			'custom'       => false,
		);
	}

	/* =====================================================================
	 * Nexxen Studio process checklists
	 * ================================================================== */

	private static function mockup_content() {
		$seo   = array( 'SEO & Metadata', 'קידום ומטא-דאטה' );
		$brief = array( 'Brief & Content', 'בריף ותוכן' );

		return array(
			'slug'        => 'nexxen-mockup-content',
			'name'        => 'Mockup & Content Prep',
			'name_he'     => 'הכנת מוקאפ ותוכן',
			'description' => 'Everything that must be settled from the brief and the content document before the build starts: metadata, translated copy, images and the site-wide details the whole build depends on.',
			'category'    => 'nexxen',
			'source'      => 'builtin',
			'sort_order'  => 10,
			'items'       => array(
				self::item( 'meta-from-document', $seo, array( 'Homepage meta title and description taken from the content document', 'כותרת ותיאור מטא לדף הבית נלקחו ממסמך התוכן' ), 'Open the client content document and copy the homepage meta title and meta description exactly as written. Set them with Yoast SEO, or with the Bricks Builder page settings if Yoast is not installed. Do not invent your own wording when the document supplies it.', 'major', 'agent', array( 'seo', 'content' ) ),
				self::item( 'meta-all-pages', $seo, array( 'Every page has a meta title set in the builder', 'לכל עמוד הוגדרה כותרת מטא בבילדר' ), 'Go through each published page and confirm a meta title is set (Bricks page settings or Yoast). No page should fall back to the raw WordPress default such as "Home - Sitename".', 'major', 'agent', array( 'seo' ) ),
				self::item( 'sitewide-details-filled', $brief, array( 'Site-wide details are filled in and used everywhere', 'פרטי האתר הוזנו ומשומשים בכל מקום' ), 'Check the site-wide details store (JetEngine options / theme options): site title, phone, email, address, opening hours. Then confirm the header, footer, contact page and legal pages pull those dynamic values rather than repeating hard-coded text.', 'blocker', 'agent', array( 'content', 'consistency' ) ),
				self::item( 'copy-translated', $brief, array( 'All English copy has been translated to Hebrew', 'כל התוכן באנגלית תורגם לעברית' ), 'Read every page of the mockup content. No English placeholder or source copy may remain in the Hebrew build. Translate anything outstanding and have the wording sanity-checked before it goes live.', 'blocker', 'agent', array( 'content', 'hebrew' ) ),
				self::item( 'images-light-preference', $brief, array( 'Light images preferred over dark ones', 'העדפה לתמונות בהירות על פני כהות' ), 'Review the images chosen for each section. The client prefers light imagery; keep dark images to a minimum and only where the design genuinely calls for it.', 'minor', 'browser', array( 'media', 'design' ) ),
				self::item( 'images-webp', $brief, array( 'All images are WebP', 'כל התמונות בפורמט WebP' ), 'List the media library and the images actually rendered on key pages. Every content image should be served as .webp. Flag any leftover .jpg/.png originals that are still being displayed.', 'major', 'agent', array( 'media', 'performance' ) ),
				self::item( 'no-large-image-with-title-repeat', $brief, array( 'No large image with a title over it followed by the same content repeated below', 'אין תמונה גדולה עם כותרת מעליה ואותו תוכן החוזר מתחתיה' ), 'Scan every page layout. The client has explicitly rejected the pattern of a big hero image with a title overlaid, immediately followed by a section repeating that same title and text. If it appears anywhere, restructure the section.', 'blocker', 'browser', array( 'design', 'content' ) ),
				self::item( 'no-unnecessary-whitespace', $brief, array( 'No unnecessary empty space in the layout', 'אין רווחים ריקים מיותרים בפריסה' ), 'Scroll each page and look for oversized blank gaps between sections. Large empty space is only acceptable where the client asked for it specifically; otherwise tighten the spacing.', 'major', 'browser', array( 'design', 'layout' ) ),
			),
		);
	}

	private static function initial_build() {
		$builder  = array( 'Builder Setup', 'הגדרות הבילדר' );
		$struct   = array( 'Structure & Classes', 'מבנה ומחלקות' );
		$forms    = array( 'Forms', 'טפסים' );
		$motion   = array( 'Motion & Sliders', 'אנימציות וסליידרים' );
		$cpt      = array( 'Custom Post Types', 'סוגי תוכן מותאמים' );
		$pages    = array( 'Pages & Templates', 'עמודים ותבניות' );

		return array(
			'slug'        => 'nexxen-initial-build',
			'name'        => 'Initial Development',
			'name_he'     => 'פיתוח ראשוני',
			'description' => 'The Nexxen build standard: Hebrew RTL builder setup, a structure the client can edit, correct form behaviour, no auto-motion, and clean class naming.',
			'category'    => 'nexxen',
			'source'      => 'builtin',
			'sort_order'  => 20,
			'items'       => array(
				self::item( 'builder-light-theme', $builder, array( 'Builder interface is set to the light theme', 'ממשק הבילדר מוגדר לערכת נושא בהירה' ), 'Open Bricks Builder and confirm the editor interface uses the light colour scheme, not dark. The client works in the builder and expects it light.', 'minor', 'manual', array( 'builder' ) ),
				self::item( 'builder-hebrew-rtl', $builder, array( 'Builder language is Hebrew and direction is right-to-left', 'שפת הבילדר עברית והכיוון מימין לשמאל' ), 'Confirm the builder language is set to Hebrew and RTL is enabled, so the client sees the editor in their own language and reading direction. Also confirm the WordPress site language is Hebrew (Settings > General).', 'blocker', 'agent', array( 'builder', 'hebrew', 'rtl' ) ),
				self::item( 'structure-panel-hebrew', $builder, array( 'Structure panel labels are in Hebrew', 'תוויות פאנל המבנה בעברית' ), 'Open the Bricks structure panel. Every element should carry a meaningful Hebrew label so the client can find sections without reading English element names.', 'major', 'manual', array( 'builder', 'hebrew' ) ),
				self::item( 'easy-to-edit-structure', $struct, array( 'Page structure is as simple as possible for the client to edit', 'מבנה העמוד פשוט ככל האפשר לעריכה על ידי הלקוח' ), 'Review the element tree of each template. Avoid needless nesting and clever constructions; a non-technical client should be able to change text and images without breaking the layout.', 'major', 'manual', array( 'builder', 'handover' ) ),
				self::item( 'specific-class-names', $struct, array( 'Class names are specific, not generic', 'שמות המחלקות ספציפיים ולא גנריים' ), 'Inspect the classes applied in the builder. Names must describe the component precisely (for example hero__title, not title or box). Generic names collide across templates and break future edits.', 'major', 'agent', array( 'builder', 'css' ) ),
				self::item( 'no-styling-on-builtin-classes', $struct, array( 'No styles added to built-in framework classes', 'לא נוספו עיצובים למחלקות מובנות של הפריימוורק' ), 'Confirm no custom styling has been attached to built-in Core Framework or Bricks classes. Styling those globally breaks other components and future framework updates; create a dedicated class instead.', 'major', 'agent', array( 'builder', 'css' ) ),
				self::item( 'templates-for-loops', $struct, array( 'Query loops use templates rather than inline markup', 'לולאות שאילתה משתמשות בתבניות ולא בקוד מוטמע' ), 'Check each query loop (posts, CPTs, related items). The loop item should render a reusable template, so one edit updates every listing.', 'major', 'agent', array( 'builder' ) ),
				self::item( 'form-required-fields', $forms, array( 'Only phone and email are required on forms', 'רק טלפון ואימייל הם שדות חובה בטפסים' ), 'Open each form and check the required flags. Phone and email are required; everything else is optional unless the client asked for it explicitly.', 'major', 'agent', array( 'forms' ) ),
				self::item( 'form-messages-hebrew', $forms, array( 'Form messages (success, error, validation) are in Hebrew', 'הודעות הטופס (הצלחה, שגיאה, ולידציה) בעברית' ), 'Submit each form correctly and incorrectly. Success, error and field-validation messages must all appear in Hebrew, not the plugin default English.', 'major', 'browser', array( 'forms', 'hebrew' ) ),
				self::item( 'form-font-size-16', $forms, array( 'Form field font size is 16px', 'גודל הגופן בשדות הטופס הוא 16 פיקסלים' ), 'Inspect the computed font-size of form inputs. It must be 16px — smaller values make iOS Safari zoom in when a field is focused.', 'minor', 'agent', array( 'forms', 'mobile' ) ),
				self::item( 'form-post-submit-design', $forms, array( 'The state after sending a message is designed, not raw', 'המצב לאחר שליחת ההודעה מעוצב ולא גולמי' ), 'Submit a form and look at what the visitor sees afterwards. The confirmation must be styled to match the site, not an unstyled default message.', 'major', 'browser', array( 'forms', 'design' ) ),
				self::item( 'form-consent-checkbox', $forms, array( 'Privacy/terms consent checkbox present with the agreed Hebrew wording', 'תיבת אישור מדיניות פרטיות ותקנון עם הנוסח העברי המוסכם' ), 'Every public form needs the consent checkbox reading: קראתי והסכמתי למדיניות הפרטיות ולתקנון האתר — with both phrases linked to the real policy pages.', 'major', 'browser', array( 'forms', 'legal', 'hebrew' ) ),
				self::item( 'form-submissions-saved', $forms, array( 'All form submissions are saved to the database', 'כל שליחות הטפסים נשמרות במסד הנתונים' ), 'Confirm form submission storage is enabled for every form, then submit a test entry and verify the row appears in the submissions list. Delete the test entry afterwards.', 'blocker', 'agent', array( 'forms', 'data' ) ),
				self::item( 'no-auto-movement', $motion, array( 'No auto-playing movement anywhere on the site', 'אין תנועה אוטומטית בשום מקום באתר' ), 'Check every slider, carousel, marquee and animated section. Nothing may move by itself — the client considers auto-movement annoying and has asked for a fast, still site. Autoplay must be off everywhere.', 'blocker', 'browser', array( 'sliders', 'motion' ) ),
				self::item( 'sliders-fade-effect', $motion, array( 'Sliders use the fade effect', 'הסליידרים משתמשים באפקט מעבר הדרגתי' ), 'Where a slider is used, confirm the transition is set to fade rather than slide.', 'minor', 'browser', array( 'sliders' ) ),
				self::item( 'testimonials-native-element', $motion, array( 'Testimonials use the Bricks testimonials element', 'המלצות משתמשות באלמנט ההמלצות של Bricks' ), 'Confirm testimonials are built with the native Bricks testimonials element. Only fall back to a nested slider when a special requirement demands it, and keep it as simple as possible.', 'minor', 'agent', array( 'builder' ) ),
				self::item( 'cpt-hebrew-labels', $cpt, array( 'Custom post types are labelled in Hebrew', 'סוגי התוכן המותאמים מתויגים בעברית' ), 'Check each registered CPT. The admin labels the client sees must be Hebrew and meaningful, so the WordPress menu reads naturally to them.', 'major', 'agent', array( 'cpt', 'hebrew' ) ),
				self::item( 'meta-fields-hebrew-labels', $cpt, array( 'Meta field names are Hebrew, slugs are English', 'שמות שדות המטא בעברית, המזהים באנגלית' ), 'For every meta field: the display name shown in the editor is Hebrew, the slug/key stays English and lowercase. Mixed-language slugs break dynamic tags.', 'major', 'agent', array( 'cpt', 'hebrew' ) ),
				self::item( 'cpt-organized', $cpt, array( 'CPTs and fields are organised with meaningful names', 'סוגי התוכן והשדות מאורגנים בשמות בעלי משמעות' ), 'Review the CPT and field structure as a whole. Grouping and naming should be logical enough that the client can add content without help.', 'minor', 'agent', array( 'cpt', 'handover' ) ),
				self::item( 'related-posts-title', $pages, array( 'Related posts section carries the agreed Hebrew title', 'לאזור הפוסטים הקשורים יש הכותרת העברית המוסכמת' ), 'The related-posts block must be titled: עוד מידע שיכול לעניין אותך', 'minor', 'browser', array( 'content', 'hebrew' ) ),
				self::item( 'single-video-conditional', $pages, array( 'Single template video block renders conditionally', 'בלוק הווידאו בתבנית הבודדת מוצג בתנאי' ), 'On the single post/CPT template, the video element must be wrapped in a condition so it only renders when a video is actually set. An empty player must never show.', 'major', 'agent', array( 'templates' ) ),
				self::item( 'single-gallery-conditional', $pages, array( 'Single template gallery renders conditionally', 'הגלריה בתבנית הבודדת מוצגת בתנאי' ), 'Same as the video block: the gallery must only render when images exist, so entries without a gallery do not show an empty area.', 'major', 'agent', array( 'templates' ) ),
				self::item( 'search-visibility-staging', $pages, array( 'Search engine visibility matches the environment', 'נראות במנועי חיפוש תואמת לסביבה' ), 'If the site is on the final domain, "Discourage search engines" must be unchecked. If it is still on a staging domain, leave it checked. State which environment you checked.', 'blocker', 'agent', array( 'seo' ) ),
			),
		);
	}

	private static function final_delivery() {
		$nav    = array( 'Navigation', 'ניווט' );
		$pages  = array( 'Pages', 'עמודים' );
		$lang   = array( 'Language & RTL', 'שפה וכיוון' );
		$final  = array( 'Final Pass', 'בדיקה סופית' );

		return array(
			'slug'        => 'nexxen-final-delivery',
			'name'        => 'Final Check Before Delivery',
			'name_he'     => 'בדיקה סופית לפני מסירה',
			'description' => 'The last pass before the link goes to the delivery group: offcanvas menu, policy and utility pages, Hebrew everywhere, and a full incognito review.',
			'category'    => 'nexxen',
			'source'      => 'builtin',
			'sort_order'  => 30,
			'items'       => array(
				self::item( 'offcanvas-mobile-menu', $nav, array( 'Offcanvas menu is used on responsive devices', 'תפריט offcanvas בשימוש במכשירים ניידים' ), 'At tablet and mobile widths, confirm the menu opens as an offcanvas panel, closes cleanly, and its links work.', 'major', 'browser', array( 'nav', 'mobile' ) ),
				self::item( 'external-links-new-tab', $nav, array( 'External links open in a new tab', 'קישורים חיצוניים נפתחים בלשונית חדשה' ), 'Crawl the rendered pages for links pointing to other domains and confirm each has target="_blank" (with rel="noopener"). Internal links must stay in the same tab.', 'minor', 'agent', array( 'links' ) ),
				self::item( 'scroll-padding', $nav, array( 'Scroll padding is set so anchors are not hidden by the sticky header', 'הוגדר ריפוד גלילה כדי שהעוגנים לא יוסתרו על ידי ההדר הדביק' ), 'Click each in-page anchor link. The target heading must land below the sticky header, not behind it — set scroll-padding-top to the header height.', 'minor', 'browser', array( 'nav', 'css' ) ),
				self::item( 'policy-pages-added', $pages, array( 'Privacy policy and terms pages exist and are linked', 'עמודי מדיניות פרטיות ותקנון קיימים ומקושרים' ), 'Confirm both pages exist with the real Hebrew content (not placeholders) and are linked from the footer.', 'blocker', 'agent', array( 'legal' ) ),
				self::item( 'cookie-policy-added', $pages, array( 'Cookie notice is in place', 'הודעת עוגיות מוטמעת' ), 'Confirm the cookie banner/notice appears, matches the tracking actually running on the site, and links to the privacy policy.', 'major', 'browser', array( 'legal' ) ),
				self::item( 'utility-pages-styled', $pages, array( 'Thank-you, login and forgot-password pages are adjusted', 'עמודי תודה, התחברות ושחזור סיסמה הותאמו' ), 'Visit the thank-you page, wp-login and the forgot-password screen. Each must be branded and in Hebrew rather than left as WordPress defaults.', 'major', 'browser', array( 'pages' ) ),
				self::item( 'forgot-password-title', $pages, array( 'Forgot-password page uses the agreed Hebrew title', 'עמוד שחזור הסיסמה משתמש בכותרת העברית המוסכמת' ), 'The page title must read: שכחת את הסיסמה שלך?', 'minor', 'browser', array( 'pages', 'hebrew' ) ),
				self::item( '404-page-language', $pages, array( '404 page is in Hebrew and on-brand', 'עמוד 404 בעברית ובשפת המותג' ), 'Request a nonsense URL. The 404 page must return HTTP 404, use the site design, be written in Hebrew, and link back to useful pages.', 'major', 'agent', array( 'pages', 'hebrew' ) ),
				self::item( 'copyright-line', $final, array( 'Footer copyright line matches the agreed format', 'שורת זכויות היוצרים בפוטר תואמת לפורמט המוסכם' ), 'The footer must read: בניית אתר קבוצת נועדים © [שם האתר] — with בניית אתר linked to https://1000shekel.com/ and the site name pulled from site-wide details. Check every site for this.', 'major', 'browser', array( 'legal', 'hebrew' ) ),
				self::item( 'admin-hebrew-throughout', $lang, array( 'WordPress admin reads in Hebrew for the client', 'ממשק הניהול של וורדפרס בעברית עבור הלקוח' ), 'Log in as the client role and walk the admin menu: CPT names, taxonomies, meta boxes and the builder should all read in Hebrew.', 'major', 'agent', array( 'hebrew', 'handover' ) ),
				self::item( 'rtl-layout-correct', $lang, array( 'RTL layout is correct across all pages', 'פריסת RTL תקינה בכל העמודים' ), 'Review every page for direction bugs: text alignment, icon and arrow direction, list bullets, sliders, form labels, and any element whose padding/margin was written left/right instead of logical start/end.', 'blocker', 'browser', array( 'rtl', 'hebrew' ) ),
				self::item( 'deactivate-advanced-themer', $final, array( 'Advanced Themer for Bricks is deactivated', 'התוסף Advanced Themer עבור Bricks מבוטל' ), 'Advanced Themer is a development-only tool. Confirm it is deactivated before delivery.', 'major', 'agent', array( 'plugins' ) ),
				self::item( 'extra-themes-removed', $final, array( 'Unused themes are removed', 'ערכות עיצוב שאינן בשימוש הוסרו' ), 'List installed themes. Keep the active theme (and a child theme if used); delete the rest.', 'minor', 'agent', array( 'themes' ) ),
				self::item( 'incognito-full-review', $final, array( 'Whole site reviewed in incognito mode before sending the link', 'האתר כולו נבדק במצב גלישה בסתר לפני שליחת הקישור' ), 'Open a fresh incognito window and walk the entire site as a logged-out visitor: every page, every form, every link. Caching and admin-only styling hide problems when you are logged in. This is the last gate before the delivery group.', 'blocker', 'browser', array( 'qa' ) ),
			),
		);
	}

	private static function ecommerce() {
		$cart  = array( 'Cart & Add to Cart', 'עגלה והוספה לעגלה' );
		$price = array( 'Pricing', 'תמחור' );
		$legal = array( 'Required Pages', 'עמודים נדרשים' );

		return array(
			'slug'        => 'nexxen-ecommerce',
			'name'        => 'E-commerce (WooCommerce)',
			'name_he'     => 'חנות מקוונת (WooCommerce)',
			'description' => 'Store-specific requirements: cart behaviour, quantity controls in RTL, shekel formatting, and the three pages every Israeli store must publish.',
			'category'    => 'nexxen',
			'source'      => 'builtin',
			'sort_order'  => 40,
			'items'       => array(
				self::item( 'cart-reveal', $cart, array( 'Cart reveals when a product is added', 'העגלה נחשפת בעת הוספת מוצר' ), 'Add a product from the shop and single product pages. The cart should reveal itself so the customer sees the item landed.', 'major', 'browser', array( 'woocommerce' ) ),
				self::item( 'add-to-cart-ajax-minibar', $cart, array( 'Add to cart is AJAX with a mini-cart', 'הוספה לעגלה מתבצעת ב-AJAX עם מיני-עגלה' ), 'Adding to cart must not reload the page; the mini-cart count and contents must update in place.', 'major', 'browser', array( 'woocommerce' ) ),
				self::item( 'quantity-field-present', $cart, array( 'Quantity selector is present', 'בורר הכמות קיים' ), 'Confirm a quantity control appears on the product page (and in the cart) for every purchasable product.', 'major', 'browser', array( 'woocommerce' ) ),
				self::item( 'plus-sign-right', $cart, array( 'Plus (+) sits on the right of the quantity control', 'סימן הפלוס (+) ממוקם בצד ימין של בורר הכמות' ), 'In the RTL layout, the increment (+) button must be on the right-hand side of the quantity field.', 'minor', 'browser', array( 'woocommerce', 'rtl' ) ),
				self::item( 'minus-sign-left', $cart, array( 'Minus (−) sits on the left of the quantity control', 'סימן המינוס (−) ממוקם בצד שמאל של בורר הכמות' ), 'In the RTL layout, the decrement (−) button must be on the left-hand side of the quantity field.', 'minor', 'browser', array( 'woocommerce', 'rtl' ) ),
				self::item( 'shekel-symbol-left', $price, array( 'Shekel symbol appears to the left of the amount', 'סמל השקל מופיע משמאל לסכום' ), 'Check the WooCommerce currency position and the rendered prices: the ₪ symbol must sit on the left of the number.', 'major', 'agent', array( 'woocommerce', 'rtl' ) ),
				self::item( 'shekel-spacing', $price, array( 'A space separates the shekel symbol from the amount', 'רווח מפריד בין סמל השקל לסכום' ), 'Prices must render with a space between ₪ and the figure, on the shop, product, cart and checkout pages.', 'minor', 'browser', array( 'woocommerce' ) ),
				self::item( 'store-accessibility-statement', $legal, array( 'Accessibility statement page published', 'עמוד הצהרת נגישות פורסם' ), 'Every store must publish הצהרת נגישות with the studio standard Hebrew text and the client contact details filled in from site-wide details.', 'blocker', 'agent', array( 'legal', 'a11y' ) ),
				self::item( 'store-privacy-policy', $legal, array( 'Privacy policy page published', 'עמוד מדיניות פרטיות פורסם' ), 'Every store must publish מדיניות פרטיות, updated for Amendment 13 to the Israeli Privacy Protection Law, with real contact details at the end.', 'blocker', 'agent', array( 'legal' ) ),
				self::item( 'store-terms-of-use', $legal, array( 'Terms of use page published', 'עמוד תנאי שימוש פורסם' ), 'Every store must publish תנאי שימוש / תקנון האתר with the site name filled in and the purchase, cancellation and jurisdiction clauses present.', 'blocker', 'agent', array( 'legal' ) ),
			),
		);
	}

	private static function legal_pages() {
		$content = array( 'Content', 'תוכן' );
		$link    = array( 'Linking', 'קישורים' );

		return array(
			'slug'        => 'nexxen-legal-accessibility',
			'name'        => 'Legal & Accessibility Pages',
			'name_he'     => 'עמודי חוק ונגישות',
			'description' => 'The Hebrew legal set every Nexxen site ships with: accessibility statement, privacy policy and site terms — real content, real contact details, correctly linked.',
			'category'    => 'nexxen',
			'source'      => 'builtin',
			'sort_order'  => 50,
			'items'       => array(
				self::item( 'accessibility-statement-published', $content, array( 'Accessibility statement published with the studio text', 'הצהרת נגישות פורסמה עם נוסח הסטודיו' ), 'Publish הצהרת נגישות using the studio standard Hebrew text, covering the accessibility menu, the WCAG 2.1 and Israeli standard reference, and the list of available adjustments.', 'blocker', 'agent', array( 'legal', 'a11y', 'hebrew' ) ),
				self::item( 'accessibility-coordinator-details', $content, array( 'Accessibility coordinator details are real and dynamic', 'פרטי רכז הנגישות אמיתיים ודינמיים' ), 'The statement must end with the coordinator name, phone, email and postal address pulled from site-wide details — never left as template placeholders — plus the physical accessibility arrangements and the last-updated date.', 'blocker', 'agent', array( 'legal', 'a11y' ) ),
				self::item( 'accessibility-widget-active', $content, array( 'Accessibility menu widget is installed and working', 'תפריט הנגישות מותקן ופועל' ), 'Load the site as a visitor, open the accessibility menu and confirm the adjustments actually apply: keyboard navigation, contrast, font sizing, link and heading highlighting, cursor size.', 'blocker', 'browser', array( 'a11y' ) ),
				self::item( 'privacy-policy-published', $content, array( 'Privacy policy published and current with Amendment 13', 'מדיניות פרטיות פורסמה ומעודכנת לתיקון 13' ), 'Publish מדיניות פרטיות covering data collected, purposes, sensitive data, the privacy officer, user rights, cookies and security — in the Amendment 13 wording — and append the client contact details.', 'blocker', 'agent', array( 'legal' ) ),
				self::item( 'terms-published', $content, array( 'Site terms published with the site name filled in', 'תקנון האתר פורסם עם שם האתר מוזן' ), 'Publish תקנון האתר. Confirm the opening line names the actual site rather than leaving the bracketed placeholder, and that all nine clauses are present.', 'blocker', 'agent', array( 'legal' ) ),
				self::item( 'legal-pages-linked-footer', $link, array( 'All legal pages are linked in the footer', 'כל עמודי החוק מקושרים בפוטר' ), 'Confirm the footer links to the accessibility statement, privacy policy and site terms, that every link resolves (no 404), and that the anchor text is the Hebrew page name.', 'major', 'agent', array( 'legal', 'links' ) ),
				self::item( 'legal-pages-noindex-choice', $link, array( 'Legal pages indexing is a deliberate choice', 'הגדרת האינדוקס לעמודי החוק היא בחירה מודעת' ), 'Check the robots meta on the legal pages and record whether they are indexed intentionally. Either answer is acceptable; an accidental setting is not.', 'minor', 'agent', array( 'legal', 'seo' ) ),
			),
		);
	}

	/* =====================================================================
	 * General QA checklists
	 * ================================================================== */

	private static function frontend_design() {
		$header = array( 'Header & Navigation', 'הדר וניווט' );
		$btn    = array( 'Buttons & Links', 'כפתורים וקישורים' );
		$type   = array( 'Colours & Typography', 'צבעים וטיפוגרפיה' );
		$layout = array( 'Layout & Spacing', 'פריסה ומרווחים' );
		$resp   = array( 'Responsive', 'רספונסיביות' );
		$media  = array( 'Media', 'מדיה' );
		$inter  = array( 'Interactions', 'אינטראקציות' );

		return array(
			'slug'        => 'frontend-design-qa',
			'name'        => 'Front-end Design QA',
			'name_he'     => 'בקרת איכות עיצוב' ,
			'description' => 'Visual and interaction consistency across the site: header, buttons, colours, typography, spacing, responsive behaviour.',
			'category'    => 'frontend',
			'source'      => 'builtin',
			'sort_order'  => 60,
			'items'       => array(
				self::item( 'sticky-header', $header, array( 'Header is sticky on scroll (unless the client requested otherwise)', 'ההדר דביק בגלילה (אלא אם הלקוח ביקש אחרת)' ), 'Load the homepage and one inner page in a browser. Scroll down at least two viewport heights and confirm the header stays visible (position sticky or fixed, no jump/flicker). If the client explicitly requested a non-sticky header, mark N/A with a note.', 'major', 'browser', array( 'header' ) ),
				self::item( 'sticky-header-mobile', $header, array( 'Sticky header behaves correctly on mobile', 'ההדר הדביק מתנהג כראוי במובייל' ), 'At a 375px viewport, scroll and confirm the header does not cover too much of the screen, does not overlap content, and the mobile menu still opens while scrolled.', 'major', 'browser', array( 'header', 'mobile' ) ),
				self::item( 'logo-links-home', $header, array( 'Logo links to the homepage', 'הלוגו מקושר לדף הבית' ), 'On an inner page, click the header logo and confirm it navigates to the site root.', 'minor', 'browser', array( 'header' ) ),
				self::item( 'menu-active-state', $header, array( 'Current page is highlighted in the navigation', 'העמוד הנוכחי מודגש בתפריט' ), 'Visit two or three top-level pages and confirm the active menu item is visually distinguished (colour, underline or weight).', 'minor', 'browser', array( 'header' ) ),
				self::item( 'mobile-menu-works', $header, array( 'Mobile menu opens, closes and links work', 'תפריט המובייל נפתח, נסגר והקישורים פועלים' ), 'At a 375px viewport open the hamburger menu, confirm it opens and closes cleanly, submenus expand, links navigate, and the page behind does not scroll while the menu is open.', 'blocker', 'browser', array( 'header', 'mobile' ) ),
				self::item( 'buttons-consistent', $btn, array( 'Button styles are consistent site-wide', 'סגנון הכפתורים אחיד בכל האתר' ), 'Compare buttons across the homepage, an inner page and any forms. Primary buttons should share the same background, border-radius, padding and font. Secondary/outline buttons should be one consistent alternative style, not a new style per page.', 'major', 'browser', array( 'buttons', 'consistency' ) ),
				self::item( 'button-hover-consistent', $btn, array( 'Button hover colour is consistent', 'צבע המעבר על הכפתורים אחיד' ), 'Hover every distinct button on the homepage and two inner pages. All primary buttons should share one hover treatment (same colour shift/transition). Flag any button whose hover colour differs from the rest.', 'major', 'browser', array( 'buttons', 'consistency' ) ),
				self::item( 'link-hover-states', $btn, array( 'Text links have visible hover/focus states', 'לקישורי טקסט יש מצבי מעבר ומיקוד נראים' ), 'Hover and keyboard-focus in-content text links; confirm a visible state change (colour or underline) so links are discoverable.', 'minor', 'browser', array( 'links' ) ),
				self::item( 'no-dead-links', $btn, array( 'No dead or placeholder links', 'אין קישורים מתים או זמניים' ), 'Crawl rendered HTML of the main pages for href="#", href="" and links to staging URLs or missing pages. Every CTA must point at a real destination. Check footer and legal links too.', 'blocker', 'agent', array( 'links' ) ),
				self::item( 'global-colors-used', $type, array( 'Global colour variables are used correctly', 'משתני הצבע הגלובליים בשימוש נכון' ), 'Inspect the builder global colours (e.g. Bricks/Core Framework palette) and sample rendered pages. Brand colours in content should reference the global palette variables, not hard-coded one-off hex values. Flag sections whose colours are close-but-not-equal to the palette.', 'major', 'agent', array( 'colors', 'consistency' ) ),
				self::item( 'heading-scale-consistent', $type, array( 'Heading sizes follow one consistent scale', 'גדלי הכותרות עוקבים אחר סקאלה אחידה' ), 'Compare H1/H2/H3 sizes across pages. The same heading level should render at the same size and weight everywhere unless a section intentionally differs.', 'major', 'browser', array( 'typography' ) ),
				self::item( 'one-h1-per-page', $type, array( 'Each page has exactly one H1', 'לכל עמוד יש בדיוק כותרת H1 אחת' ), 'Fetch the rendered HTML of every main page and count H1 elements. Exactly one per page.', 'major', 'agent', array( 'typography', 'seo' ) ),
				self::item( 'font-loading-clean', $type, array( 'Fonts load without flashes or fallbacks', 'הגופנים נטענים ללא הבהובים או גופני גיבוי' ), 'Load pages with cache disabled and watch for FOUT/wrong fallback fonts. Confirm only the intended font families load (no leftover theme fonts) and that the Hebrew font renders correctly, including final letters and punctuation.', 'minor', 'browser', array( 'typography', 'performance', 'hebrew' ) ),
				self::item( 'section-spacing-consistent', $layout, array( 'Section spacing is consistent', 'המרווח בין המקטעים אחיד' ), 'Scroll every main page and compare vertical gaps between sections. Spacing should come from a consistent scale; flag sections that are noticeably cramped or double-spaced.', 'major', 'browser', array( 'layout', 'consistency' ) ),
				self::item( 'no-horizontal-scroll', $layout, array( 'No horizontal scrollbar at any breakpoint', 'אין גלילה אופקית בשום רזולוציה' ), 'At 1440px, 1024px, 768px and 375px widths, confirm the page never scrolls sideways and no element overflows the viewport.', 'blocker', 'browser', array( 'layout', 'responsive' ) ),
				self::item( 'alignment-clean', $layout, array( 'Content aligns to the grid', 'התוכן מיושר לרשת' ), 'Check that headings, text blocks and images line up with the container edges, and columns share equal heights/gutters where intended.', 'minor', 'browser', array( 'layout' ) ),
				self::item( 'responsive-key-breakpoints', $resp, array( 'Key pages verified at mobile, tablet and desktop', 'עמודי המפתח נבדקו במובייל, טאבלט ודסקטופ' ), 'Review homepage plus the most important inner pages at 375px, 768px and 1280px+. Confirm layouts reflow properly: no overlapping text, no giant images, columns stack in a sensible order.', 'blocker', 'browser', array( 'responsive' ) ),
				self::item( 'touch-targets', $resp, array( 'Tap targets are large enough on mobile', 'אזורי הלחיצה גדולים מספיק במובייל' ), 'On mobile widths confirm buttons and menu links are comfortably tappable (roughly 44px targets) and not placed too close together.', 'minor', 'browser', array( 'responsive', 'accessibility' ) ),
				self::item( 'images-not-distorted', $media, array( 'No stretched, squashed or pixelated images', 'אין תמונות מתוחות, דחוסות או מפוקסלות' ), 'Scan main pages for images with wrong aspect ratio or visibly low resolution (especially logos and team photos, and retina displays).', 'major', 'browser', array( 'media' ) ),
				self::item( 'hero-images-optimized', $media, array( 'Hero/LCP images are appropriately sized and compressed', 'תמונות ההירו דחוסות ובגודל מתאים' ), 'Check the byte size and dimensions of above-the-fold images on key pages. They should be modern formats (WebP/AVIF) served near their display size, not multi-megabyte originals.', 'major', 'agent', array( 'media', 'performance' ) ),
				self::item( 'animations-smooth', $inter, array( 'Animations are smooth and unobtrusive', 'האנימציות חלקות ולא מפריעות' ), 'Scroll pages with entrance animations. Confirm nothing flickers, jumps (layout shift), animates twice, or stays invisible because a trigger never fired.', 'major', 'browser', array( 'interactions' ) ),
				self::item( 'hover-cards-consistent', $inter, array( 'Card and image hover effects are consistent', 'אפקטי המעבר על כרטיסים ותמונות אחידים' ), 'Where cards/portfolio items have hover effects, confirm one consistent effect is used across a grid, and the whole card is clickable if it looks clickable.', 'minor', 'browser', array( 'interactions', 'consistency' ) ),
			),
		);
	}

	private static function plugins_backend() {
		$upd  = array( 'Updates', 'עדכונים' );
		$hyg  = array( 'Plugin hygiene', 'תחזוקת תוספים' );
		$set  = array( 'Settings', 'הגדרות' );
		$usr  = array( 'Users & access', 'משתמשים והרשאות' );
		$idx  = array( 'Search & indexing', 'חיפוש ואינדוקס' );
		$safe = array( 'Safety net', 'רשת ביטחון' );

		return array(
			'slug'        => 'plugins-backend-qa',
			'name'        => 'Plugins & Backend QA',
			'name_he'     => 'בקרת תוספים וצד שרת',
			'description' => 'WordPress configuration, plugin hygiene, updates, users and backup readiness before handover.',
			'category'    => 'backend',
			'source'      => 'builtin',
			'sort_order'  => 70,
			'items'       => array(
				self::item( 'core-plugins-updated', $upd, array( 'WordPress core, theme and plugins are up to date', 'ליבת וורדפרס, הערכה והתוספים מעודכנים' ), 'List core version, theme and plugin update status (e.g. via MCP site abilities or the Updates screen). Everything should be current, or a note recorded for anything intentionally held back.', 'major', 'agent', array( 'updates' ) ),
				self::item( 'unused-plugins-removed', $hyg, array( 'Unused plugins are deactivated AND deleted', 'תוספים שאינם בשימוש בוטלו ונמחקו' ), 'List installed plugins. Any deactivated plugin should be deleted unless there is a documented reason to keep it. Flag overlapping plugins doing the same job (e.g. two SEO or two cache plugins).', 'major', 'agent', array( 'plugins' ) ),
				self::item( 'licenses-active', $hyg, array( 'Premium plugin/theme licenses are activated', 'רישיונות התוספים והערכות בתשלום מופעלים' ), 'Check license status for premium products (builder, addons, forms). Licenses should be active so updates keep flowing after handover.', 'major', 'agent', array( 'plugins' ) ),
				self::item( 'nexxen-stack-installed', $hyg, array( 'The Nexxen standard plugin stack is installed and configured', 'ערכת התוספים הסטנדרטית של Nexxen מותקנת ומוגדרת' ), 'Confirm the standard Nexxen Studio plugins for this site type are present and configured (builder, forms, SEO, performance, security, SMTP). Record any deliberate omissions.', 'major', 'agent', array( 'plugins', 'nexxen' ) ),
				self::item( 'admin-email-correct', $set, array( 'Admin email and site title/tagline are correct', 'אימייל המנהל וכותרת האתר נכונים' ), 'Check Settings > General: admin email should be a monitored address (not a developer placeholder), site title correct, tagline set or intentionally empty.', 'major', 'agent', array( 'settings' ) ),
				self::item( 'timezone-locale', $set, array( 'Timezone, date format and language are correct', 'אזור הזמן, תבנית התאריך והשפה נכונים' ), 'Confirm the timezone is the Israel timezone (Asia/Jerusalem) unless the client is elsewhere, the site language is Hebrew, and date/time formats read naturally in Hebrew.', 'minor', 'agent', array( 'settings', 'hebrew' ) ),
				self::item( 'permalinks-clean', $set, array( 'Permalinks use a clean structure', 'מבנה הקישורים הקבועים נקי' ), 'Permalink structure should be "Post name" (or the agreed structure) and URLs should not contain ?p= IDs.', 'major', 'agent', array( 'settings' ) ),
				self::item( 'comments-configured', $set, array( 'Comments/pingbacks disabled unless the site needs them', 'תגובות ופינגבקים מבוטלים אלא אם נדרשים' ), 'For brochure sites, discussion should be off and existing pages should not show comment forms. Pingbacks/trackbacks disabled.', 'minor', 'agent', array( 'settings' ) ),
				self::item( 'media-sizes-sane', $set, array( 'Media settings and upload hygiene are sane', 'הגדרות המדיה והעלאות תקינות' ), 'Spot-check the media library for enormous originals and confirm image sizes/regeneration are configured as intended.', 'minor', 'agent', array( 'media' ) ),
				self::item( 'user-accounts-clean', $usr, array( 'User accounts are cleaned up with correct roles', 'חשבונות המשתמשים נוקו וההרשאות נכונות' ), 'List users. Remove or demote leftover developer/test accounts, confirm the client account exists with the right role, and no user is named "admin" with a weak setup.', 'major', 'agent', array( 'users', 'security' ) ),
				self::item( 'search-engine-visibility', $idx, array( '"Discourage search engines" is OFF (on production)', 'האפשרות "הסתר ממנועי חיפוש" כבויה (בייצור)' ), 'Check Settings > Reading. On the live site the discourage-indexing option must be unchecked, and robots.txt must not block the whole site.', 'blocker', 'agent', array( 'seo' ) ),
				self::item( 'backups-configured', $safe, array( 'Backups are configured and a restore point exists', 'גיבויים מוגדרים וקיימת נקודת שחזור' ), 'Confirm the hosting/backup solution covers this site, a recent backup exists, and note where restores happen.', 'blocker', 'agent', array( 'backups' ) ),
				self::item( 'security-basics', $safe, array( 'Security basics are in place', 'יסודות האבטחה מוטמעים' ), 'Confirm login protection (limit attempts/2FA where agreed), no directory listing, file editing disabled (DISALLOW_FILE_EDIT) where appropriate, and the security plugin (if any) is configured, not just installed.', 'major', 'agent', array( 'security' ) ),
				self::item( 'no-debug-output', $safe, array( 'Debug mode is off and no PHP notices leak to the front-end', 'מצב ניפוי שגיאות כבוי ואין הודעות PHP בחזית' ), 'WP_DEBUG should be false (or logging only) on production. Load key pages and confirm no PHP warnings/notices are visible in HTML.', 'blocker', 'agent', array( 'settings' ) ),
			),
		);
	}

	private static function go_live() {
		$dom   = array( 'Domain & SSL', 'דומיין ואבטחה' );
		$forms = array( 'Forms & email', 'טפסים ודוא"ל' );
		$perf  = array( 'Performance', 'ביצועים' );
		$pages = array( 'Pages & errors', 'עמודים ושגיאות' );
		$track = array( 'Tracking & monitoring', 'מדידה וניטור' );
		$redir = array( 'Redirects', 'הפניות' );

		return array(
			'slug'        => 'go-live-launch',
			'name'        => 'Go-Live / Launch',
			'name_he'     => 'עלייה לאוויר',
			'description' => 'The final pre-launch and launch-day pass: domain, SSL, forms and email deliverability, caching, redirects, analytics and monitoring.',
			'category'    => 'launch',
			'source'      => 'builtin',
			'sort_order'  => 80,
			'items'       => array(
				self::item( 'ssl-valid-forced', $dom, array( 'SSL certificate is valid and HTTPS is forced', 'תעודת SSL תקפה ו-HTTPS נאכף' ), 'Request the site over http:// and confirm a 301 redirect to https://. Confirm the certificate is valid, covers www/non-www as used, and no mixed-content warnings appear on key pages.', 'blocker', 'agent', array( 'ssl' ) ),
				self::item( 'canonical-host', $dom, array( 'One canonical host (www or non-www) with redirects', 'דומיין קנוני יחיד (עם או בלי www) עם הפניות' ), 'Request both www and non-www variants; one must 301 to the other consistently, matching the canonical URLs in the sitemap.', 'major', 'agent', array( 'domain', 'seo' ) ),
				self::item( 'staging-urls-gone', $dom, array( 'No staging URLs left in content, settings or CSS', 'לא נותרו כתובות סטייג׳ינג בתוכן, בהגדרות או ב-CSS' ), 'Search the database and rendered HTML for the staging domain (e.g. *.hostingersite.com). Site URL, content links, image sources and generated CSS/font files must all reference the live domain.', 'blocker', 'agent', array( 'domain' ) ),
				self::item( 'forms-submit', $forms, array( 'Every form submits successfully', 'כל הטפסים נשלחים בהצלחה' ), 'Submit each form on the site with test data. Confirm success messages in Hebrew, no console/validation errors, and entries stored where applicable. Remove the test entries afterwards.', 'blocker', 'browser', array( 'forms' ) ),
				self::item( 'email-delivery-proven', $forms, array( 'Form notifications actually reach a real inbox', 'התראות הטפסים מגיעות בפועל לתיבת דואר אמיתית' ), 'Do not trust "message sent". Confirm SMTP (not PHP mail) is configured, send a real test submission, and verify the notification arrives at the client address — check spam. Confirm the from-address matches the domain (SPF/DKIM aligned).', 'blocker', 'manual', array( 'forms', 'email' ) ),
				self::item( 'form-spam-protection', $forms, array( 'Forms have spam protection', 'לטפסים יש הגנה מפני ספאם' ), 'Confirm honeypot/turnstile/recaptcha is active on public forms and does not block normal submissions.', 'major', 'agent', array( 'forms' ) ),
				self::item( 'caching-active', $perf, array( 'Caching is enabled and verified', 'מטמון מופעל ואומת' ), 'Confirm the caching layer is active: request a page twice and verify a cache HIT header on the second request. Confirm logged-in/admin requests bypass the cache.', 'major', 'agent', array( 'performance' ) ),
				self::item( 'performance-baseline', $perf, array( 'Performance baseline recorded (mobile and desktop)', 'נרשם בסיס ביצועים (מובייל ודסקטופ)' ), 'Run PageSpeed/Lighthouse for the homepage and one key inner page on mobile and desktop. Record scores and LCP/CLS as the launch baseline.', 'major', 'agent', array( 'performance' ) ),
				self::item( '404-page-styled', $pages, array( 'A styled 404 page exists', 'קיים עמוד 404 מעוצב' ), 'Request a nonsense URL and confirm the 404 page uses the site design, returns HTTP 404, is written in Hebrew, and links back to useful pages.', 'minor', 'agent', array( 'pages' ) ),
				self::item( 'legal-pages-present', $pages, array( 'Privacy/cookie/terms pages exist and are linked', 'עמודי פרטיות, עוגיות ותקנון קיימים ומקושרים' ), 'Confirm required legal pages exist with real content and are linked from the footer. Cookie consent (if required) works and matches actual tracking.', 'major', 'browser', array( 'legal' ) ),
				self::item( 'favicon-set', $pages, array( 'Favicon and site icon are set', 'סמל האתר (favicon) הוגדר' ), 'Load the site and check the browser tab icon; confirm the site icon is configured (not the default) at all sizes.', 'minor', 'agent', array( 'branding' ) ),
				self::item( 'analytics-installed', $track, array( 'Analytics is installed and receiving data', 'מערכת האנליטיקס מותקנת וקולטת נתונים' ), 'Confirm the agreed analytics (GA4/Fathom/etc.) fires exactly once per page view (no duplicate tags) and a realtime test visit is recorded.', 'major', 'agent', array( 'tracking' ) ),
				self::item( 'search-console-connected', $track, array( 'Search Console is verified and sitemap submitted', 'Search Console אומת ומפת האתר הוגשה' ), 'Confirm the property is verified for the live domain and the XML sitemap has been submitted without errors.', 'major', 'manual', array( 'seo', 'tracking' ) ),
				self::item( 'uptime-monitoring', $track, array( 'Uptime monitoring covers the live domain', 'ניטור זמינות מכסה את הדומיין החי' ), 'Confirm the site is in the monitoring system and alerts go to a monitored channel.', 'minor', 'manual', array( 'monitoring' ) ),
				self::item( 'old-site-redirects', $redir, array( 'Old/changed URLs redirect to their new equivalents', 'כתובות ישנות מופנות לכתובות החדשות המקבילות' ), 'If the site replaces an older site or URLs changed, confirm 301 redirects map important old URLs (from Search Console/analytics) to the correct new pages, not just to the homepage.', 'major', 'agent', array( 'seo', 'redirects' ) ),
			),
		);
	}

	private static function seo_content() {
		$meta    = array( 'Metadata', 'מטא-דאטה' );
		$index   = array( 'Indexing', 'אינדוקס' );
		$content = array( 'Content', 'תוכן' );

		return array(
			'slug'        => 'seo-content-qa',
			'name'        => 'SEO & Content QA',
			'name_he'     => 'בקרת קידום ותוכן',
			'description' => 'On-page SEO, metadata, social sharing and content quality: no placeholders, correct titles, sensible descriptions.',
			'category'    => 'seo',
			'source'      => 'builtin',
			'sort_order'  => 90,
			'items'       => array(
				self::item( 'meta-titles-unique', $meta, array( 'Every key page has a unique, sensible meta title', 'לכל עמוד מפתח כותרת מטא ייחודית והגיונית' ), 'Fetch each main page and read the <title>. Titles should be unique, descriptive, in Hebrew, include the brand, and not be raw defaults like "Home - Sitename".', 'major', 'agent', array( 'seo' ) ),
				self::item( 'meta-descriptions', $meta, array( 'Key pages have meta descriptions', 'לעמודי המפתח יש תיאורי מטא' ), 'Check each main page for a meta description of reasonable length that actually describes the page, written in Hebrew.', 'major', 'agent', array( 'seo' ) ),
				self::item( 'og-tags-set', $meta, array( 'Social sharing (Open Graph) image and tags work', 'תגיות ותמונת שיתוף (Open Graph) פועלות' ), 'Check og:title/og:description/og:image on key pages, and confirm the OG image exists, loads and looks correct (e.g. via a share preview).', 'minor', 'agent', array( 'seo', 'social' ) ),
				self::item( 'sitemap-valid', $index, array( 'XML sitemap exists, is valid and matches live URLs', 'מפת אתר XML קיימת, תקפה ותואמת לכתובות החיות' ), 'Fetch the sitemap URL; confirm it returns 200, lists live-domain URLs only, and excludes junk (tag archives, test pages).', 'major', 'agent', array( 'seo' ) ),
				self::item( 'robots-txt-sane', $index, array( 'robots.txt allows crawling and references the sitemap', 'קובץ robots.txt מאפשר סריקה ומפנה למפת האתר' ), 'Fetch /robots.txt: it must not Disallow: / on production and should reference the sitemap.', 'blocker', 'agent', array( 'seo' ) ),
				self::item( 'no-index-leaks', $index, array( 'No stray noindex on public pages; utility pages excluded', 'אין noindex מיותר בעמודים ציבוריים' ), 'Check key pages for unexpected noindex robots meta. Thank-you/utility pages should be noindexed intentionally.', 'major', 'agent', array( 'seo' ) ),
				self::item( 'no-placeholder-content', $content, array( 'No lorem ipsum or placeholder content anywhere', 'אין תוכן זמני או לורם איפסום באתר' ), 'Search rendered pages (and search the database) for "lorem", "ipsum", "placeholder", "dummy", "your text here", template-default headings, and unfinished sections. Check Hebrew placeholder text too.', 'blocker', 'agent', array( 'content' ) ),
				self::item( 'no-placeholder-images', $content, array( 'No placeholder or stock-frame images left', 'לא נותרו תמונות זמניות או תמונות דמו' ), 'Scan pages for obvious placeholder images (grey boxes, "image coming soon", builder demo images).', 'major', 'browser', array( 'content', 'media' ) ),
				self::item( 'contact-details-correct', $content, array( 'Phone numbers, addresses and emails are real and consistent', 'מספרי טלפון, כתובות ואימיילים אמיתיים ועקביים' ), 'Verify contact details against the client brief everywhere they appear (header, footer, contact page, schema). Phone links use tel:, emails use mailto: and are correct.', 'blocker', 'agent', array( 'content' ) ),
				self::item( 'spelling-grammar', $content, array( 'Spelling and grammar pass on all main pages', 'איות ודקדוק תקינים בכל העמודים הראשיים' ), 'Proofread rendered Hebrew page text for typos, broken sentences, double spaces, mixed direction in numbers and Latin words, and inconsistent spelling of the brand name.', 'major', 'agent', array( 'content', 'hebrew' ) ),
				self::item( 'image-alt-seo', $content, array( 'Images have descriptive filenames and alt text', 'לתמונות יש שמות קבצים ותיאורי alt מתארים' ), 'Sample content images: filenames should be descriptive and in English (not IMG_1234.jpg), and alt attributes present and meaningful in Hebrew on meaningful images.', 'minor', 'agent', array( 'seo', 'media', 'accessibility' ) ),
				self::item( 'schema-basics', $content, array( 'Basic structured data is present and valid', 'נתונים מובנים בסיסיים קיימים ותקפים' ), 'Check Organization/LocalBusiness schema (name, logo, address) validates without errors where applicable.', 'minor', 'agent', array( 'seo' ) ),
			),
		);
	}

	private static function accessibility() {
		$vis  = array( 'Visual', 'חזותי' );
		$kbd  = array( 'Keyboard', 'מקלדת' );
		$form = array( 'Forms', 'טפסים' );
		$sem  = array( 'Semantics', 'סמנטיקה' );
		$mot  = array( 'Motion', 'תנועה' );

		return array(
			'slug'        => 'accessibility-basics',
			'name'        => 'Accessibility Basics',
			'name_he'     => 'יסודות נגישות',
			'description' => 'A pragmatic pass informed by WCAG 2.1 and the Israeli accessibility standard: contrast, keyboard, focus, labels and semantics. Not a full audit, but no obvious failures.',
			'category'    => 'accessibility',
			'source'      => 'builtin',
			'sort_order'  => 100,
			'items'       => array(
				self::item( 'contrast-passes', $vis, array( 'Text colour contrast meets WCAG AA', 'ניגודיות הטקסט עומדת בתקן WCAG AA' ), 'Sample body text, headings, buttons and text over images/hero overlays. Normal text needs 4.5:1 contrast, large text 3:1. Flag light-grey-on-white text and text on busy images without an overlay.', 'major', 'agent', array( 'a11y' ) ),
				self::item( 'focus-visible', $kbd, array( 'Keyboard focus is visible on all interactive elements', 'מיקוד המקלדת נראה בכל האלמנטים האינטראקטיביים' ), 'Tab through the header, menu, links, buttons and forms. Every focused element must show a visible outline/state; focus must not be trapped or vanish.', 'major', 'browser', array( 'a11y' ) ),
				self::item( 'keyboard-operable', $kbd, array( 'Menus, sliders and modals work with keyboard only', 'תפריטים, סליידרים וחלונות קופצים פועלים במקלדת בלבד' ), 'Operate the mobile/desktop menu, any carousels, accordions and popups using only the keyboard (Tab/Enter/Escape). Everything interactive must be reachable and closable. In RTL, confirm the arrow keys move in the direction the user expects.', 'major', 'browser', array( 'a11y', 'rtl' ) ),
				self::item( 'form-labels', $form, array( 'All form fields have proper labels', 'לכל שדות הטופס יש תוויות תקינות' ), 'Inspect form HTML: every input needs an associated label (or aria-label), placeholders are not the only label, and error messages are announced next to the field.', 'major', 'agent', array( 'a11y', 'forms' ) ),
				self::item( 'alt-text-meaningful', $sem, array( 'Meaningful images have alt text; decorative images have empty alt', 'לתמונות משמעותיות יש alt; לתמונות דקורטיביות alt ריק' ), 'Check img tags across main pages: content images need descriptive alt, decorative ones alt="", and no missing alt attributes.', 'major', 'agent', array( 'a11y', 'media' ) ),
				self::item( 'heading-hierarchy', $sem, array( 'Heading levels are hierarchical (no skipped levels for styling)', 'רמות הכותרות היררכיות (ללא דילוג לצורכי עיצוב)' ), 'Extract the heading outline of key pages. Levels should nest logically (H1 > H2 > H3) rather than being chosen for their font size.', 'minor', 'agent', array( 'a11y', 'typography' ) ),
				self::item( 'lang-dir-attributes', $sem, array( 'html lang and dir attributes are correct', 'תגיות lang ו-dir תקינות ב-HTML' ), 'Fetch the rendered HTML and confirm the <html> element carries lang="he-IL" (or the correct Hebrew locale) and dir="rtl". Screen readers switch voice and reading direction from these.', 'major', 'agent', array( 'a11y', 'hebrew', 'rtl' ) ),
				self::item( 'motion-respect', $mot, array( 'Animations respect prefers-reduced-motion where heavy', 'האנימציות מכבדות את העדפת צמצום התנועה' ), 'If the site uses significant motion, confirm it is disabled or reduced when prefers-reduced-motion is set, and nothing flashes rapidly.', 'minor', 'browser', array( 'a11y', 'interactions' ) ),
				self::item( 'icon-buttons-labelled', $sem, array( 'Icon-only buttons/links have accessible names', 'לכפתורי אייקון יש שמות נגישים' ), 'Check hamburger buttons, social icons, slider arrows and close buttons for aria-label or visually hidden text, written in Hebrew.', 'minor', 'agent', array( 'a11y' ) ),
			),
		);
	}
}
