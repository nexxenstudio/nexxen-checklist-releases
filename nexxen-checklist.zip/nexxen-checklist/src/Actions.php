<?php
namespace Nexxen_Checklist;

defined( 'ABSPATH' ) || exit;

/**
 * Business logic shared by the REST controller (dashboard) and the Abilities
 * API (Novamira MCP). Every method accepts one input array and returns the
 * standard envelope: success, status, data, warnings.
 */
final class Actions {

	private $store;

	/**
	 * Optional factory returning an Engine\AutoCheck; lets tests inject a
	 * fake HTTP fetcher.
	 */
	public $engine_factory = null;

	public function __construct( Store $store = null ) {
		$this->store = $store ? $store : new Store();
	}

	private function engine() {
		return is_callable( $this->engine_factory ) ? call_user_func( $this->engine_factory ) : new Engine\AutoCheck();
	}

	private function ok( $status, array $data, array $warnings = array() ) {
		return array(
			'success'  => true,
			'status'   => $status,
			'data'     => $data,
			'warnings' => $warnings,
		);
	}

	private function fail( $status, $message ) {
		return array(
			'success'  => false,
			'status'   => $status,
			'data'     => array( 'message' => $message ),
			'warnings' => array(),
		);
	}

	/* ---------------------------------------------------------------------
	 * Checklists
	 * ------------------------------------------------------------------ */

	public function list_checklists( array $input = array() ) {
		$checklists = $this->store->get_checklists( $input );
		$out        = array();
		foreach ( $checklists as $checklist ) {
			$enabled = 0;
			$auto    = 0;
			$supported = Engine\AutoCheck::supported_ids();
			foreach ( $checklist['items'] as $item ) {
				if ( ! empty( $item['enabled'] ) ) {
					$enabled++;
				}
				if ( in_array( $item['id'], $supported, true ) ) {
					$auto++;
				}
			}
			$out[] = array(
				'id'          => $checklist['id'],
				'slug'        => $checklist['slug'],
				'name'        => $checklist['name'],
				'name_he'     => isset( $checklist['name_he'] ) ? $checklist['name_he'] : '',
				'description' => $checklist['description'],
				'category'    => $checklist['category'],
				'source'      => $checklist['source'],
				'item_count'  => count( $checklist['items'] ),
				'enabled_count' => $enabled,
				'auto_count'  => $auto,
				'updated_at'  => $checklist['updated_at'],
			);
		}
		return $this->ok( 'ok', array( 'checklists' => $out, 'total' => count( $out ) ) );
	}

	public function get_checklist( array $input = array() ) {
		$ref = $this->checklist_ref( $input );
		if ( null === $ref ) {
			return $this->fail( 'invalid-input', 'Provide "checklist" (slug or numeric id).' );
		}
		$checklist = $this->store->get_checklist( $ref );
		if ( ! $checklist ) {
			return $this->fail( 'not-found', 'No checklist found for: ' . $ref );
		}
		$supported = Engine\AutoCheck::supported_ids();
		$auto      = array();
		foreach ( $checklist['items'] as $item ) {
			if ( in_array( $item['id'], $supported, true ) ) {
				$auto[] = $item['id'];
			}
		}
		return $this->ok( 'ok', array( 'checklist' => $checklist, 'auto_checkable' => $auto ) );
	}

	public function create_checklist( array $input = array() ) {
		if ( empty( $input['name'] ) ) {
			return $this->fail( 'invalid-input', 'A checklist "name" is required.' );
		}
		if ( ! empty( $input['slug'] ) && $this->store->get_checklist( sanitize_title( $input['slug'] ) ) ) {
			return $this->fail( 'duplicate', 'A checklist with that slug already exists. Use update-checklist instead.' );
		}
		$items = isset( $input['items'] ) ? (array) $input['items'] : array();
		foreach ( $items as &$item ) {
			if ( is_array( $item ) ) {
				$item['custom'] = true;
			}
		}
		unset( $item );
		$checklist = $this->store->save_checklist(
			array(
				'slug'        => isset( $input['slug'] ) ? $input['slug'] : '',
				'name'        => $input['name'],
				'description' => isset( $input['description'] ) ? $input['description'] : '',
				'category'    => isset( $input['category'] ) ? $input['category'] : 'general',
				'source'      => 'custom',
				'items'       => $items,
				'sort_order'  => isset( $input['sort_order'] ) ? (int) $input['sort_order'] : 100,
			)
		);
		return $this->ok( 'created', array( 'checklist' => $checklist ) );
	}

	/**
	 * Updates name/description/category and supports three item operations:
	 * items (full replace), add_items (append), update_item (patch one by id),
	 * remove_item_ids (delete by id).
	 */
	public function update_checklist( array $input = array() ) {
		$ref = $this->checklist_ref( $input );
		if ( null === $ref ) {
			return $this->fail( 'invalid-input', 'Provide "checklist" (slug or numeric id).' );
		}
		$checklist = $this->store->get_checklist( $ref );
		if ( ! $checklist ) {
			return $this->fail( 'not-found', 'No checklist found for: ' . $ref );
		}

		foreach ( array( 'name', 'name_he', 'description', 'category', 'sort_order' ) as $field ) {
			if ( isset( $input[ $field ] ) ) {
				$checklist[ $field ] = $input[ $field ];
			}
		}

		$items = $checklist['items'];

		if ( isset( $input['items'] ) && is_array( $input['items'] ) ) {
			$items = $input['items'];
		}

		if ( ! empty( $input['add_items'] ) && is_array( $input['add_items'] ) ) {
			foreach ( $input['add_items'] as $new_item ) {
				if ( is_array( $new_item ) ) {
					$new_item['custom'] = true;
					$items[]            = $new_item;
				}
			}
		}

		if ( ! empty( $input['update_item'] ) && is_array( $input['update_item'] ) && ! empty( $input['update_item']['id'] ) ) {
			$patch = $input['update_item'];
			$found = false;
			foreach ( $items as &$item ) {
				if ( isset( $item['id'] ) && $item['id'] === $patch['id'] ) {
					$item  = array_merge( $item, $patch );
					$item['custom'] = true;
					$found = true;
					break;
				}
			}
			unset( $item );
			if ( ! $found ) {
				return $this->fail( 'not-found', 'No item with id "' . $patch['id'] . '" in this checklist.' );
			}
		}

		if ( ! empty( $input['remove_item_ids'] ) && is_array( $input['remove_item_ids'] ) ) {
			$remove = array_map( 'strval', $input['remove_item_ids'] );
			$items  = array_values(
				array_filter(
					$items,
					static function ( $item ) use ( $remove ) {
						return ! isset( $item['id'] ) || ! in_array( (string) $item['id'], $remove, true );
					}
				)
			);
		}

		$checklist['items'] = $items;
		$saved              = $this->store->save_checklist( $checklist );
		return $this->ok( 'updated', array( 'checklist' => $saved ) );
	}

	public function delete_checklist( array $input = array() ) {
		$ref = $this->checklist_ref( $input );
		if ( null === $ref ) {
			return $this->fail( 'invalid-input', 'Provide "checklist" (slug or numeric id).' );
		}
		$checklist = $this->store->get_checklist( $ref );
		if ( ! $checklist ) {
			return $this->fail( 'not-found', 'No checklist found for: ' . $ref );
		}
		if ( 'builtin' === $checklist['source'] && empty( $input['confirm_builtin'] ) ) {
			return $this->fail( 'confirmation-required', 'This is a built-in Nexxen Studio checklist. Pass confirm_builtin=true to delete it (restore-builtin-checklists can bring it back).' );
		}
		$this->store->delete_checklist( $checklist['id'] );
		return $this->ok( 'deleted', array( 'deleted' => $checklist['slug'] ) );
	}

	public function restore_builtin_checklists( array $input = array() ) {
		Installer::seed_library();
		return $this->list_checklists();
	}

	/**
	 * Full checklist as portable JSON, for moving between sites.
	 */
	public function export_checklist( array $input = array() ) {
		$ref = $this->checklist_ref( $input );
		if ( null === $ref ) {
			return $this->fail( 'invalid-input', 'Provide "checklist" (slug or numeric id).' );
		}
		$checklist = $this->store->get_checklist( $ref );
		if ( ! $checklist ) {
			return $this->fail( 'not-found', 'No checklist found for: ' . $ref );
		}
		unset( $checklist['id'], $checklist['created_at'], $checklist['updated_at'] );
		$checklist['exported_from'] = home_url();
		$checklist['exported_at']   = current_time( 'mysql', true );
		return $this->ok( 'ok', array( 'checklist' => $checklist ) );
	}

	/**
	 * Imports an exported checklist. Same slug updates in place (that is what
	 * makes "edit once, push to every site" work); new slug creates.
	 */
	public function import_checklist( array $input = array() ) {
		$data = isset( $input['checklist'] ) && is_array( $input['checklist'] ) ? $input['checklist'] : $input;
		if ( empty( $data['name'] ) || empty( $data['items'] ) || ! is_array( $data['items'] ) ) {
			return $this->fail( 'invalid-input', 'The import needs at least "name" and a non-empty "items" array. Use a file produced by Export.' );
		}
		$slug     = ! empty( $data['slug'] ) ? sanitize_title( $data['slug'] ) : sanitize_title( $data['name'] );
		$existing = $slug ? $this->store->get_checklist( $slug ) : null;
		$saved    = $this->store->save_checklist(
			array(
				'slug'        => $slug,
				'name'        => (string) $data['name'],
				'name_he'     => isset( $data['name_he'] ) ? (string) $data['name_he'] : '',
				'description' => isset( $data['description'] ) ? (string) $data['description'] : '',
				'category'    => isset( $data['category'] ) ? (string) $data['category'] : 'general',
				'source'      => $existing && 'builtin' === $existing['source'] ? 'builtin' : 'custom',
				'items'       => (array) $data['items'],
				'sort_order'  => isset( $data['sort_order'] ) ? (int) $data['sort_order'] : 100,
			)
		);
		return $this->ok( $existing ? 'updated' : 'created', array( 'checklist' => $saved, 'replaced' => (bool) $existing ) );
	}

	/* ---------------------------------------------------------------------
	 * Runs
	 * ------------------------------------------------------------------ */

	public function start_run( array $input = array() ) {
		$ref = $this->checklist_ref( $input );
		if ( null === $ref ) {
			return $this->fail( 'invalid-input', 'Provide "checklist" (slug or numeric id).' );
		}
		$checklist = $this->store->get_checklist( $ref );
		if ( ! $checklist ) {
			return $this->fail( 'not-found', 'No checklist found for: ' . $ref );
		}
		$user = wp_get_current_user();
		$run  = $this->store->create_run(
			$checklist,
			isset( $input['label'] ) ? (string) $input['label'] : '',
			$user && $user->ID ? $user->user_login : 'system'
		);
		if ( ! $run ) {
			return $this->fail( 'error', 'The run could not be created.' );
		}
		$scope = $this->auto_scope( $run );
		return $this->ok(
			'started',
			array(
				'run'          => $this->run_with_progress( $run, $checklist ),
				'auto_pending' => count( $scope['pending'] ),
				'hint'         => 'Run run-auto-checks first (' . count( $scope['pending'] ) . ' of ' . count( $run['results'] ) . ' items are auto-checkable), then loop get-next-items / record-item-result for the rest.',
			)
		);
	}

	public function list_runs( array $input = array() ) {
		$limit = isset( $input['limit'] ) ? (int) $input['limit'] : 20;
		$runs  = $this->store->list_runs( $limit );
		$out   = array();
		foreach ( $runs as $run ) {
			$out[] = $this->run_with_progress( $run, null, false );
		}
		return $this->ok( 'ok', array( 'runs' => $out, 'total' => count( $out ) ) );
	}

	public function get_run( array $input = array() ) {
		$run = $this->require_run( $input );
		if ( is_array( $run ) && isset( $run['success'] ) ) {
			return $run;
		}
		$checklist = $this->store->get_checklist( $run['checklist_id'] );
		$scope     = $this->auto_scope( $run );
		return $this->ok( 'ok', array(
			'run'            => $this->run_with_progress( $run, $checklist ),
			'auto_checkable' => $scope['all'],
			'auto_pending'   => count( $scope['pending'] ),
		) );
	}

	/**
	 * Returns the next pending items together with their full instructions —
	 * this is the ability an agent loops on to work through a run.
	 */
	public function get_next_items( array $input = array() ) {
		$run = $this->require_run( $input );
		if ( is_array( $run ) && isset( $run['success'] ) ) {
			return $run;
		}
		$limit     = isset( $input['limit'] ) ? max( 1, min( 20, (int) $input['limit'] ) ) : 5;
		$checklist = $this->store->get_checklist( $run['checklist_id'] );
		$items_by_id = array();
		if ( $checklist ) {
			foreach ( $checklist['items'] as $item ) {
				$items_by_id[ $item['id'] ] = $item;
			}
		}
		$next = array();
		foreach ( $run['results'] as $result ) {
			if ( 'pending' !== $result['status'] ) {
				continue;
			}
			$item   = isset( $items_by_id[ $result['item_id'] ] ) ? $items_by_id[ $result['item_id'] ] : array( 'id' => $result['item_id'], 'title' => $result['item_id'] );
			$next[] = $item;
			if ( count( $next ) >= $limit ) {
				break;
			}
		}
		$progress = $this->progress( $run );
		return $this->ok(
			$next ? 'ok' : 'run-complete',
			array(
				'run_id'    => $run['run_id'],
				'progress'  => $progress,
				'items'     => $next,
				'hint'      => $next
					? 'Check each item following how_to_check, then call record-item-result with run_id, item_id, status (pass|fail|na|skipped), notes and evidence.'
					: 'All items are recorded. Call complete-run to compute the readiness summary and final report.',
			)
		);
	}

	/**
	 * Records one result or a batch. Accepts either item_id/status pairs at the
	 * top level or a results[] array of {item_id, status, notes, evidence}.
	 */
	public function record_item_result( array $input = array() ) {
		$run = $this->require_run( $input );
		if ( is_array( $run ) && isset( $run['success'] ) ) {
			return $run;
		}
		if ( 'in-progress' !== $run['status'] ) {
			return $this->fail( 'run-closed', 'This run is ' . $run['status'] . '. Start a new run to record results.' );
		}

		$updates = array();
		if ( ! empty( $input['results'] ) && is_array( $input['results'] ) ) {
			$updates = $input['results'];
		} elseif ( ! empty( $input['item_id'] ) ) {
			$updates[] = array(
				'item_id'  => $input['item_id'],
				'status'   => isset( $input['status'] ) ? $input['status'] : '',
				'notes'    => isset( $input['notes'] ) ? $input['notes'] : '',
				'evidence' => isset( $input['evidence'] ) ? $input['evidence'] : '',
			);
		}
		if ( ! $updates ) {
			return $this->fail( 'invalid-input', 'Provide item_id + status, or a results[] batch.' );
		}

		$valid    = array( 'pass', 'fail', 'na', 'skipped', 'pending' );
		$user     = wp_get_current_user();
		$actor    = isset( $input['checked_by'] ) && '' !== $input['checked_by'] ? sanitize_text_field( $input['checked_by'] ) : ( $user && $user->ID ? $user->user_login : 'agent' );
		$now      = current_time( 'mysql', true );
		$applied  = array();
		$warnings = array();

		$results = $run['results'];
		foreach ( $updates as $update ) {
			if ( ! is_array( $update ) || empty( $update['item_id'] ) ) {
				continue;
			}
			$status = isset( $update['status'] ) ? strtolower( (string) $update['status'] ) : '';
			if ( ! in_array( $status, $valid, true ) ) {
				$warnings[] = 'Skipped "' . $update['item_id'] . '": invalid status "' . $status . '". Use pass|fail|na|skipped.';
				continue;
			}
			$found = false;
			foreach ( $results as &$result ) {
				if ( $result['item_id'] === $update['item_id'] ) {
					if ( isset( $update['assignee'] ) ) {
						$result['assignee'] = sanitize_text_field( (string) $update['assignee'] );
					}
					$result['status']     = $status;
					$result['notes']      = sanitize_textarea_field( isset( $update['notes'] ) ? (string) $update['notes'] : $result['notes'] );
					$result['evidence']   = sanitize_textarea_field( isset( $update['evidence'] ) ? (string) $update['evidence'] : $result['evidence'] );
					$result['checked_by'] = $actor;
					$result['checked_at'] = $now;
					$found                = true;
					$applied[]            = $update['item_id'];
					break;
				}
			}
			unset( $result );
			if ( ! $found ) {
				$warnings[] = 'Item "' . $update['item_id'] . '" is not part of this run.';
			}
		}

		$run = $this->store->update_run( $run['run_id'], array( 'results' => $results ) );
		return $this->ok(
			'recorded',
			array(
				'run_id'   => $run['run_id'],
				'applied'  => $applied,
				'progress' => $this->progress( $run ),
			),
			$warnings
		);
	}

	public function complete_run( array $input = array() ) {
		$run = $this->require_run( $input );
		if ( is_array( $run ) && isset( $run['success'] ) ) {
			return $run;
		}
		$checklist = $this->store->get_checklist( $run['checklist_id'] );
		$summary   = $this->summarize( $run, $checklist );
		$pending   = $summary['counts']['pending'];
		if ( $pending > 0 && empty( $input['force'] ) ) {
			return $this->fail( 'items-pending', $pending . ' item(s) are still pending. Record them (or pass force=true to complete anyway; pending items count as skipped).' );
		}
		$fields = array(
			'summary'      => $summary,
			'status'       => 'completed',
			'completed_at' => current_time( 'mysql', true ),
		);
		if ( empty( $run['share_token'] ) ) {
			$fields['share_token'] = strtolower( wp_generate_password( 32, false, false ) );
		}
		$run = $this->store->update_run( $run['run_id'], $fields );
		return $this->ok(
			'completed',
			array(
				'run_id'    => $run['run_id'],
				'summary'   => $summary,
				'share_url' => $this->share_url( $run ),
			)
		);
	}

	/**
	 * Public read-only report URL for a completed run.
	 */
	public function get_share_link( array $input = array() ) {
		$run = $this->require_run( $input );
		if ( is_array( $run ) && isset( $run['success'] ) ) {
			return $run;
		}
		if ( 'completed' !== $run['status'] ) {
			return $this->fail( 'run-open', 'Share links exist for completed runs only. Complete the run first.' );
		}
		if ( empty( $run['share_token'] ) ) {
			$run = $this->store->update_run( $run['run_id'], array( 'share_token' => strtolower( wp_generate_password( 32, false, false ) ) ) );
		}
		return $this->ok( 'ok', array( 'run_id' => $run['run_id'], 'share_url' => $this->share_url( $run ) ) );
	}

	private function share_url( array $run ) {
		return empty( $run['share_token'] ) ? '' : add_query_arg( 'nexxen-report', $run['share_token'], home_url( '/' ) );
	}

	/**
	 * Assigns one item of a run to a named person (free text, so it works
	 * without WordPress accounts for every teammate).
	 */
	public function assign_item( array $input = array() ) {
		$run = $this->require_run( $input );
		if ( is_array( $run ) && isset( $run['success'] ) ) {
			return $run;
		}
		if ( empty( $input['item_id'] ) ) {
			return $this->fail( 'invalid-input', 'Provide "item_id".' );
		}
		$assignee = isset( $input['assignee'] ) ? sanitize_text_field( (string) $input['assignee'] ) : '';
		$results  = $run['results'];
		$found    = false;
		foreach ( $results as &$result ) {
			if ( $result['item_id'] === $input['item_id'] ) {
				$result['assignee'] = $assignee;
				$found              = true;
				break;
			}
		}
		unset( $result );
		if ( ! $found ) {
			return $this->fail( 'not-found', 'Item "' . $input['item_id'] . '" is not part of this run.' );
		}
		$this->store->update_run( $run['run_id'], array( 'results' => $results ) );
		return $this->ok( 'assigned', array( 'run_id' => $run['run_id'], 'item_id' => $input['item_id'], 'assignee' => $assignee ) );
	}


	public function delete_run( array $input = array() ) {
		$run = $this->require_run( $input );
		if ( is_array( $run ) && isset( $run['success'] ) ) {
			return $run;
		}
		$this->store->delete_run( $run['run_id'] );
		return $this->ok( 'deleted', array( 'deleted' => $run['run_id'] ) );
	}

	public function get_run_report( array $input = array() ) {
		$run = $this->require_run( $input );
		if ( is_array( $run ) && isset( $run['success'] ) ) {
			return $run;
		}
		$checklist = $this->store->get_checklist( $run['checklist_id'] );
		$summary   = ! empty( $run['summary'] ) ? $run['summary'] : $this->summarize( $run, $checklist );
		$markdown  = $this->markdown_report( $run, $checklist, $summary );
		return $this->ok(
			'ok',
			array(
				'run_id'   => $run['run_id'],
				'summary'  => $summary,
				'markdown' => $markdown,
			)
		);
	}

	/* ---------------------------------------------------------------------
	 * Auto-check engine
	 * ------------------------------------------------------------------ */

	/**
	 * Runs the deterministic engine against every pending, enabled item of a
	 * run that the engine knows how to check, and records the results as
	 * checked_by "auto-engine". Items the engine cannot decide stay pending.
	 */
	public function run_auto_checks( array $input = array() ) {
		$run = $this->require_run( $input );
		if ( is_array( $run ) && isset( $run['success'] ) ) {
			return $run;
		}
		if ( 'in-progress' !== $run['status'] ) {
			return $this->fail( 'run-closed', 'This run is ' . $run['status'] . '.' );
		}
		$supported = Engine\AutoCheck::supported_ids();
		$targets   = array();
		foreach ( $run['results'] as $result ) {
			if ( 'pending' === $result['status'] && in_array( $result['item_id'], $supported, true ) ) {
				$targets[] = $result['item_id'];
			}
		}
		if ( ! $targets ) {
			return $this->ok( 'nothing-to-check', array(
				'run_id'  => $run['run_id'],
				'checked' => array(),
				'message' => 'No pending items in this run are auto-checkable. The remaining items need the agent or a human.',
			) );
		}
		$engine  = $this->engine();
		$results = $engine->run_for_items( $targets );
		$batch   = array();
		foreach ( $results as $item_id => $outcome ) {
			$batch[] = array(
				'item_id'  => $item_id,
				'status'   => $outcome['status'],
				'notes'    => $outcome['notes'],
				'evidence' => $outcome['evidence'],
			);
		}
		$recorded = $this->record_item_result( array(
			'run_id'     => $run['run_id'],
			'results'    => $batch,
			'checked_by' => 'auto-engine',
		) );
		$counts = array( 'pass' => 0, 'fail' => 0, 'skipped' => 0 );
		foreach ( $results as $outcome ) {
			if ( isset( $counts[ $outcome['status'] ] ) ) {
				$counts[ $outcome['status'] ]++;
			}
		}
		return $this->ok( 'checked', array(
			'run_id'   => $run['run_id'],
			'checked'  => array_keys( $results ),
			'counts'   => $counts,
			'progress' => isset( $recorded['data']['progress'] ) ? $recorded['data']['progress'] : null,
			'message'  => sprintf( 'Auto-engine checked %d item(s): %d pass, %d fail, %d inconclusive (left for review). Remaining pending items need the agent or a human.', count( $results ), $counts['pass'], $counts['fail'], $counts['skipped'] ),
		), isset( $recorded['warnings'] ) ? $recorded['warnings'] : array() );
	}

	/**
	 * Standalone drift scan: re-runs the live-site safety checks without a
	 * checklist run and stores the report (also executed weekly via cron).
	 */
	public function run_drift_scan( array $input = array() ) {
		$engine  = $this->engine();
		$results = $engine->run_for_items( Engine\AutoCheck::DRIFT_IDS );
		$failures = array();
		foreach ( $results as $item_id => $outcome ) {
			if ( 'fail' === $outcome['status'] ) {
				$failures[] = array( 'item_id' => $item_id, 'notes' => $outcome['notes'] );
			}
		}
		$report = array(
			'scanned_at' => current_time( 'mysql', true ),
			'results'    => $results,
			'failures'   => $failures,
			'trigger'    => ! empty( $input['trigger'] ) ? sanitize_key( $input['trigger'] ) : 'manual',
		);
		update_option( 'nexxen_checklist_drift', $report, false );
		return $this->ok( $failures ? 'drift-detected' : 'clean', array( 'report' => $report ) );
	}

	public function get_drift_report( array $input = array() ) {
		$report = get_option( 'nexxen_checklist_drift' );
		if ( ! is_array( $report ) || empty( $report['scanned_at'] ) ) {
			return $this->ok( 'never-scanned', array( 'report' => null, 'message' => 'No drift scan has run yet. Use run-drift-scan, or wait for the weekly cron.' ) );
		}
		return $this->ok( empty( $report['failures'] ) ? 'clean' : 'drift-detected', array( 'report' => $report ) );
	}

	/* ---------------------------------------------------------------------
	 * Overview + operator prompt
	 * ------------------------------------------------------------------ */

	public function get_overview( array $input = array() ) {
		$checklists = $this->store->get_checklists();
		$runs       = $this->store->list_runs( 10 );
		$last       = null;
		foreach ( $runs as $run ) {
			if ( 'completed' === $run['status'] ) {
				$last = $run;
				break;
			}
		}
		$out_runs = array();
		foreach ( $runs as $run ) {
			$out_runs[] = $this->run_with_progress( $run, null, false );
		}
		$drift = get_option( 'nexxen_checklist_drift' );
		return $this->ok(
			'ok',
			array(
				'site'            => home_url(),
				'plugin_version'  => NEXXEN_CHECKLIST_VERSION,
				'checklist_count' => count( $checklists ),
				'drift'           => is_array( $drift ) && ! empty( $drift['scanned_at'] ) ? $drift : null,
				'recent_runs'     => $out_runs,
				'last_completed'  => $last ? array(
					'run_id'  => $last['run_id'],
					'name'    => $last['checklist_name'],
					'summary' => $last['summary'],
					'completed_at' => $last['completed_at'],
				) : null,
			)
		);
	}

	public function get_operator_prompt( array $input = array() ) {
		$lists = $this->store->get_checklists();
		$names = array();
		foreach ( $lists as $list ) {
			$names[] = $list['slug'] . ' (' . $list['name'] . ', ' . count( $list['items'] ) . ' items)';
		}
		$prompt = "You are running a Nexxen Studio QA session on " . home_url() . ".\n"
			. "Context: Nexxen builds Hebrew, right-to-left WordPress sites. Checklist items are bilingual — `title` is English, `title_he` is the Hebrew the client sees. Report to the client in Hebrew when they work in Hebrew; the how_to_check instructions are always English.\n"
			. "Workflow:\n"
			. "1. list-checklists to see what is available. Current: " . implode( '; ', $names ) . ".\n"
			. "2. start-run with the chosen checklist slug (label it, e.g. 'Pre-launch 2026-08-11').\n"
			. "2b. run-auto-checks with the run_id first: the plugin's deterministic engine settles the mechanical items (options, HTTP status, sitemap, robots, staging URLs, meta tags) itself and records evidence, so you only handle what is left.\n"
			. "3. Loop: get-next-items (default 5 at a time), actually verify each item following its how_to_check instructions using your other tools (HTTP fetches, browser, site MCP abilities). Never mark an item pass without checking.\n"
			. "4. record-item-result for every item with status pass|fail|na|skipped, concrete notes, and evidence (URLs checked, values observed, screenshots taken).\n"
			. "5. complete-run when nothing is pending, then get-run-report and present the markdown report with the readiness score, blockers first.\n"
			. "Rules: fail honestly — a checklist exists to find problems. Use na only when an item genuinely does not apply (say why). Blocker fails mean the site is not ready to launch.";
		return $this->ok( 'ok', array( 'prompt' => $prompt, 'site' => home_url() ) );
	}

	/* ---------------------------------------------------------------------
	 * Internals
	 * ------------------------------------------------------------------ */

	private function checklist_ref( array $input ) {
		foreach ( array( 'checklist', 'checklist_id', 'slug', 'id' ) as $key ) {
			if ( isset( $input[ $key ] ) && '' !== $input[ $key ] ) {
				return is_numeric( $input[ $key ] ) ? (int) $input[ $key ] : (string) $input[ $key ];
			}
		}
		return null;
	}

	/**
	 * Returns the run array, or a failure envelope when missing.
	 */
	private function require_run( array $input ) {
		$run_id = isset( $input['run_id'] ) ? (string) $input['run_id'] : '';
		if ( '' === $run_id ) {
			return $this->fail( 'invalid-input', 'Provide "run_id".' );
		}
		$run = $this->store->get_run( $run_id );
		if ( ! $run ) {
			return $this->fail( 'not-found', 'No run found for: ' . $run_id );
		}
		return $run;
	}

	/**
	 * Auto-checkable item ids present in a run, split by whether they are
	 * still pending. Lets the dashboard label items and size the button.
	 */
	private function auto_scope( array $run ) {
		$supported = Engine\AutoCheck::supported_ids();
		$all       = array();
		$pending   = array();
		foreach ( $run['results'] as $result ) {
			if ( in_array( $result['item_id'], $supported, true ) ) {
				$all[] = $result['item_id'];
				if ( 'pending' === $result['status'] ) {
					$pending[] = $result['item_id'];
				}
			}
		}
		return array( 'all' => $all, 'pending' => $pending );
	}

	private function progress( array $run ) {
		$counts = array( 'pass' => 0, 'fail' => 0, 'na' => 0, 'skipped' => 0, 'pending' => 0 );
		foreach ( $run['results'] as $result ) {
			$status = isset( $counts[ $result['status'] ] ) ? $result['status'] : 'pending';
			$counts[ $status ]++;
		}
		$total = count( $run['results'] );
		$done  = $total - $counts['pending'];
		return array(
			'total'   => $total,
			'done'    => $done,
			'percent' => $total ? (int) round( 100 * $done / $total ) : 0,
			'counts'  => $counts,
		);
	}

	private function run_with_progress( array $run, $checklist = null, $include_results = true ) {
		$run['progress'] = $this->progress( $run );
		if ( ! $include_results ) {
			unset( $run['results'] );
		} elseif ( $checklist ) {
			$items_by_id = array();
			foreach ( $checklist['items'] as $item ) {
				$items_by_id[ $item['id'] ] = $item;
			}
			foreach ( $run['results'] as &$result ) {
				if ( isset( $items_by_id[ $result['item_id'] ] ) ) {
					$item                 = $items_by_id[ $result['item_id'] ];
					$result['title']      = $item['title'];
					$result['title_he']   = isset( $item['title_he'] ) ? $item['title_he'] : '';
					$result['section']    = $item['section'];
					$result['section_he'] = isset( $item['section_he'] ) ? $item['section_he'] : '';
					$result['severity']   = $item['severity'];
					$result['check_type'] = $item['check_type'];
					$result['how_to_check'] = isset( $item['how_to_check'] ) ? $item['how_to_check'] : '';
				}
			}
			unset( $result );
		}
		return $run;
	}

	/**
	 * Readiness scoring: pass/na count fully, minor fails cost little, blocker
	 * fails cap the verdict at not-ready regardless of the numeric score.
	 */
	private function summarize( array $run, $checklist ) {
		$items_by_id = array();
		if ( $checklist ) {
			foreach ( $checklist['items'] as $item ) {
				$items_by_id[ $item['id'] ] = $item;
			}
		}
		$counts  = array( 'pass' => 0, 'fail' => 0, 'na' => 0, 'skipped' => 0, 'pending' => 0 );
		$weights = array( 'blocker' => 5, 'major' => 3, 'minor' => 1 );
		$earned  = 0;
		$possible = 0;
		$failed_items = array();
		$blocker_fails = 0;

		foreach ( $run['results'] as $result ) {
			$status = isset( $counts[ $result['status'] ] ) ? $result['status'] : 'pending';
			$counts[ $status ]++;
			$item     = isset( $items_by_id[ $result['item_id'] ] ) ? $items_by_id[ $result['item_id'] ] : array();
			$severity = isset( $item['severity'] ) ? $item['severity'] : 'major';
			$weight   = isset( $weights[ $severity ] ) ? $weights[ $severity ] : 3;
			if ( 'na' === $status ) {
				continue; // Not applicable: excluded from the score entirely.
			}
			$possible += $weight;
			if ( 'pass' === $status ) {
				$earned += $weight;
			}
			if ( 'fail' === $status ) {
				if ( 'blocker' === $severity ) {
					$blocker_fails++;
				}
				$failed_items[] = array(
					'item_id'  => $result['item_id'],
					'title'    => isset( $item['title'] ) ? $item['title'] : $result['item_id'],
					'section'  => isset( $item['section'] ) ? $item['section'] : '',
					'severity' => $severity,
					'notes'    => $result['notes'],
				);
			}
		}

		$score = $possible ? (int) round( 100 * $earned / $possible ) : 0;
		if ( $blocker_fails > 0 ) {
			$verdict = 'not-ready';
		} elseif ( $counts['fail'] > 0 || $counts['pending'] > 0 || $counts['skipped'] > 0 ) {
			$verdict = 'review';
		} else {
			$verdict = 'ready';
		}

		usort(
			$failed_items,
			static function ( $a, $b ) {
				$order = array( 'blocker' => 0, 'major' => 1, 'minor' => 2 );
				return $order[ $a['severity'] ] - $order[ $b['severity'] ];
			}
		);

		return array(
			'counts'          => $counts,
			'readiness_score' => $score,
			'verdict'         => $verdict,
			'blocker_fails'   => $blocker_fails,
			'failed_items'    => $failed_items,
		);
	}

	private function markdown_report( array $run, $checklist, array $summary ) {
		$lines   = array();
		$lines[] = '# Nexxen Checklist report — ' . $run['checklist_name'];
		$lines[] = '';
		$lines[] = '- Site: ' . home_url();
		$lines[] = '- Run: `' . $run['run_id'] . '`' . ( $run['label'] ? ' (' . $run['label'] . ')' : '' );
		$lines[] = '- Started: ' . $run['started_at'] . ( $run['completed_at'] ? ' — completed: ' . $run['completed_at'] : ' (in progress)' );
		$lines[] = '- Readiness score: **' . $summary['readiness_score'] . '/100** — verdict: **' . strtoupper( $summary['verdict'] ) . '**';
		$counts  = $summary['counts'];
		$lines[] = '- Results: ' . $counts['pass'] . ' pass · ' . $counts['fail'] . ' fail · ' . $counts['na'] . ' n/a · ' . $counts['skipped'] . ' skipped · ' . $counts['pending'] . ' pending';
		$lines[] = '';

		if ( $summary['failed_items'] ) {
			$lines[] = '## Failures (fix these first)';
			foreach ( $summary['failed_items'] as $failure ) {
				$lines[] = '- **[' . strtoupper( $failure['severity'] ) . ']** ' . $failure['title'] . ( $failure['notes'] ? ' — ' . $failure['notes'] : '' );
			}
			$lines[] = '';
		}

		$items_by_id = array();
		if ( $checklist ) {
			foreach ( $checklist['items'] as $item ) {
				$items_by_id[ $item['id'] ] = $item;
			}
		}
		$by_section = array();
		foreach ( $run['results'] as $result ) {
			$item    = isset( $items_by_id[ $result['item_id'] ] ) ? $items_by_id[ $result['item_id'] ] : array();
			$section = isset( $item['section'] ) ? $item['section'] : 'General';
			$by_section[ $section ][] = array( $result, $item );
		}
		$lines[] = '## Full results';
		foreach ( $by_section as $section => $pairs ) {
			$lines[] = '';
			$lines[] = '### ' . $section;
			foreach ( $pairs as $pair ) {
				list( $result, $item ) = $pair;
				$icon  = array( 'pass' => 'x', 'fail' => ' ', 'na' => '-', 'skipped' => ' ', 'pending' => ' ' );
				$mark  = isset( $icon[ $result['status'] ] ) ? $icon[ $result['status'] ] : ' ';
				$title = isset( $item['title'] ) ? $item['title'] : $result['item_id'];
				$line  = '- [' . $mark . '] ' . $title . ' — **' . $result['status'] . '**';
				if ( $result['notes'] ) {
					$line .= ' · ' . $result['notes'];
				}
				$lines[] = $line;
			}
		}
		return implode( "\n", $lines );
	}
}
