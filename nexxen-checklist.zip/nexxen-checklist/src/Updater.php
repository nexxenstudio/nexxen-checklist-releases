<?php
namespace Nexxen_Checklist;

defined( 'ABSPATH' ) || exit;

/**
 * Self-updater. WordPress only auto-updates plugins hosted on wordpress.org,
 * so this class answers the twice-daily "any updates?" question itself by
 * reading a small JSON manifest from the public Nexxen Studio releases
 * repository. Source stays in the private repo; only finished zips and the
 * manifest are public.
 *
 * The manifest looks like:
 * {
 *   "version": "1.0.1",
 *   "requires": "6.5",
 *   "requires_php": "7.4",
 *   "tested": "6.8",
 *   "download_url": "https://github.com/.../nexxen-checklist.zip",
 *   "details_url": "https://github.com/nexxenstudio/nexxen-checklist-releases",
 *   "last_updated": "2026-08-11",
 *   "changelog": "<h4>1.0.1</h4><ul><li>...</li></ul>"
 * }
 *
 * Once a version with this class is installed, later releases appear on the
 * Plugins screen like any other update, and WordPress's per-plugin
 * "Enable auto-updates" toggle applies to them unmodified.
 */
final class Updater {

	/*
	 * The manifest is read via the "latest release" download path, which
	 * resolves to the newest release at request time. The raw.githubusercontent
	 * mirror used before 1.2.1 could serve a stale copy for several minutes
	 * after publishing, which made fresh releases invisible to force-checks.
	 */
	const MANIFEST_URL  = 'https://github.com/nexxenstudio/nexxen-checklist-releases/releases/latest/download/manifest.json';
	const CACHE_KEY     = 'nexxen_checklist_update_manifest';
	const CACHE_TTL     = 6 * HOUR_IN_SECONDS;
	const CACHE_ERR_TTL = HOUR_IN_SECONDS;

	public function boot() {
		add_filter( 'pre_set_site_transient_update_plugins', array( $this, 'inject_update' ) );
		add_filter( 'plugins_api', array( $this, 'plugin_details' ), 10, 3 );
		// After an update installs, clear the cache so the row disappears immediately.
		add_action( 'upgrader_process_complete', array( $this, 'flush_cache' ), 10, 0 );
		/*
		 * "Check again" on the Updates screen deletes WordPress's own
		 * update_plugins transient (wp_clean_update_cache). Piggy-back on that
		 * so a forced check also bypasses OUR manifest cache — otherwise a
		 * release published minutes ago stays invisible for up to six hours
		 * no matter how often the button is pressed.
		 */
		add_action( 'delete_site_transient_update_plugins', array( $this, 'flush_cache' ), 10, 0 );

		// "Check for updates" link on the Plugins screen row + its handler.
		add_filter( 'plugin_action_links_' . $this->basename(), array( $this, 'action_links' ) );
		add_action( 'admin_init', array( $this, 'handle_manual_check' ) );
		add_action( 'admin_notices', array( $this, 'manual_check_notice' ) );
	}

	public function action_links( $links ) {
		if ( current_user_can( 'update_plugins' ) ) {
			$url = wp_nonce_url( add_query_arg( 'nexxen-check-updates', '1', admin_url( 'plugins.php' ) ), 'nexxen-check-updates' );
			$links[] = '<a href="' . esc_url( $url ) . '">' . esc_html__( 'Check for updates', 'nexxen-checklist' ) . '</a>';
		}
		return $links;
	}

	/**
	 * Forces a fresh manifest fetch and a WordPress update recalculation, then
	 * redirects back with the outcome. The redirect strips the nonce from the
	 * URL so a reload does not re-trigger the check.
	 */
	public function handle_manual_check() {
		if ( ! isset( $_GET['nexxen-check-updates'] ) ) {
			return;
		}
		if ( ! current_user_can( 'update_plugins' ) || ! check_admin_referer( 'nexxen-check-updates' ) ) {
			return;
		}
		$this->flush_cache();
		$manifest = $this->manifest();
		wp_clean_update_cache();
		wp_update_plugins();

		if ( ! $manifest ) {
			$status = 'unreachable';
		} elseif ( version_compare( $manifest['version'], NEXXEN_CHECKLIST_VERSION, '>' ) ) {
			$status = 'available-' . $manifest['version'];
		} else {
			$status = 'latest';
		}
		wp_safe_redirect( add_query_arg( 'nexxen-update-status', rawurlencode( $status ), admin_url( 'plugins.php' ) ) );
		exit;
	}

	public function manual_check_notice() {
		if ( empty( $_GET['nexxen-update-status'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			return;
		}
		$status = sanitize_text_field( wp_unslash( $_GET['nexxen-update-status'] ) ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		if ( 'latest' === $status ) {
			$class   = 'notice-success';
			$message = sprintf( __( 'Nexxen Checklist %s is the latest version.', 'nexxen-checklist' ), NEXXEN_CHECKLIST_VERSION );
		} elseif ( 0 === strpos( $status, 'available-' ) ) {
			$class   = 'notice-info';
			$message = sprintf( __( 'Nexxen Checklist %s is available — use the update link in the plugin list below.', 'nexxen-checklist' ), substr( $status, 10 ) );
		} elseif ( 'unreachable' === $status ) {
			$class   = 'notice-error';
			$message = __( 'Nexxen Checklist could not reach the update server (GitHub). Check again in a few minutes; if it persists, the host may be blocking raw.githubusercontent.com.', 'nexxen-checklist' );
		} else {
			return;
		}
		echo '<div class="notice ' . esc_attr( $class ) . ' is-dismissible"><p>' . esc_html( $message ) . '</p></div>';
	}

	private function basename() {
		return plugin_basename( NEXXEN_CHECKLIST_FILE );
	}

	/**
	 * Manifest as an array, cached in a transient. Failures are cached briefly
	 * too, so a GitHub outage never means a manifest request on every
	 * admin page load.
	 */
	private function manifest() {
		$cached = get_site_transient( self::CACHE_KEY );
		if ( is_array( $cached ) ) {
			return isset( $cached['unreachable'] ) ? null : $cached;
		}

		$response = wp_remote_get(
			self::MANIFEST_URL,
			array(
				'timeout'    => 10,
				'user-agent' => 'Nexxen-Checklist/' . NEXXEN_CHECKLIST_VERSION . '; ' . home_url(),
			)
		);

		$manifest = null;
		if ( ! is_wp_error( $response ) && 200 === (int) wp_remote_retrieve_response_code( $response ) ) {
			$decoded = json_decode( (string) wp_remote_retrieve_body( $response ), true );
			if ( is_array( $decoded ) && ! empty( $decoded['version'] ) && ! empty( $decoded['download_url'] ) ) {
				// Only ever install from the Nexxen Studio releases repository.
				$host = wp_parse_url( (string) $decoded['download_url'], PHP_URL_HOST );
				if ( in_array( $host, array( 'github.com', 'raw.githubusercontent.com', 'objects.githubusercontent.com' ), true ) ) {
					$manifest = $decoded;
				}
			}
		}

		if ( null === $manifest ) {
			set_site_transient( self::CACHE_KEY, array( 'unreachable' => true ), self::CACHE_ERR_TTL );
			return null;
		}

		set_site_transient( self::CACHE_KEY, $manifest, self::CACHE_TTL );
		return $manifest;
	}

	public function flush_cache() {
		delete_site_transient( self::CACHE_KEY );
	}

	/**
	 * Adds our row to the update_plugins transient when the manifest version
	 * is newer than the installed one.
	 */
	public function inject_update( $transient ) {
		if ( ! is_object( $transient ) ) {
			return $transient;
		}
		$manifest = $this->manifest();
		if ( ! $manifest ) {
			return $transient;
		}

		$item = (object) array(
			'id'           => 'nexxen-checklist/nexxen-checklist',
			'slug'         => 'nexxen-checklist',
			'plugin'       => $this->basename(),
			'new_version'  => (string) $manifest['version'],
			'url'          => isset( $manifest['details_url'] ) ? (string) $manifest['details_url'] : '',
			'package'      => (string) $manifest['download_url'],
			'requires'     => isset( $manifest['requires'] ) ? (string) $manifest['requires'] : '',
			'requires_php' => isset( $manifest['requires_php'] ) ? (string) $manifest['requires_php'] : '',
			'tested'       => isset( $manifest['tested'] ) ? (string) $manifest['tested'] : '',
		);

		if ( version_compare( $manifest['version'], NEXXEN_CHECKLIST_VERSION, '>' ) ) {
			$transient->response[ $this->basename() ] = $item;
			unset( $transient->no_update[ $this->basename() ] );
		} else {
			// Registering in no_update keeps the auto-update toggle visible.
			$transient->no_update[ $this->basename() ] = $item;
			unset( $transient->response[ $this->basename() ] );
		}
		return $transient;
	}

	/**
	 * Backs the "View version x.x.x details" link on the Plugins screen.
	 */
	public function plugin_details( $result, $action, $args ) {
		if ( 'plugin_information' !== $action || ! isset( $args->slug ) || 'nexxen-checklist' !== $args->slug ) {
			return $result;
		}
		$manifest = $this->manifest();
		if ( ! $manifest ) {
			return $result;
		}
		return (object) array(
			'name'          => 'Nexxen Checklist',
			'slug'          => 'nexxen-checklist',
			'version'       => (string) $manifest['version'],
			'author'        => '<a href="https://nexxenstudio.com/">Nexxen Studio</a>',
			'homepage'      => 'https://nexxenstudio.com/',
			'requires'      => isset( $manifest['requires'] ) ? (string) $manifest['requires'] : '',
			'requires_php'  => isset( $manifest['requires_php'] ) ? (string) $manifest['requires_php'] : '',
			'tested'        => isset( $manifest['tested'] ) ? (string) $manifest['tested'] : '',
			'last_updated'  => isset( $manifest['last_updated'] ) ? (string) $manifest['last_updated'] : '',
			'download_link' => (string) $manifest['download_url'],
			'sections'      => array(
				'changelog' => isset( $manifest['changelog'] ) ? wp_kses_post( (string) $manifest['changelog'] ) : '',
			),
		);
	}
}
