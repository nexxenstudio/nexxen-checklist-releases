<?php
namespace Nexxen_Checklist;

defined( 'ABSPATH' ) || exit;

/**
 * Database access for checklists and runs. All item/result payloads are stored
 * as JSON so the schema stays flexible while the tables stay simple.
 */
final class Store {

	private function checklists_table() {
		global $wpdb;
		return $wpdb->prefix . 'nexxen_checklist_checklists';
	}

	private function runs_table() {
		global $wpdb;
		return $wpdb->prefix . 'nexxen_checklist_runs';
	}

	/* ---------------------------------------------------------------------
	 * Checklists
	 * ------------------------------------------------------------------ */

	public function get_checklists( array $args = array() ) {
		global $wpdb;
		$table = $this->checklists_table();
		$where = '1=1';
		$bind  = array();
		if ( ! empty( $args['category'] ) ) {
			$where .= ' AND category = %s';
			$bind[] = (string) $args['category'];
		}
		$sql = "SELECT * FROM {$table} WHERE {$where} ORDER BY sort_order ASC, id ASC";
		if ( $bind ) {
			$sql = $wpdb->prepare( $sql, $bind ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
		}
		$rows = $wpdb->get_results( $sql, ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
		return array_map( array( $this, 'hydrate_checklist' ), (array) $rows );
	}

	/**
	 * Accepts a numeric id or a slug.
	 */
	public function get_checklist( $ref ) {
		global $wpdb;
		$table = $this->checklists_table();
		if ( is_numeric( $ref ) ) {
			$row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$table} WHERE id = %d", (int) $ref ), ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		} else {
			$row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$table} WHERE slug = %s", (string) $ref ), ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		}
		return $row ? $this->hydrate_checklist( $row ) : null;
	}

	public function save_checklist( array $checklist ) {
		global $wpdb;
		$table = $this->checklists_table();
		$now   = current_time( 'mysql', true );

		$slug = ! empty( $checklist['slug'] ) ? sanitize_title( $checklist['slug'] ) : sanitize_title( $checklist['name'] );
		if ( '' === $slug ) {
			$slug = 'checklist-' . wp_generate_password( 8, false, false );
		}

		$data = array(
			'slug'        => $slug,
			'name'        => sanitize_text_field( isset( $checklist['name'] ) ? $checklist['name'] : $slug ),
			'name_he'     => sanitize_text_field( isset( $checklist['name_he'] ) ? $checklist['name_he'] : '' ),
			'description' => sanitize_textarea_field( isset( $checklist['description'] ) ? $checklist['description'] : '' ),
			'category'    => sanitize_key( ! empty( $checklist['category'] ) ? $checklist['category'] : 'general' ),
			'source'      => in_array( isset( $checklist['source'] ) ? $checklist['source'] : 'custom', array( 'builtin', 'custom' ), true ) ? $checklist['source'] : 'custom',
			'items'       => wp_json_encode( $this->sanitize_items( isset( $checklist['items'] ) ? (array) $checklist['items'] : array() ) ),
			'sort_order'  => isset( $checklist['sort_order'] ) ? (int) $checklist['sort_order'] : 0,
			'updated_at'  => $now,
		);

		$existing = $this->get_checklist( ! empty( $checklist['id'] ) ? $checklist['id'] : $slug );
		if ( $existing ) {
			$wpdb->update( $table, $data, array( 'id' => (int) $existing['id'] ) );
			return $this->get_checklist( (int) $existing['id'] );
		}

		$data['created_at'] = $now;
		$wpdb->insert( $table, $data );
		return $this->get_checklist( (int) $wpdb->insert_id );
	}

	public function delete_checklist( $ref ) {
		global $wpdb;
		$checklist = $this->get_checklist( $ref );
		if ( ! $checklist ) {
			return false;
		}
		$wpdb->delete( $this->checklists_table(), array( 'id' => (int) $checklist['id'] ) );
		return true;
	}

	public function sanitize_items( array $items ) {
		$clean = array();
		$seen  = array();
		foreach ( $items as $item ) {
			if ( ! is_array( $item ) ) {
				continue;
			}
			$title = sanitize_text_field( isset( $item['title'] ) ? $item['title'] : '' );
			if ( '' === $title ) {
				continue;
			}
			$id = ! empty( $item['id'] ) ? sanitize_title( $item['id'] ) : sanitize_title( $title );
			if ( '' === $id || isset( $seen[ $id ] ) ) {
				$id = $id . '-' . substr( md5( $title . count( $clean ) ), 0, 6 );
			}
			$seen[ $id ] = true;

			$severity = isset( $item['severity'] ) ? $item['severity'] : 'major';
			if ( ! in_array( $severity, array( 'blocker', 'major', 'minor' ), true ) ) {
				$severity = 'major';
			}
			$check_type = isset( $item['check_type'] ) ? $item['check_type'] : 'agent';
			if ( ! in_array( $check_type, array( 'agent', 'browser', 'manual' ), true ) ) {
				$check_type = 'agent';
			}

			$clean[] = array(
				'id'           => $id,
				'section'      => sanitize_text_field( ! empty( $item['section'] ) ? $item['section'] : 'General' ),
				'section_he'   => sanitize_text_field( isset( $item['section_he'] ) ? $item['section_he'] : '' ),
				'title'        => $title,
				'title_he'     => sanitize_text_field( isset( $item['title_he'] ) ? $item['title_he'] : '' ),
				'how_to_check' => sanitize_textarea_field( isset( $item['how_to_check'] ) ? $item['how_to_check'] : '' ),
				'severity'     => $severity,
				'check_type'   => $check_type,
				'tags'         => array_values( array_filter( array_map( 'sanitize_key', isset( $item['tags'] ) ? (array) $item['tags'] : array() ) ) ),
				'enabled'      => isset( $item['enabled'] ) ? (bool) $item['enabled'] : true,
				'custom'       => ! empty( $item['custom'] ),
			);
		}
		return $clean;
	}

	private function hydrate_checklist( array $row ) {
		$items = json_decode( isset( $row['items'] ) ? (string) $row['items'] : '[]', true );
		return array(
			'id'          => (int) $row['id'],
			'slug'        => $row['slug'],
			'name'        => $row['name'],
			'name_he'     => isset( $row['name_he'] ) ? (string) $row['name_he'] : '',
			'description' => $row['description'],
			'category'    => $row['category'],
			'source'      => $row['source'],
			'items'       => is_array( $items ) ? $items : array(),
			'sort_order'  => (int) $row['sort_order'],
			'created_at'  => $row['created_at'],
			'updated_at'  => $row['updated_at'],
		);
	}

	/* ---------------------------------------------------------------------
	 * Runs
	 * ------------------------------------------------------------------ */

	public function create_run( array $checklist, $label = '', $created_by = '' ) {
		global $wpdb;
		$now     = current_time( 'mysql', true );
		$run_id  = 'run_' . str_replace( '-', '', wp_generate_uuid4() );
		$results = array();
		foreach ( $checklist['items'] as $item ) {
			if ( empty( $item['enabled'] ) ) {
				continue;
			}
			$results[] = array(
				'item_id'    => $item['id'],
				'status'     => 'pending',
				'notes'      => '',
				'evidence'   => '',
				'assignee'   => '',
				'checked_by' => '',
				'checked_at' => '',
			);
		}
		$wpdb->insert(
			$this->runs_table(),
			array(
				'run_id'         => $run_id,
				'checklist_id'   => (int) $checklist['id'],
				'checklist_slug' => $checklist['slug'],
				'checklist_name' => $checklist['name'],
				'label'          => sanitize_text_field( $label ),
				'status'         => 'in-progress',
				'results'        => wp_json_encode( $results ),
				'summary'        => wp_json_encode( array() ),
				'started_at'     => $now,
				'created_by'     => sanitize_text_field( $created_by ),
			)
		);
		return $this->get_run( $run_id );
	}

	public function get_run( $run_id ) {
		global $wpdb;
		$table = $this->runs_table();
		$row   = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$table} WHERE run_id = %s", (string) $run_id ), ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		return $row ? $this->hydrate_run( $row ) : null;
	}

	public function get_run_by_token( $token ) {
		global $wpdb;
		$token = sanitize_key( (string) $token );
		if ( strlen( $token ) < 20 ) {
			return null;
		}
		$table = $this->runs_table();
		$row   = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$table} WHERE share_token = %s", $token ), ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		return $row ? $this->hydrate_run( $row ) : null;
	}

	public function list_runs( $limit = 20 ) {
		global $wpdb;
		$table = $this->runs_table();
		$rows  = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$table} ORDER BY id DESC LIMIT %d", max( 1, (int) $limit ) ), ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		return array_map( array( $this, 'hydrate_run' ), (array) $rows );
	}

	public function update_run( $run_id, array $fields ) {
		global $wpdb;
		$allowed = array();
		if ( isset( $fields['results'] ) ) {
			$allowed['results'] = wp_json_encode( array_values( (array) $fields['results'] ) );
		}
		if ( isset( $fields['summary'] ) ) {
			$allowed['summary'] = wp_json_encode( (array) $fields['summary'] );
		}
		if ( isset( $fields['status'] ) && in_array( $fields['status'], array( 'in-progress', 'completed', 'abandoned' ), true ) ) {
			$allowed['status'] = $fields['status'];
		}
		if ( isset( $fields['completed_at'] ) ) {
			$allowed['completed_at'] = $fields['completed_at'];
		}
		if ( isset( $fields['label'] ) ) {
			$allowed['label'] = sanitize_text_field( $fields['label'] );
		}
		if ( isset( $fields['share_token'] ) ) {
			$allowed['share_token'] = sanitize_key( $fields['share_token'] );
		}
		if ( ! $allowed ) {
			return $this->get_run( $run_id );
		}
		$wpdb->update( $this->runs_table(), $allowed, array( 'run_id' => (string) $run_id ) );
		return $this->get_run( $run_id );
	}

	public function delete_run( $run_id ) {
		global $wpdb;
		return (bool) $wpdb->delete( $this->runs_table(), array( 'run_id' => (string) $run_id ) );
	}

	private function hydrate_run( array $row ) {
		$results = json_decode( isset( $row['results'] ) ? (string) $row['results'] : '[]', true );
		$summary = json_decode( isset( $row['summary'] ) ? (string) $row['summary'] : '{}', true );
		return array(
			'run_id'         => $row['run_id'],
			'checklist_id'   => (int) $row['checklist_id'],
			'checklist_slug' => $row['checklist_slug'],
			'checklist_name' => $row['checklist_name'],
			'label'          => isset( $row['label'] ) ? $row['label'] : '',
			'status'         => $row['status'],
			'results'        => is_array( $results ) ? $results : array(),
			'summary'        => is_array( $summary ) ? $summary : array(),
			'started_at'     => $row['started_at'],
			'completed_at'   => isset( $row['completed_at'] ) ? $row['completed_at'] : null,
			'created_by'     => isset( $row['created_by'] ) ? $row['created_by'] : '',
			'share_token'    => isset( $row['share_token'] ) ? (string) $row['share_token'] : '',
		);
	}
}
