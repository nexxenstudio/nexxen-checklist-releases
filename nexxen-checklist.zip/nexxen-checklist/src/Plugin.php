<?php
namespace Nexxen_Checklist;

defined( 'ABSPATH' ) || exit;

final class Plugin {

	private static $instance;

	private $actions;

	public static function instance() {
		if ( ! self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	public function boot() {
		Installer::maybe_upgrade();

		$store         = new Store();
		$this->actions = new Actions( $store );

		$share = new Share( $store );
		$share->boot();

		$rest = new Rest\Controller( $this->actions );
		$rest->boot();

		$abilities = new Agent\Abilities( $this->actions );
		$abilities->boot();

		if ( is_admin() ) {
			$page = new Admin\Page();
			$page->boot();
		}

		$updater = new Updater();
		$updater->boot();

		add_action( 'nexxen_checklist_drift_scan', array( $this, 'cron_drift_scan' ) );
		if ( ! wp_next_scheduled( 'nexxen_checklist_drift_scan' ) ) {
			wp_schedule_event( time() + DAY_IN_SECONDS, 'weekly', 'nexxen_checklist_drift_scan' );
		}
	}

	public function cron_drift_scan() {
		$this->actions->run_drift_scan( array( 'trigger' => 'cron' ) );
	}

	public function actions() {
		return $this->actions;
	}
}
