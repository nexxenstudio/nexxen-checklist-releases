<?php
namespace Nexxen_Checklist\Engine;

defined( 'ABSPATH' ) || exit;

/**
 * Deterministic auto-check engine. Every check is plain PHP — a WordPress
 * option read, an HTTP request against the site's own URLs, or a database
 * search. No AI, no external services. Checks the engine cannot decide
 * conclusively return status "skipped" with a note, never a guessed pass.
 *
 * Results map to built-in checklist item ids, so a run can be pre-filled
 * mechanically before the agent/human handles the visual items.
 */
final class AutoCheck {

	/**
	 * Item ids re-checked by the weekly drift scan on live sites.
	 */
	const DRIFT_IDS = array(
		'search-engine-visibility',
		'no-debug-output',
		'ssl-valid-forced',
		'robots-txt-sane',
		'sitemap-valid',
		'caching-active',
		'404-page-styled',
		'lang-dir-attributes',
	);

	/**
	 * Optional fetch override for testing: callable( $url, $args ) returning
	 * array( 'code' => int, 'body' => string, 'headers' => array ).
	 */
	public $fetcher = null;

	private $http_cache = array();

	public static function registry() {
		return array(
			'search-engine-visibility' => 'check_search_visibility',
			'permalinks-clean'         => 'check_permalinks',
			'timezone-locale'          => 'check_timezone',
			'comments-configured'      => 'check_comments',
			'no-debug-output'          => 'check_debug',
			'core-plugins-updated'     => 'check_updates',
			'unused-plugins-removed'   => 'check_inactive_plugins',
			'user-accounts-clean'      => 'check_users',
			'backups-configured'       => 'check_backups',
			'ssl-valid-forced'         => 'check_ssl',
			'canonical-host'           => 'check_canonical_host',
			'staging-urls-gone'        => 'check_staging_urls',
			'404-page-styled'          => 'check_404',
			'caching-active'           => 'check_cache_headers',
			'favicon-set'              => 'check_favicon',
			'legal-pages-present'      => 'check_legal_pages',
			'analytics-installed'      => 'check_analytics',
			'sitemap-valid'            => 'check_sitemap',
			'robots-txt-sane'          => 'check_robots',
			'no-index-leaks'           => 'check_noindex',
			'meta-titles-unique'       => 'check_meta_titles',
			'meta-descriptions'        => 'check_meta_descriptions',
			'og-tags-set'              => 'check_og',
			'no-placeholder-content'   => 'check_placeholder_content',
			'one-h1-per-page'          => 'check_h1',
			'no-dead-links'            => 'check_dead_links',
			'image-alt-seo'            => 'check_image_alts',
			'alt-text-meaningful'      => 'check_image_alts',
			'heading-hierarchy'        => 'check_heading_hierarchy',
			'schema-basics'            => 'check_schema',

			/* Nexxen process items the engine can settle mechanically. */
			'builder-hebrew-rtl'                => 'check_site_hebrew_rtl',
			'lang-dir-attributes'               => 'check_lang_dir',
			'search-visibility-staging'         => 'check_search_visibility_env',
			'images-webp'                       => 'check_webp_images',
			'extra-themes-removed'              => 'check_extra_themes',
			'deactivate-advanced-themer'        => 'check_advanced_themer',
			'external-links-new-tab'            => 'check_external_link_targets',
			'404-page-language'                 => 'check_404_hebrew',
			'copyright-line'                    => 'check_copyright_line',
			'cpt-hebrew-labels'                 => 'check_cpt_hebrew_labels',
			'accessibility-statement-published' => 'check_accessibility_statement',
			'store-accessibility-statement'     => 'check_accessibility_statement',
			'privacy-policy-published'          => 'check_privacy_policy_page',
			'store-privacy-policy'              => 'check_privacy_policy_page',
			'terms-published'                   => 'check_terms_page',
			'store-terms-of-use'                => 'check_terms_page',
			'policy-pages-added'                => 'check_legal_pages',
			'legal-pages-linked-footer'         => 'check_footer_legal_links',
			'shekel-symbol-left'                => 'check_shekel_position',
		);
	}

	public static function supported_ids() {
		return array_keys( self::registry() );
	}

	/**
	 * Runs the engine for the given item ids. Unknown ids are ignored.
	 * Returns item_id => array( status, notes, evidence ).
	 */
	public function run_for_items( array $item_ids ) {
		$registry = self::registry();
		$results  = array();
		foreach ( $item_ids as $id ) {
			if ( ! isset( $registry[ $id ] ) ) {
				continue;
			}
			$method = $registry[ $id ];
			try {
				$results[ $id ] = $this->{$method}();
			} catch ( \Throwable $e ) {
				$results[ $id ] = $this->result( 'skipped', 'Auto-check crashed: ' . $e->getMessage(), '' );
			}
		}
		return $results;
	}

	private function result( $status, $notes, $evidence = '' ) {
		return array(
			'status'   => $status,
			'notes'    => (string) $notes,
			'evidence' => (string) $evidence,
		);
	}

	/* ---------------------------------------------------------------------
	 * HTTP helpers
	 * ------------------------------------------------------------------ */

	private function fetch( $url, array $args = array() ) {
		$key = $url . '|' . md5( wp_json_encode( $args ) );
		if ( isset( $this->http_cache[ $key ] ) ) {
			return $this->http_cache[ $key ];
		}
		if ( is_callable( $this->fetcher ) ) {
			$out = call_user_func( $this->fetcher, $url, $args );
		} else {
			$response = wp_remote_get(
				$url,
				array_merge(
					array(
						'timeout'     => 10,
						'redirection' => isset( $args['redirection'] ) ? $args['redirection'] : 3,
						'user-agent'  => 'Nexxen-Checklist/' . NEXXEN_CHECKLIST_VERSION . '; ' . home_url(),
						'sslverify'   => true,
					),
					$args
				)
			);
			if ( is_wp_error( $response ) ) {
				$out = array( 'code' => 0, 'body' => '', 'headers' => array(), 'error' => $response->get_error_message() );
			} else {
				$headers = wp_remote_retrieve_headers( $response );
				$out     = array(
					'code'    => (int) wp_remote_retrieve_response_code( $response ),
					'body'    => (string) wp_remote_retrieve_body( $response ),
					'headers' => is_object( $headers ) && method_exists( $headers, 'getAll' ) ? array_change_key_case( $headers->getAll() ) : (array) $headers,
				);
			}
		}
		$this->http_cache[ $key ] = $out;
		return $out;
	}

	private function header( array $response, $name ) {
		$name = strtolower( $name );
		return isset( $response['headers'][ $name ] ) ? ( is_array( $response['headers'][ $name ] ) ? implode( ', ', $response['headers'][ $name ] ) : (string) $response['headers'][ $name ] ) : '';
	}

	/**
	 * Homepage plus a bounded sample of published pages and recent posts.
	 */
	private function sample_urls() {
		$urls = array( home_url( '/' ) );
		$pages = get_posts( array( 'post_type' => 'page', 'post_status' => 'publish', 'numberposts' => 8, 'orderby' => 'menu_order', 'order' => 'ASC' ) );
		foreach ( $pages as $page ) {
			$urls[] = get_permalink( $page );
		}
		$posts = get_posts( array( 'post_type' => 'post', 'post_status' => 'publish', 'numberposts' => 3 ) );
		foreach ( $posts as $post ) {
			$urls[] = get_permalink( $post );
		}
		return array_values( array_unique( array_filter( $urls ) ) );
	}

	private function page_bodies() {
		$bodies = array();
		foreach ( $this->sample_urls() as $url ) {
			$response = $this->fetch( $url );
			if ( 200 === $response['code'] && '' !== $response['body'] ) {
				$bodies[ $url ] = $response['body'];
			}
		}
		return $bodies;
	}

	private function short_list( array $items, $max = 5 ) {
		$shown = array_slice( $items, 0, $max );
		$extra = count( $items ) - count( $shown );
		return implode( '; ', $shown ) . ( $extra > 0 ? ' (+' . $extra . ' more)' : '' );
	}

	/* ---------------------------------------------------------------------
	 * Option / settings checks
	 * ------------------------------------------------------------------ */

	private function check_search_visibility() {
		if ( '1' === (string) get_option( 'blog_public' ) ) {
			return $this->result( 'pass', 'Search engines are allowed to index the site.', 'Settings > Reading: blog_public = 1' );
		}
		return $this->result( 'fail', '"Discourage search engines" is ON. Search engines are blocked.', 'Settings > Reading: blog_public = ' . get_option( 'blog_public' ) );
	}

	private function check_permalinks() {
		$structure = (string) get_option( 'permalink_structure' );
		if ( '' === $structure ) {
			return $this->result( 'fail', 'Permalinks are set to Plain (?p= IDs).', 'permalink_structure is empty' );
		}
		return $this->result( 'pass', 'Clean permalink structure in use.', 'permalink_structure = ' . $structure );
	}

	private function check_timezone() {
		$tz = (string) get_option( 'timezone_string' );
		if ( '' !== $tz ) {
			return $this->result( 'pass', 'Timezone is set.', 'timezone_string = ' . $tz );
		}
		$offset = (float) get_option( 'gmt_offset' );
		if ( 0.0 !== $offset ) {
			return $this->result( 'pass', 'Timezone set via UTC offset.', 'gmt_offset = ' . $offset );
		}
		return $this->result( 'fail', 'Timezone is the WordPress default (UTC+0). Set the client timezone.', 'timezone_string empty, gmt_offset 0' );
	}

	private function check_comments() {
		$comments = (string) get_option( 'default_comment_status' );
		$pings    = (string) get_option( 'default_ping_status' );
		if ( 'closed' === $comments && 'closed' === $pings ) {
			return $this->result( 'pass', 'Comments and pingbacks are disabled by default.', 'default_comment_status/default_ping_status = closed' );
		}
		return $this->result( 'fail', 'Discussion is open by default (comments: ' . $comments . ', pingbacks: ' . $pings . '). Disable unless the site needs them.', 'Settings > Discussion' );
	}

	private function check_debug() {
		if ( defined( 'WP_DEBUG' ) && WP_DEBUG && ( ! defined( 'WP_DEBUG_DISPLAY' ) || WP_DEBUG_DISPLAY ) ) {
			return $this->result( 'fail', 'WP_DEBUG is on with display enabled — PHP notices can leak to visitors.', 'WP_DEBUG = true, WP_DEBUG_DISPLAY not false' );
		}
		$home = $this->fetch( home_url( '/' ) );
		if ( 200 === $home['code'] && preg_match( '/(Fatal error|Warning: |Notice: |Deprecated: )/', $home['body'] ) ) {
			return $this->result( 'fail', 'The homepage HTML contains PHP error output.', home_url( '/' ) );
		}
		$note = defined( 'WP_DEBUG' ) && WP_DEBUG ? 'WP_DEBUG on but logging only (display off).' : 'WP_DEBUG is off.';
		return $this->result( 'pass', $note . ' No error text found on the homepage.', home_url( '/' ) );
	}

	private function check_updates() {
		$pending = array();
		$plugins = get_site_transient( 'update_plugins' );
		if ( $plugins && ! empty( $plugins->response ) ) {
			$pending[] = count( $plugins->response ) . ' plugin update(s)';
		}
		$themes = get_site_transient( 'update_themes' );
		if ( $themes && ! empty( $themes->response ) ) {
			$pending[] = count( $themes->response ) . ' theme update(s)';
		}
		$core = get_site_transient( 'update_core' );
		if ( $core && ! empty( $core->updates ) && isset( $core->updates[0]->response ) && 'upgrade' === $core->updates[0]->response ) {
			$pending[] = 'WordPress core update';
		}
		if ( $pending ) {
			return $this->result( 'fail', 'Updates pending: ' . implode( ', ', $pending ) . '.', 'update transients' );
		}
		return $this->result( 'pass', 'Core, themes and plugins are up to date (per the last update check).', 'update transients empty' );
	}

	private function check_inactive_plugins() {
		if ( ! function_exists( 'get_plugins' ) ) {
			require_once ABSPATH . 'wp-admin/includes/plugin.php';
		}
		$all      = get_plugins();
		$active   = (array) get_option( 'active_plugins', array() );
		$inactive = array();
		foreach ( $all as $file => $data ) {
			if ( ! in_array( $file, $active, true ) ) {
				$inactive[] = $data['Name'];
			}
		}
		if ( $inactive ) {
			return $this->result( 'fail', count( $inactive ) . ' plugin(s) installed but deactivated: ' . $this->short_list( $inactive ) . '. Delete them unless there is a documented reason to keep them.', 'plugin list' );
		}
		return $this->result( 'pass', 'No deactivated plugins left installed.', count( $all ) . ' plugins, all active' );
	}

	private function check_users() {
		$admins     = get_users( array( 'role' => 'administrator', 'fields' => array( 'user_login' ) ) );
		$logins     = array_map( static function ( $user ) { return $user->user_login; }, $admins );
		$suspicious = array();
		foreach ( $logins as $login ) {
			if ( 'admin' === strtolower( $login ) || preg_match( '/(test|demo|temp)/i', $login ) ) {
				$suspicious[] = $login;
			}
		}
		if ( $suspicious ) {
			return $this->result( 'fail', 'Suspicious admin account(s): ' . implode( ', ', $suspicious ) . '. Remove or rename before handover.', 'Administrators: ' . implode( ', ', $logins ) );
		}
		return $this->result( 'pass', count( $logins ) . ' administrator account(s), none obviously left over. Confirm the list matches who should have access.', 'Administrators: ' . implode( ', ', $logins ) );
	}

	private function check_backups() {
		$active  = array_map( 'strtolower', (array) get_option( 'active_plugins', array() ) );
		$known   = array( 'wpvivid', 'updraft', 'backwpup', 'duplicator', 'blogvault', 'wp-staging', 'all-in-one-wp-migration' );
		$found   = array();
		foreach ( $active as $file ) {
			foreach ( $known as $marker ) {
				if ( false !== strpos( $file, $marker ) ) {
					$found[] = $marker;
				}
			}
		}
		if ( $found ) {
			return $this->result( 'pass', 'Backup plugin active (' . implode( ', ', array_unique( $found ) ) . '). Confirm a recent backup actually exists.', 'active_plugins' );
		}
		return $this->result( 'skipped', 'No backup plugin detected. If backups are handled at hosting level (FlyWP/Hostinger), verify there and mark this manually.', 'active_plugins scanned' );
	}

	/* ---------------------------------------------------------------------
	 * HTTP checks
	 * ------------------------------------------------------------------ */

	private function check_ssl() {
		$home = home_url( '/' );
		if ( 0 !== strpos( $home, 'https://' ) ) {
			return $this->result( 'fail', 'The site URL itself is not HTTPS.', 'home_url = ' . $home );
		}
		$http     = set_url_scheme( $home, 'http' );
		$response = $this->fetch( $http, array( 'redirection' => 0 ) );
		if ( 0 === $response['code'] ) {
			return $this->result( 'skipped', 'Could not reach the http:// variant to test the redirect: ' . ( isset( $response['error'] ) ? $response['error'] : 'no response' ), $http );
		}
		$location = $this->header( $response, 'location' );
		if ( in_array( $response['code'], array( 301, 302, 307, 308 ), true ) && 0 === strpos( $location, 'https://' ) ) {
			return $this->result( 'pass', 'HTTP redirects to HTTPS (' . $response['code'] . ').', $http . ' -> ' . $location );
		}
		return $this->result( 'fail', 'http:// did not redirect to https:// (got HTTP ' . $response['code'] . ').', $http );
	}

	private function check_canonical_host() {
		$host = wp_parse_url( home_url(), PHP_URL_HOST );
		if ( ! $host ) {
			return $this->result( 'skipped', 'Could not determine the site host.', '' );
		}
		$alt      = 0 === strpos( $host, 'www.' ) ? substr( $host, 4 ) : 'www.' . $host;
		$alt_url  = 'https://' . $alt . '/';
		$response = $this->fetch( $alt_url, array( 'redirection' => 0 ) );
		if ( 0 === $response['code'] ) {
			return $this->result( 'skipped', 'The ' . $alt . ' variant did not respond (may not be configured in DNS). Verify manually that one canonical host is enforced.', $alt_url );
		}
		$location = $this->header( $response, 'location' );
		if ( in_array( $response['code'], array( 301, 308 ), true ) && false !== strpos( $location, $host ) ) {
			return $this->result( 'pass', $alt . ' permanently redirects to the canonical host ' . $host . '.', $alt_url . ' -> ' . $location );
		}
		return $this->result( 'fail', $alt . ' answered HTTP ' . $response['code'] . ' instead of a 301 redirect to ' . $host . '.', $alt_url );
	}

	private function check_staging_urls() {
		global $wpdb;
		$host     = (string) wp_parse_url( home_url(), PHP_URL_HOST );
		$patterns = apply_filters( 'nexxen_checklist_staging_patterns', array( 'hostingersite.com', '.wpdesigns.xyz', 'staging.', '.local', 'localhost' ) );
		foreach ( $patterns as $pattern ) {
			if ( false !== strpos( $host, trim( $pattern, '.' ) ) ) {
				return $this->result( 'skipped', 'This site itself runs on a staging/dev domain (' . $host . '), so staging-URL detection only applies after go-live.', $host );
			}
		}
		$hits = array();
		foreach ( $patterns as $pattern ) {
			$like  = '%' . $wpdb->esc_like( $pattern ) . '%';
			$count = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$wpdb->posts} WHERE post_status = 'publish' AND post_content LIKE %s", $like ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
			if ( $count > 0 ) {
				$hits[] = $pattern . ' in ' . $count . ' post(s)';
			}
		}
		$home = $this->fetch( home_url( '/' ) );
		if ( 200 === $home['code'] ) {
			foreach ( $patterns as $pattern ) {
				if ( false !== stripos( $home['body'], $pattern ) ) {
					$hits[] = $pattern . ' in rendered homepage HTML';
				}
			}
		}
		if ( $hits ) {
			return $this->result( 'fail', 'Staging references found: ' . $this->short_list( array_unique( $hits ) ) . '.', 'database + homepage scan' );
		}
		return $this->result( 'pass', 'No staging-domain references in published content or homepage HTML.', 'patterns: ' . implode( ', ', $patterns ) );
	}

	private function check_404() {
		$url      = home_url( '/nexxen-checklist-missing-' . wp_generate_password( 8, false, false ) . '/' );
		$response = $this->fetch( $url );
		if ( 404 === $response['code'] ) {
			return $this->result( 'pass', 'Unknown URLs return HTTP 404. Whether the 404 page is styled still needs a visual check.', $url );
		}
		if ( 0 === $response['code'] ) {
			return $this->result( 'skipped', 'Could not reach the site to test the 404 status.', $url );
		}
		return $this->result( 'fail', 'A nonsense URL returned HTTP ' . $response['code'] . ' instead of 404.', $url );
	}

	private function check_cache_headers() {
		$url = home_url( '/' );
		$this->fetch( $url, array( 'headers' => array( 'X-Nexxen-Warm' => '1' ) ) );
		$second  = $this->fetch( $url, array( 'headers' => array( 'X-Nexxen-Warm' => '2' ) ) );
		$markers = array( 'x-nexxen-cache', 'x-wpd-cache', 'x-cache', 'cf-cache-status', 'x-litespeed-cache', 'x-cache-status', 'x-fastcgi-cache', 'x-srcache-fetch-status' );
		foreach ( $markers as $marker ) {
			$value = $this->header( $second, $marker );
			if ( '' !== $value ) {
				$hit = (bool) preg_match( '/hit/i', $value );
				return $hit
					? $this->result( 'pass', 'Page cache serving HITs (' . $marker . ': ' . $value . ').', $url )
					: $this->result( 'fail', 'Cache header present but not a HIT on repeat request (' . $marker . ': ' . $value . ').', $url );
			}
		}
		$age = $this->header( $second, 'age' );
		if ( '' !== $age && (int) $age > 0 ) {
			return $this->result( 'pass', 'Cached response detected (Age: ' . $age . ').', $url );
		}
		return $this->result( 'fail', 'No cache header found on a repeat homepage request — page caching looks inactive.', $url );
	}

	private function check_favicon() {
		if ( (int) get_option( 'site_icon' ) > 0 ) {
			return $this->result( 'pass', 'Site icon is configured in WordPress.', 'site_icon attachment #' . get_option( 'site_icon' ) );
		}
		$response = $this->fetch( home_url( '/favicon.ico' ) );
		if ( 200 === $response['code'] && '' !== $response['body'] ) {
			return $this->result( 'pass', 'No WordPress site icon set, but /favicon.ico exists.', home_url( '/favicon.ico' ) );
		}
		return $this->result( 'fail', 'No site icon configured and /favicon.ico is missing.', 'Settings > General > Site Icon' );
	}

	private function check_legal_pages() {
		$pages = get_posts( array( 'post_type' => 'page', 'post_status' => 'publish', 'numberposts' => 200, 'fields' => 'ids' ) );
		$found = array();
		foreach ( $pages as $page_id ) {
			$title = get_the_title( $page_id );
			if ( preg_match( '/(privacy|cookie|terms|conditions|impressum|voorwaarden|disclaimer)/i', $title ) ) {
				$found[] = $title;
			}
		}
		if ( $found ) {
			return $this->result( 'pass', 'Legal page(s) published: ' . $this->short_list( $found ) . '. Confirm they are linked in the footer and contain real content.', count( $pages ) . ' pages scanned' );
		}
		return $this->result( 'fail', 'No privacy/cookie/terms page found among published pages.', count( $pages ) . ' pages scanned' );
	}

	private function check_analytics() {
		$home = $this->fetch( home_url( '/' ) );
		if ( 200 !== $home['code'] ) {
			return $this->result( 'skipped', 'Homepage did not return 200; cannot inspect for analytics.', home_url( '/' ) );
		}
		$vendors = array(
			'googletagmanager.com' => 'Google Tag Manager',
			'gtag('                => 'GA4 (gtag)',
			'google-analytics.com' => 'Google Analytics',
			'usefathom'            => 'Fathom',
			'plausible'            => 'Plausible',
			'matomo'               => 'Matomo',
			'_paq'                 => 'Matomo',
			'clarity.ms'           => 'MS Clarity',
		);
		$found = array();
		foreach ( $vendors as $needle => $label ) {
			if ( false !== stripos( $home['body'], $needle ) ) {
				$found[ $label ] = $label;
			}
		}
		if ( $found ) {
			return $this->result( 'pass', 'Analytics detected: ' . implode( ', ', $found ) . '. Verify a realtime test visit is recorded.', home_url( '/' ) );
		}
		return $this->result( 'fail', 'No known analytics snippet found in the homepage HTML.', home_url( '/' ) );
	}

	private function check_sitemap() {
		foreach ( array( '/sitemap.xml', '/sitemap_index.xml', '/wp-sitemap.xml' ) as $path ) {
			$url      = home_url( $path );
			$response = $this->fetch( $url );
			if ( 200 === $response['code'] && preg_match( '/<(urlset|sitemapindex)/i', $response['body'] ) ) {
				$host    = (string) wp_parse_url( home_url(), PHP_URL_HOST );
				$foreign = ! preg_match( '/https?:\/\/[^<]*' . preg_quote( $host, '/' ) . '/i', $response['body'] );
				if ( $foreign && preg_match( '/<loc>/i', $response['body'] ) ) {
					return $this->result( 'fail', 'Sitemap at ' . $path . ' exists but its URLs do not reference ' . $host . ' — likely stale staging URLs.', $url );
				}
				return $this->result( 'pass', 'Valid XML sitemap at ' . $path . '.', $url );
			}
		}
		return $this->result( 'fail', 'No XML sitemap found at the common locations.', home_url( '/sitemap.xml' ) );
	}

	private function check_robots() {
		$url      = home_url( '/robots.txt' );
		$response = $this->fetch( $url );
		if ( 200 !== $response['code'] ) {
			return $this->result( 'fail', '/robots.txt returned HTTP ' . $response['code'] . '.', $url );
		}
		if ( preg_match( '/^\s*Disallow:\s*\/\s*$/mi', $response['body'] ) ) {
			return $this->result( 'fail', 'robots.txt contains "Disallow: /" — the whole site is blocked from crawling.', $url );
		}
		$sitemap_note = preg_match( '/^\s*Sitemap:/mi', $response['body'] ) ? 'It references a sitemap.' : 'It does not reference a sitemap (minor).';
		return $this->result( 'pass', 'robots.txt allows crawling. ' . $sitemap_note, $url );
	}

	private function check_noindex() {
		$offenders = array();
		foreach ( $this->page_bodies() as $url => $body ) {
			if ( preg_match( '/<meta[^>]+name=["\']robots["\'][^>]+content=["\'][^"\']*noindex/i', $body ) ) {
				$offenders[] = $url;
			}
		}
		if ( $offenders ) {
			return $this->result( 'fail', 'noindex found on: ' . $this->short_list( $offenders ) . '. Confirm each is intentional.', count( $offenders ) . ' page(s)' );
		}
		return $this->result( 'pass', 'No stray noindex meta on the sampled pages.', count( $this->page_bodies() ) . ' pages checked' );
	}

	private function check_meta_titles() {
		$titles  = array();
		$missing = array();
		foreach ( $this->page_bodies() as $url => $body ) {
			if ( preg_match( '/<title[^>]*>(.*?)<\/title>/is', $body, $match ) ) {
				$title = trim( wp_strip_all_tags( $match[1] ) );
				if ( '' === $title ) {
					$missing[] = $url;
				} else {
					$titles[ $url ] = $title;
				}
			} else {
				$missing[] = $url;
			}
		}
		$dupes = array_diff_assoc( $titles, array_unique( $titles ) );
		if ( $missing || $dupes ) {
			$problems = array();
			if ( $missing ) {
				$problems[] = 'missing titles: ' . $this->short_list( $missing, 3 );
			}
			if ( $dupes ) {
				$problems[] = 'duplicate titles: ' . $this->short_list( array_unique( array_values( $dupes ) ), 3 );
			}
			return $this->result( 'fail', ucfirst( implode( '; ', $problems ) ) . '.', count( $titles ) + count( $missing ) . ' pages checked' );
		}
		return $this->result( 'pass', 'Every sampled page has a unique, non-empty title.', count( $titles ) . ' pages checked' );
	}

	private function check_meta_descriptions() {
		$missing = array();
		$checked = 0;
		foreach ( $this->page_bodies() as $url => $body ) {
			$checked++;
			if ( ! preg_match( '/<meta[^>]+name=["\']description["\'][^>]+content=["\'][^"\']{20,}/i', $body )
				&& ! preg_match( '/<meta[^>]+content=["\'][^"\']{20,}["\'][^>]+name=["\']description["\']/i', $body ) ) {
				$missing[] = $url;
			}
		}
		if ( $missing ) {
			return $this->result( 'fail', 'Meta description missing (or under 20 chars) on: ' . $this->short_list( $missing ) . '.', $checked . ' pages checked' );
		}
		return $this->result( 'pass', 'All sampled pages have meta descriptions.', $checked . ' pages checked' );
	}

	private function check_og() {
		$home = $this->fetch( home_url( '/' ) );
		if ( 200 !== $home['code'] ) {
			return $this->result( 'skipped', 'Homepage did not return 200.', home_url( '/' ) );
		}
		$missing = array();
		foreach ( array( 'og:title', 'og:image' ) as $property ) {
			if ( ! preg_match( '/<meta[^>]+property=["\']' . preg_quote( $property, '/' ) . '["\']/i', $home['body'] ) ) {
				$missing[] = $property;
			}
		}
		if ( $missing ) {
			return $this->result( 'fail', 'Open Graph tags missing on the homepage: ' . implode( ', ', $missing ) . '.', home_url( '/' ) );
		}
		return $this->result( 'pass', 'og:title and og:image present on the homepage. Verify the image looks right in a share preview.', home_url( '/' ) );
	}

	private function check_placeholder_content() {
		global $wpdb;
		$patterns = array( 'lorem ipsum', 'dummy text', 'your text here', 'sample page content', 'placeholder text' );
		$hits     = array();
		foreach ( $patterns as $pattern ) {
			$like   = '%' . $wpdb->esc_like( $pattern ) . '%';
			$titles = $wpdb->get_col( $wpdb->prepare( "SELECT post_title FROM {$wpdb->posts} WHERE post_status = 'publish' AND post_type IN ('page','post') AND post_content LIKE %s LIMIT 5", $like ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
			foreach ( $titles as $title ) {
				$hits[] = '"' . $pattern . '" in ' . $title;
			}
		}
		if ( $hits ) {
			return $this->result( 'fail', 'Placeholder text found: ' . $this->short_list( array_unique( $hits ) ) . '.', 'database scan' );
		}
		return $this->result( 'pass', 'No lorem ipsum or placeholder phrases in published content.', 'patterns: ' . implode( ', ', $patterns ) );
	}

	private function check_h1() {
		$offenders = array();
		$checked   = 0;
		foreach ( $this->page_bodies() as $url => $body ) {
			$checked++;
			$count = preg_match_all( '/<h1[\s>]/i', $body );
			if ( 1 !== $count ) {
				$offenders[] = $url . ' (' . (int) $count . ' H1s)';
			}
		}
		if ( $offenders ) {
			return $this->result( 'fail', 'Pages without exactly one H1: ' . $this->short_list( $offenders ) . '.', $checked . ' pages checked' );
		}
		return $this->result( 'pass', 'Every sampled page has exactly one H1.', $checked . ' pages checked' );
	}

	/**
	 * Truly empty hrefs are a defect; bare "#" anchors are usually builder
	 * JS toggles (accordions, menus, tabs), so those are reported for review
	 * rather than failed — a false blocker would wrongly sink the verdict.
	 */
	private function check_dead_links() {
		$empty  = array();
		$hashes = array();
		$checked = 0;
		foreach ( $this->page_bodies() as $url => $body ) {
			$checked++;
			$empty_count = preg_match_all( '/<a[^>]+href=["\']\s*["\']/i', $body );
			if ( $empty_count > 0 ) {
				$empty[] = $url . ' (' . $empty_count . ')';
			}
			$hash_count = preg_match_all( '/<a[^>]+href=["\']#["\']/i', $body );
			if ( $hash_count > 0 ) {
				$hashes[] = $url . ' (' . $hash_count . ')';
			}
		}
		if ( $empty ) {
			return $this->result( 'fail', 'Links with a completely empty href: ' . $this->short_list( $empty ) . '. These go nowhere.', $checked . ' pages checked' );
		}
		if ( $hashes ) {
			return $this->result( 'skipped', 'No empty links, but href="#" anchors are present: ' . $this->short_list( $hashes ) . '. These are usually builder JS toggles (menus, accordions, tabs) rather than dead links — confirm visually, then mark this item yourself.', $checked . ' pages checked' );
		}
		return $this->result( 'pass', 'No empty or placeholder links on the sampled pages.', $checked . ' pages checked' );
	}

	private function check_image_alts() {
		$missing = 0;
		$total   = 0;
		$example = '';
		foreach ( $this->page_bodies() as $url => $body ) {
			if ( preg_match_all( '/<img[^>]*>/i', $body, $matches ) ) {
				foreach ( $matches[0] as $img ) {
					$total++;
					if ( ! preg_match( '/\salt=["\']/', $img ) ) {
						$missing++;
						if ( '' === $example ) {
							$example = $url;
						}
					}
				}
			}
		}
		if ( 0 === $total ) {
			return $this->result( 'skipped', 'No <img> tags found on the sampled pages (images may be CSS backgrounds — needs a visual pass).', '' );
		}
		if ( $missing > 0 ) {
			return $this->result( 'fail', $missing . ' of ' . $total . ' images have no alt attribute at all (first seen on ' . $example . '). Decorative images should use empty alt="", not none.', $total . ' images scanned' );
		}
		return $this->result( 'pass', 'All ' . $total . ' sampled images carry an alt attribute. Whether the alt text is meaningful still needs a human/agent read.', $total . ' images scanned' );
	}

	private function check_heading_hierarchy() {
		$offenders = array();
		$checked   = 0;
		foreach ( $this->page_bodies() as $url => $body ) {
			$checked++;
			if ( preg_match_all( '/<h([1-6])[\s>]/i', $body, $matches ) ) {
				$previous = 0;
				foreach ( $matches[1] as $level ) {
					$level = (int) $level;
					if ( $previous > 0 && $level > $previous + 1 ) {
						$offenders[] = $url . ' (h' . $previous . ' -> h' . $level . ')';
						break;
					}
					$previous = $level;
				}
			}
		}
		if ( $offenders ) {
			return $this->result( 'fail', 'Skipped heading levels: ' . $this->short_list( $offenders ) . '.', $checked . ' pages checked' );
		}
		return $this->result( 'pass', 'Heading levels nest without skips on the sampled pages.', $checked . ' pages checked' );
	}

	private function check_schema() {
		$home = $this->fetch( home_url( '/' ) );
		if ( 200 !== $home['code'] ) {
			return $this->result( 'skipped', 'Homepage did not return 200.', home_url( '/' ) );
		}
		if ( preg_match( '/application\/ld\+json/i', $home['body'] ) ) {
			return $this->result( 'pass', 'Structured data (JSON-LD) present on the homepage. Validate it if schema details matter for this client.', home_url( '/' ) );
		}
		return $this->result( 'fail', 'No JSON-LD structured data found on the homepage.', home_url( '/' ) );
	}

	/* ---------------------------------------------------------------------
	 * Nexxen: Hebrew, RTL and process checks
	 * ------------------------------------------------------------------ */

	/**
	 * True when a string contains at least one Hebrew letter.
	 */
	private function has_hebrew( $text ) {
		return (bool) preg_match( '/[\x{0590}-\x{05FF}]/u', (string) $text );
	}

	/**
	 * Published pages whose title matches a pattern, in Hebrew or English.
	 */
	private function find_pages( $pattern ) {
		$found = array();
		$pages = get_posts( array( 'post_type' => 'page', 'post_status' => 'publish', 'numberposts' => 300, 'fields' => 'ids' ) );
		foreach ( $pages as $page_id ) {
			$title = get_the_title( $page_id );
			if ( preg_match( $pattern, $title ) ) {
				$found[ $page_id ] = $title;
			}
		}
		return $found;
	}

	private function check_site_hebrew_rtl() {
		$locale = get_locale();
		$hebrew = ( 0 === strpos( $locale, 'he' ) );
		$rtl    = is_rtl();
		$evidence = 'locale=' . $locale . '; is_rtl=' . ( $rtl ? 'true' : 'false' );

		if ( $hebrew && $rtl ) {
			return $this->result( 'pass', 'WordPress runs in Hebrew with RTL active. The builder interface language still needs a visual confirmation inside Bricks.', $evidence );
		}
		if ( ! $hebrew && ! $rtl ) {
			return $this->result( 'fail', 'Site language is "' . $locale . '" and RTL is off — this should be Hebrew, right-to-left.', $evidence );
		}
		if ( ! $hebrew ) {
			return $this->result( 'fail', 'RTL is active but the site language is "' . $locale . '" rather than Hebrew.', $evidence );
		}
		return $this->result( 'fail', 'Site language is Hebrew but is_rtl() is false — the active theme is not flipping to RTL.', $evidence );
	}

	private function check_lang_dir() {
		$home = $this->fetch( home_url( '/' ) );
		if ( 200 !== $home['code'] ) {
			return $this->result( 'skipped', 'Homepage did not return 200, so the html attributes could not be read.', home_url( '/' ) );
		}
		preg_match( '/<html[^>]*>/i', $home['body'], $match );
		$tag = isset( $match[0] ) ? $match[0] : '';
		if ( '' === $tag ) {
			return $this->result( 'skipped', 'No <html> tag found in the homepage response.', home_url( '/' ) );
		}
		$has_lang_he = (bool) preg_match( '/lang=["\']he/i', $tag );
		$has_rtl     = (bool) preg_match( '/dir=["\']rtl["\']/i', $tag );
		if ( $has_lang_he && $has_rtl ) {
			return $this->result( 'pass', 'The html element declares Hebrew and right-to-left.', trim( $tag ) );
		}
		$missing = array();
		if ( ! $has_lang_he ) {
			$missing[] = 'lang is not a Hebrew locale';
		}
		if ( ! $has_rtl ) {
			$missing[] = 'dir="rtl" is missing';
		}
		return $this->result( 'fail', 'Screen readers will read this page wrongly: ' . implode( ' and ', $missing ) . '.', trim( $tag ) );
	}

	/**
	 * Environment-aware indexing check: staging domains are expected to be
	 * hidden, production domains are expected to be indexable.
	 */
	private function check_search_visibility_env() {
		$host    = wp_parse_url( home_url(), PHP_URL_HOST );
		$public  = '1' === (string) get_option( 'blog_public' );
		$staging = (bool) preg_match( '/(hostingersite\.com|\.wpdesigns\.xyz|staging|\.local$|localhost|\.test$|\.dev$)/i', (string) $host );
		$evidence = 'host=' . $host . '; blog_public=' . ( $public ? '1' : '0' ) . '; environment=' . ( $staging ? 'staging' : 'production' );

		if ( $staging && ! $public ) {
			return $this->result( 'pass', 'Staging domain with indexing discouraged — correct for this environment.', $evidence );
		}
		if ( $staging && $public ) {
			return $this->result( 'fail', 'This looks like a staging domain but search engines are allowed to index it. Tick "Discourage search engines" until the site moves to the live domain.', $evidence );
		}
		if ( ! $staging && $public ) {
			return $this->result( 'pass', 'Production domain and indexing is allowed — correct for this environment.', $evidence );
		}
		return $this->result( 'fail', 'This is the live domain but "Discourage search engines" is still ticked. The site cannot be indexed.', $evidence );
	}

	private function check_webp_images() {
		$attachments = get_posts(
			array(
				'post_type'      => 'attachment',
				'post_mime_type' => 'image',
				'post_status'    => 'inherit',
				'numberposts'    => 200,
				'fields'         => 'ids',
			)
		);
		if ( ! $attachments ) {
			return $this->result( 'skipped', 'No images found in the media library to check.', '0 attachments' );
		}
		$non_webp = array();
		foreach ( $attachments as $id ) {
			$mime = get_post_mime_type( $id );
			if ( 'image/webp' === $mime ) {
				continue;
			}
			if ( in_array( $mime, array( 'image/svg+xml', 'image/x-icon', 'image/vnd.microsoft.icon', 'image/gif' ), true ) ) {
				continue; // Vector, icon and animated formats are legitimately not WebP.
			}
			$non_webp[] = basename( (string) get_post_meta( $id, '_wp_attached_file', true ) );
		}
		$total = count( $attachments );
		if ( ! $non_webp ) {
			return $this->result( 'pass', 'All ' . $total . ' sampled library images are WebP.', $total . ' attachments scanned' );
		}
		return $this->result(
			'fail',
			count( $non_webp ) . ' of ' . $total . ' library images are not WebP: ' . $this->short_list( $non_webp ) . '. Convert the ones actually used on the site.',
			$total . ' attachments scanned'
		);
	}

	private function check_extra_themes() {
		if ( ! function_exists( 'wp_get_themes' ) ) {
			require_once ABSPATH . 'wp-admin/includes/theme.php';
		}
		$themes  = wp_get_themes();
		$active  = wp_get_theme();
		$keep    = array( $active->get_stylesheet(), $active->get_template() );
		$extra   = array();
		foreach ( $themes as $slug => $theme ) {
			if ( ! in_array( $slug, $keep, true ) ) {
				$extra[] = $theme->get( 'Name' ) . ' (' . $slug . ')';
			}
		}
		$evidence = 'active=' . $active->get_stylesheet() . '; installed=' . count( $themes );
		if ( ! $extra ) {
			return $this->result( 'pass', 'Only the active theme (and its parent) are installed.', $evidence );
		}
		return $this->result( 'fail', count( $extra ) . ' unused theme(s) still installed: ' . $this->short_list( $extra ) . '. Delete them before delivery.', $evidence );
	}

	private function check_advanced_themer() {
		if ( ! function_exists( 'get_plugins' ) ) {
			require_once ABSPATH . 'wp-admin/includes/plugin.php';
		}
		$active = array();
		foreach ( (array) get_plugins() as $file => $data ) {
			$name = isset( $data['Name'] ) ? $data['Name'] : $file;
			if ( preg_match( '/advanced\s*themer/i', $name . ' ' . $file ) && is_plugin_active( $file ) ) {
				$active[] = $name;
			}
		}
		if ( ! $active ) {
			return $this->result( 'pass', 'Advanced Themer is not active on this site.', 'plugin list checked' );
		}
		return $this->result( 'fail', 'Advanced Themer is still active: ' . implode( ', ', $active ) . '. Deactivate it before delivery.', 'plugin list checked' );
	}

	private function check_external_link_targets() {
		$site_host = strtolower( (string) wp_parse_url( home_url(), PHP_URL_HOST ) );
		$offenders = array();
		$checked   = 0;
		foreach ( $this->page_bodies() as $url => $body ) {
			$checked++;
			if ( ! preg_match_all( '/<a\b[^>]*>/i', $body, $tags ) ) {
				continue;
			}
			foreach ( $tags[0] as $tag ) {
				if ( ! preg_match( '/href=["\']([^"\']+)["\']/i', $tag, $href ) ) {
					continue;
				}
				$target_url = $href[1];
				if ( ! preg_match( '#^https?://#i', $target_url ) ) {
					continue; // Relative, mailto:, tel: and anchors are internal by definition.
				}
				$host = strtolower( (string) wp_parse_url( $target_url, PHP_URL_HOST ) );
				if ( '' === $host || $host === $site_host || 'www.' . $site_host === $host || $site_host === 'www.' . $host ) {
					continue;
				}
				if ( ! preg_match( '/target=["\']_blank["\']/i', $tag ) ) {
					$offenders[] = $target_url . ' (on ' . $url . ')';
				}
			}
		}
		if ( ! $checked ) {
			return $this->result( 'skipped', 'No pages could be fetched to check link targets.', '' );
		}
		$offenders = array_values( array_unique( $offenders ) );
		if ( ! $offenders ) {
			return $this->result( 'pass', 'Every external link on the sampled pages opens in a new tab.', $checked . ' pages checked' );
		}
		return $this->result( 'fail', count( $offenders ) . ' external link(s) open in the same tab: ' . $this->short_list( $offenders ) . '.', $checked . ' pages checked' );
	}

	private function check_404_hebrew() {
		$url      = home_url( '/nexxen-checklist-missing-' . wp_generate_password( 8, false, false ) . '/' );
		$response = $this->fetch( $url );
		if ( 0 === $response['code'] ) {
			return $this->result( 'skipped', 'Could not reach the site to test the 404 page.', $url );
		}
		if ( 404 !== $response['code'] ) {
			return $this->result( 'fail', 'A nonsense URL returned HTTP ' . $response['code'] . ' instead of 404.', $url );
		}
		// Strip scripts/styles so we judge the visible copy, not code.
		$text = preg_replace( '#<(script|style)\b[^>]*>.*?</\1>#is', ' ', $response['body'] );
		$text = wp_strip_all_tags( (string) $text );
		if ( $this->has_hebrew( $text ) ) {
			return $this->result( 'pass', 'The 404 page returns HTTP 404 and its copy is in Hebrew. Confirm visually that it uses the site design.', $url );
		}
		return $this->result( 'fail', 'The 404 page returns HTTP 404 but contains no Hebrew text — it is probably still the default English template.', $url );
	}

	private function check_copyright_line() {
		$home = $this->fetch( home_url( '/' ) );
		if ( 200 !== $home['code'] ) {
			return $this->result( 'skipped', 'Homepage did not return 200.', home_url( '/' ) );
		}
		$has_link   = (bool) preg_match( '#1000shekel\.com#i', $home['body'] );
		$has_credit = (bool) preg_match( '/קבוצת\s*נועדים/u', $home['body'] );
		$evidence   = 'link=' . ( $has_link ? 'found' : 'missing' ) . '; credit=' . ( $has_credit ? 'found' : 'missing' );

		if ( $has_link && $has_credit ) {
			return $this->result( 'pass', 'Footer credit line and the 1000shekel.com link are both present.', $evidence );
		}
		if ( ! $has_link && ! $has_credit ) {
			return $this->result( 'fail', 'The agreed footer copyright line is missing entirely.', $evidence );
		}
		return $this->result( 'fail', 'The footer copyright line is incomplete — ' . ( $has_link ? 'the Hebrew credit text' : 'the בניית אתר link to 1000shekel.com' ) . ' is missing.', $evidence );
	}

	private function check_cpt_hebrew_labels() {
		$types = get_post_types( array( 'public' => true, '_builtin' => false ), 'objects' );
		if ( ! $types ) {
			return $this->result( 'skipped', 'No custom post types are registered on this site.', '0 CPTs' );
		}
		$english = array();
		foreach ( $types as $type ) {
			$label = isset( $type->labels->name ) ? $type->labels->name : $type->label;
			if ( ! $this->has_hebrew( $label ) ) {
				$english[] = $label . ' (' . $type->name . ')';
			}
		}
		if ( ! $english ) {
			return $this->result( 'pass', 'All ' . count( $types ) . ' custom post types carry Hebrew labels.', count( $types ) . ' CPTs checked' );
		}
		return $this->result( 'fail', count( $english ) . ' custom post type(s) still have non-Hebrew labels: ' . $this->short_list( $english ) . '.', count( $types ) . ' CPTs checked' );
	}

	private function check_accessibility_statement() {
		$found = $this->find_pages( '/(הצהרת\s*נגישות|accessibility)/ui' );
		if ( ! $found ) {
			return $this->result( 'fail', 'No accessibility statement page (הצהרת נגישות) is published.', 'page titles scanned' );
		}
		$id      = (int) array_key_first( $found );
		$content = wp_strip_all_tags( (string) get_post_field( 'post_content', $id ) );
		$title   = $found[ $id ];
		if ( strlen( $content ) < 400 ) {
			return $this->result( 'fail', 'The accessibility statement page "' . $title . '" exists but its content is very short — it looks like a placeholder rather than the full statement.', get_permalink( $id ) );
		}
		if ( preg_match( '/\{[a-z_\-]+\}/i', $content ) ) {
			return $this->result( 'fail', 'The accessibility statement still contains unresolved placeholder tokens (for example {je_sitewide-details_email}). Fill in the real coordinator details.', get_permalink( $id ) );
		}
		return $this->result( 'pass', 'Accessibility statement "' . $title . '" is published with full content and no unresolved placeholders.', get_permalink( $id ) );
	}

	private function check_privacy_policy_page() {
		$found = $this->find_pages( '/(מדיניות\s*פרטיות|privacy)/ui' );
		if ( ! $found ) {
			return $this->result( 'fail', 'No privacy policy page (מדיניות פרטיות) is published.', 'page titles scanned' );
		}
		$id      = (int) array_key_first( $found );
		$content = wp_strip_all_tags( (string) get_post_field( 'post_content', $id ) );
		if ( strlen( $content ) < 400 ) {
			return $this->result( 'fail', 'The privacy policy page "' . $found[ $id ] . '" exists but has almost no content.', get_permalink( $id ) );
		}
		return $this->result( 'pass', 'Privacy policy "' . $found[ $id ] . '" is published with real content. Confirm it reflects Amendment 13 and ends with the client contact details.', get_permalink( $id ) );
	}

	private function check_terms_page() {
		$found = $this->find_pages( '/(תקנון|תנאי\s*שימוש|terms|conditions)/ui' );
		if ( ! $found ) {
			return $this->result( 'fail', 'No site terms page (תקנון האתר / תנאי שימוש) is published.', 'page titles scanned' );
		}
		$id      = (int) array_key_first( $found );
		$content = wp_strip_all_tags( (string) get_post_field( 'post_content', $id ) );
		if ( strlen( $content ) < 400 ) {
			return $this->result( 'fail', 'The terms page "' . $found[ $id ] . '" exists but has almost no content.', get_permalink( $id ) );
		}
		if ( preg_match( '/\[add website name\]|\[שם האתר\]/ui', $content ) ) {
			return $this->result( 'fail', 'The terms page still contains the bracketed site-name placeholder. Replace it with the real site name.', get_permalink( $id ) );
		}
		return $this->result( 'pass', 'Site terms "' . $found[ $id ] . '" are published with real content and no placeholder site name.', get_permalink( $id ) );
	}

	private function check_footer_legal_links() {
		$home = $this->fetch( home_url( '/' ) );
		if ( 200 !== $home['code'] ) {
			return $this->result( 'skipped', 'Homepage did not return 200.', home_url( '/' ) );
		}
		$targets = array(
			'accessibility statement' => '/(הצהרת\s*נגישות|accessibility)/ui',
			'privacy policy'          => '/(מדיניות\s*פרטיות|privacy)/ui',
			'site terms'              => '/(תקנון|תנאי\s*שימוש|terms)/ui',
		);
		$missing = array();
		foreach ( $targets as $label => $pattern ) {
			$pages = $this->find_pages( $pattern );
			if ( ! $pages ) {
				$missing[] = $label . ' (page not published)';
				continue;
			}
			$linked = false;
			foreach ( $pages as $id => $title ) {
				$path = wp_parse_url( get_permalink( $id ), PHP_URL_PATH );
				if ( $path && false !== strpos( rawurldecode( $home['body'] ), rawurldecode( $path ) ) ) {
					$linked = true;
					break;
				}
			}
			if ( ! $linked ) {
				$missing[] = $label . ' (page exists but is not linked)';
			}
		}
		if ( ! $missing ) {
			return $this->result( 'pass', 'Accessibility statement, privacy policy and site terms are all linked from the homepage.', home_url( '/' ) );
		}
		return $this->result( 'fail', 'Not reachable from the homepage: ' . implode( '; ', $missing ) . '.', home_url( '/' ) );
	}

	private function check_shekel_position() {
		if ( ! function_exists( 'get_woocommerce_currency' ) ) {
			return $this->result( 'skipped', 'WooCommerce is not active, so currency position could not be checked.', 'no WooCommerce' );
		}
		$currency = get_woocommerce_currency();
		$position = get_option( 'woocommerce_currency_pos' );
		$evidence = 'currency=' . $currency . '; position=' . $position;
		if ( 'ILS' !== $currency ) {
			return $this->result( 'fail', 'Store currency is ' . $currency . ', not the shekel (ILS).', $evidence );
		}
		if ( 'left_space' === $position ) {
			return $this->result( 'pass', 'Prices render as ₪ followed by a space and the amount.', $evidence );
		}
		if ( 'left' === $position ) {
			return $this->result( 'fail', 'The shekel symbol is on the left but with no space before the amount. Set the currency position to "Left with space".', $evidence );
		}
		return $this->result( 'fail', 'The shekel symbol is positioned "' . $position . '" — it must be on the left of the amount, with a space.', $evidence );
	}
}
