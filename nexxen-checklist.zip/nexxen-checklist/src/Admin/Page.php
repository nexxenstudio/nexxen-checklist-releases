<?php
namespace Nexxen_Checklist\Admin;

defined( 'ABSPATH' ) || exit;

final class Page {

	const SLUG = 'nexxen-checklist';

	public function boot() {
		add_action( 'admin_menu', array( $this, 'register_menu' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'enqueue' ) );
	}

	public function register_menu() {
		$capability = apply_filters( 'nexxen_checklist_dashboard_capability', \Nexxen_Checklist\Installer::CHECK_CAP );
		add_menu_page(
			__( 'Nexxen Checklist', 'nexxen-checklist' ),
			__( 'Nexxen Checklist', 'nexxen-checklist' ),
			$capability,
			self::SLUG,
			array( $this, 'render' ),
			$this->menu_icon(),
			58
		);
	}

	private function menu_icon() {
		$svg = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="#a7aaad"><path d="M4 2h12a2 2 0 0 1 2 2v12a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2zm4.6 11.3L14 7.9l-1.4-1.4-4 4-1.9-1.9L5.3 10l3.3 3.3z"/></svg>';
		return 'data:image/svg+xml;base64,' . base64_encode( $svg );
	}

	public function enqueue( $hook ) {
		if ( 'toplevel_page_' . self::SLUG !== $hook ) {
			return;
		}

		/*
		 * WordPress rewrites emoji characters into <img> tags served from
		 * s.w.org. Where that host is blocked or slow, every emoji in the
		 * dashboard (including ones typed into a note) renders as a broken
		 * image. Our own UI uses no emoji, and on this screen the converter
		 * only creates that risk, so switch it off here.
		 */
		remove_action( 'admin_print_scripts', 'print_emoji_detection_script' );
		remove_action( 'admin_print_styles', 'print_emoji_styles' );

		wp_enqueue_style( 'nexxen-checklist-admin', NEXXEN_CHECKLIST_URL . 'assets/admin.css', array(), NEXXEN_CHECKLIST_VERSION );

		/*
		 * The dashboard is a React app built on the copy of React that
		 * WordPress already ships for the block editor (wp-element). No
		 * bundler, no npm install, and no second React downloaded by the
		 * browser. This screen is admin-only, so nothing here ever loads for
		 * site visitors.
		 */
		wp_enqueue_script(
			'nexxen-checklist-admin',
			NEXXEN_CHECKLIST_URL . 'assets/admin.js',
			array( 'wp-element' ),
			NEXXEN_CHECKLIST_VERSION,
			true
		);

		wp_localize_script(
			'nexxen-checklist-admin',
			'nexxenChecklist',
			array(
				'restUrl' => esc_url_raw( rest_url( 'nexxen-checklist/v1' ) ),
				'nonce'   => wp_create_nonce( 'wp_rest' ),
				'version' => NEXXEN_CHECKLIST_VERSION,
				'site'      => home_url(),
				'locale'    => get_locale(),
				'isRtl'     => is_rtl(),
				'canManage' => current_user_can( 'manage_options' ),
				'userName'  => wp_get_current_user()->display_name,
			)
		);
	}

	public function render() {
		echo '<div class="wrap nexxen-checklist-wrap"><div id="nexxen-checklist-app"><div class="nxnc-boot">Loading Nexxen Checklist…</div></div></div>';
	}
}
