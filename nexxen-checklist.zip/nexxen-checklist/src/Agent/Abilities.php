<?php
namespace Nexxen_Checklist\Agent;

use Nexxen_Checklist\Actions;

defined( 'ABSPATH' ) || exit;

/**
 * Registers Nexxen Checklist on the WordPress Abilities API so the Novamira MCP
 * adapter exposes every checklist operation as a tool. Mirrors the studio
 * registration pattern.
 */
final class Abilities {

	private $actions;

	public function __construct( $actions ) {
		$this->actions = $actions;
	}

	public function boot() {
		if ( ! class_exists( 'WP_Ability' ) || ! function_exists( 'wp_register_ability' ) ) {
			return;
		}
		add_action( 'wp_abilities_api_categories_init', array( $this, 'register_category' ) );
		add_action( 'wp_abilities_api_init', array( $this, 'register_abilities' ) );
	}

	public function register_category() {
		wp_register_ability_category(
			'nexxen-checklist',
			array(
				'label'       => __( 'Nexxen Checklist', 'nexxen-checklist' ),
				'description' => __( 'Launch checklists: create and manage QA checklists, run them item by item, record evidence and produce readiness reports.', 'nexxen-checklist' ),
			)
		);
	}

	public function register_abilities() {
		$actions = $this->actions();

		$item_schema = array(
			'type'                 => 'object',
			'additionalProperties' => false,
			'properties'           => array(
				'id'           => array( 'type' => 'string' ),
				'section'      => array( 'type' => 'string', 'description' => 'Section heading in English.' ),
				'section_he'   => array( 'type' => 'string', 'description' => 'Section heading in Hebrew.' ),
				'title'        => array( 'type' => 'string', 'description' => 'Item title in English.' ),
				'title_he'     => array( 'type' => 'string', 'description' => 'Item title in Hebrew, shown when the dashboard is in Hebrew.' ),
				'how_to_check' => array( 'type' => 'string' ),
				'severity'     => array( 'type' => 'string', 'enum' => array( 'blocker', 'major', 'minor' ) ),
				'check_type'   => array( 'type' => 'string', 'enum' => array( 'agent', 'browser', 'manual' ) ),
				'tags'         => array( 'type' => 'array', 'items' => array( 'type' => 'string' ) ),
				'enabled'      => array( 'type' => 'boolean' ),
			),
			'required'             => array( 'title' ),
		);
		$checklist_ref = array( 'checklist' => array( 'type' => array( 'string', 'integer' ), 'description' => 'Checklist slug or numeric id.' ) );
		$run_ref       = array( 'run_id' => array( 'type' => 'string', 'minLength' => 4 ) );

		$this->register( 'get-operator-prompt', 'Get Operator Prompt', 'Returns the recommended agent workflow for running a Nexxen Checklist QA session on this site, plus the available checklists.', null, array( $actions, 'get_operator_prompt' ), true, false, true );
		$this->register( 'get-overview', 'Get Checklist Overview', 'Returns checklist count, recent runs with progress, and the last completed run summary for this site.', null, array( $actions, 'get_overview' ), true, false, true );
		$this->register( 'list-checklists', 'List Checklists', 'Lists all QA checklists (built-in and custom) with category and item counts.', $this->object_schema( array( 'category' => array( 'type' => 'string' ) ) ), array( $actions, 'list_checklists' ), true, false, true );
		$this->register( 'get-checklist', 'Get Checklist', 'Returns one checklist with every item: section, title, how-to-check instructions, severity and check type.', $this->object_schema( $checklist_ref, array( 'checklist' ) ), array( $actions, 'get_checklist' ), true, false, true );
		$this->register(
			'create-checklist',
			'Create Checklist',
			'Creates a new custom checklist. Items need a title; section, how_to_check, severity (blocker|major|minor) and check_type (agent|browser|manual) are recommended.',
			$this->object_schema(
				array(
					'name'        => array( 'type' => 'string' ),
					'name_he'     => array( 'type' => 'string', 'description' => 'Checklist name in Hebrew.' ),
					'slug'        => array( 'type' => 'string' ),
					'description' => array( 'type' => 'string' ),
					'category'    => array( 'type' => 'string' ),
					'items'       => array( 'type' => 'array', 'items' => $item_schema ),
				),
				array( 'name' )
			),
			array( $actions, 'create_checklist' ),
			false,
			false,
			false
		);
		$this->register(
			'update-checklist',
			'Update Checklist',
			'Updates a checklist: rename, re-describe, replace items, append add_items, patch one update_item by id, or delete remove_item_ids.',
			$this->object_schema(
				array_merge(
					$checklist_ref,
					array(
						'name'            => array( 'type' => 'string' ),
						'name_he'         => array( 'type' => 'string' ),
						'description'     => array( 'type' => 'string' ),
						'category'        => array( 'type' => 'string' ),
						'items'           => array( 'type' => 'array', 'items' => $item_schema ),
						'add_items'       => array( 'type' => 'array', 'items' => $item_schema ),
						'update_item'     => $item_schema,
						'remove_item_ids' => array( 'type' => 'array', 'items' => array( 'type' => 'string' ) ),
					)
				),
				array( 'checklist' )
			),
			array( $actions, 'update_checklist' ),
			false,
			false,
			false
		);
		$this->register( 'delete-checklist', 'Delete Checklist', 'Deletes a checklist. Built-in Nexxen Studio checklists additionally require confirm_builtin=true and can be restored with restore-builtin-checklists.', $this->object_schema( array_merge( $checklist_ref, array( 'confirm_builtin' => array( 'type' => 'boolean' ) ) ), array( 'checklist' ) ), array( $actions, 'delete_checklist' ), false, true, false );
		$this->register( 'restore-builtin-checklists', 'Restore Built-in Checklists', 'Re-seeds the built-in Nexxen Studio checklist library (mockup prep, initial build, final delivery, e-commerce, legal pages, front-end QA, plugins/backend, go-live, SEO, accessibility) without touching custom checklists.', null, array( $actions, 'restore_builtin_checklists' ), false, false, true );

		$this->register( 'start-run', 'Start Checklist Run', 'Starts a new run of a checklist and returns the run_id with all items pending. Follow with get-next-items.', $this->object_schema( array_merge( $checklist_ref, array( 'label' => array( 'type' => 'string' ) ) ), array( 'checklist' ) ), array( $actions, 'start_run' ), false, false, false );
		$this->register( 'list-runs', 'List Runs', 'Lists recent checklist runs with status and progress.', $this->object_schema( array( 'limit' => array( 'type' => 'integer', 'minimum' => 1, 'maximum' => 100 ) ) ), array( $actions, 'list_runs' ), true, false, true );
		$this->register( 'get-run', 'Get Run', 'Returns one run with per-item results, titles, severities and progress.', $this->object_schema( $run_ref, array( 'run_id' ) ), array( $actions, 'get_run' ), true, false, true );
		$this->register( 'get-next-items', 'Get Next Items', 'Returns the next pending items of a run with their full how-to-check instructions. Loop this ability, verifying and recording each batch, until it reports run-complete.', $this->object_schema( array_merge( $run_ref, array( 'limit' => array( 'type' => 'integer', 'minimum' => 1, 'maximum' => 20 ) ) ), array( 'run_id' ) ), array( $actions, 'get_next_items' ), true, false, true );
		$this->register(
			'record-item-result',
			'Record Item Result',
			'Records one result (item_id + status) or a results[] batch. Status: pass, fail, na, skipped. Always include notes and evidence describing what was actually checked.',
			$this->object_schema(
				array_merge(
					$run_ref,
					array(
						'item_id'    => array( 'type' => 'string' ),
						'status'     => array( 'type' => 'string', 'enum' => array( 'pass', 'fail', 'na', 'skipped', 'pending' ) ),
						'notes'      => array( 'type' => 'string' ),
						'evidence'   => array( 'type' => 'string' ),
						'assignee'   => array( 'type' => 'string', 'description' => 'Person responsible for this item.' ),
						'checked_by' => array( 'type' => 'string' ),
						'results'    => array(
							'type'  => 'array',
							'items' => array(
								'type'                 => 'object',
								'additionalProperties' => false,
								'properties'           => array(
									'item_id'  => array( 'type' => 'string' ),
									'status'   => array( 'type' => 'string', 'enum' => array( 'pass', 'fail', 'na', 'skipped', 'pending' ) ),
									'notes'    => array( 'type' => 'string' ),
									'evidence' => array( 'type' => 'string' ),
								),
								'required'             => array( 'item_id', 'status' ),
							),
						),
					)
				),
				array( 'run_id' )
			),
			array( $actions, 'record_item_result' ),
			false,
			false,
			true
		);
		$this->register( 'run-auto-checks', 'Run Automatic Checks', 'Runs the deterministic PHP engine against all pending auto-checkable items of a run (settings, HTTP status, SSL redirect, sitemap/robots, staging URLs, meta tags, placeholder content and more) and records results with evidence. Call this right after start-run; then handle the remaining items yourself.', $this->object_schema( $run_ref, array( 'run_id' ) ), array( $actions, 'run_auto_checks' ), false, false, true );
		$this->register( 'run-drift-scan', 'Run Drift Scan', 'Runs the live-site safety subset of automatic checks (indexing, SSL, debug output, robots, sitemap, caching, 404) without a checklist run and stores the report. Also runs weekly via cron.', null, array( $actions, 'run_drift_scan' ), false, false, true );
		$this->register( 'get-drift-report', 'Get Drift Report', 'Returns the most recent drift-scan report with any failures on live-site safety checks.', null, array( $actions, 'get_drift_report' ), true, false, true );
		$this->register( 'complete-run', 'Complete Run', 'Completes a run: computes counts, weighted readiness score and verdict (ready | review | not-ready). Refuses while items are pending unless force=true.', $this->object_schema( array_merge( $run_ref, array( 'force' => array( 'type' => 'boolean' ) ) ), array( 'run_id' ) ), array( $actions, 'complete_run' ), false, false, true );
		$this->register( 'delete-run', 'Delete Run', 'Deletes one run and its recorded results.', $this->object_schema( $run_ref, array( 'run_id' ) ), array( $actions, 'delete_run' ), false, true, false );
		$this->register( 'get-run-report', 'Get Run Report', 'Returns the full report for a run: summary, readiness score, failures ranked by severity, and a copy-ready Markdown report.', $this->object_schema( $run_ref, array( 'run_id' ) ), array( $actions, 'get_run_report' ), true, false, true );
	}

	private function actions() {
		if ( is_callable( $this->actions ) ) {
			$this->actions = call_user_func( $this->actions );
		}
		return $this->actions;
	}

	private function register( $slug, $label, $description, $input_schema, $callback, $readonly, $destructive, $idempotent ) {
		$args = array(
			'label'               => $label,
			'description'         => $description,
			'category'            => 'nexxen-checklist',
			'output_schema'       => $this->output_schema(),
			'execute_callback'    => static function ( $input = null ) use ( $callback ) {
				return call_user_func( $callback, is_array( $input ) ? $input : array() );
			},
			'permission_callback' => static function () {
				$capability = apply_filters( 'nexxen_checklist_ability_capability', 'manage_options' );
				return current_user_can( $capability );
			},
			'meta'                => array(
				'show_in_rest'   => true,
				'plugin_version' => NEXXEN_CHECKLIST_VERSION,
				'mcp'            => array(
					'public' => (bool) apply_filters( 'nexxen_checklist_ability_mcp_public', true, $slug ),
					'type'   => 'tool',
				),
				'annotations'    => array(
					'readonly'     => (bool) $readonly,
					'destructive'  => (bool) $destructive,
					'idempotent'   => (bool) $idempotent,
					'instructions' => 'Start with get-operator-prompt. Verify every item honestly following its how_to_check text before recording a status, and always attach notes and evidence.',
				),
			),
		);
		if ( null !== $input_schema ) {
			$args['input_schema'] = $input_schema;
		} else {
			$args['input_schema'] = array( 'type' => array( 'object', 'null' ) );
		}
		wp_register_ability( 'nexxen-checklist/' . $slug, $args );
	}

	private function output_schema() {
		return array(
			'type'                 => 'object',
			'additionalProperties' => true,
			'properties'           => array(
				'success'  => array( 'type' => 'boolean' ),
				'status'   => array( 'type' => 'string' ),
				'data'     => array( 'type' => 'object', 'additionalProperties' => true ),
				'warnings' => array( 'type' => 'array', 'items' => array( 'type' => 'string' ) ),
			),
			'required'             => array( 'success', 'status', 'data' ),
		);
	}

	private function object_schema( array $properties, array $required = array() ) {
		$schema = array(
			'type'                 => 'object',
			'additionalProperties' => false,
			'properties'           => $properties,
		);
		if ( $required ) {
			$schema['required'] = $required;
		}
		return $schema;
	}
}
