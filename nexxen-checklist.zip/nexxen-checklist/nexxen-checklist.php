<?php
/**
 * Plugin Name: Nexxen Checklist
 * Plugin URI: https://nexxenstudio.com/
 * Description: Bilingual (Hebrew/English) launch checklists for Nexxen Studio sites. RTL-aware QA checklists — mockup prep, initial build, final delivery, e-commerce, legal pages, plus general front-end, backend, go-live, SEO and accessibility passes — with a React dashboard, run history, readiness scoring, a deterministic auto-check engine and full MCP/Abilities automation.
 * Version: 1.2.1
 * Requires at least: 6.5
 * Requires PHP: 7.4
 * Author: Nexxen Studio
 * Author URI: https://nexxenstudio.com/
 * License: GPL-2.0-or-later
 * Text Domain: nexxen-checklist
 * Domain Path: /languages
 */

defined( 'ABSPATH' ) || exit;

define( 'NEXXEN_CHECKLIST_VERSION', '1.2.1' );
define( 'NEXXEN_CHECKLIST_FILE', __FILE__ );
define( 'NEXXEN_CHECKLIST_PATH', plugin_dir_path( __FILE__ ) );
define( 'NEXXEN_CHECKLIST_URL', plugin_dir_url( __FILE__ ) );

require_once NEXXEN_CHECKLIST_PATH . 'src/Autoload.php';

register_activation_hook( __FILE__, array( 'Nexxen_Checklist\\Installer', 'activate' ) );
register_deactivation_hook( __FILE__, array( 'Nexxen_Checklist\\Installer', 'deactivate' ) );

add_action(
	'plugins_loaded',
	static function () {
		Nexxen_Checklist\Plugin::instance()->boot();
	},
	5
);
