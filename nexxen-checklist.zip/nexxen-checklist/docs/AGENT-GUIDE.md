# Nexxen Checklist — agent guide (Novamira / Claude via MCP)

Nexxen Checklist registers its tools on the WordPress Abilities API, so any site
running the Novamira MCP adapter exposes them automatically under the
`nexxen-checklist/*` namespace (discover with the adapter's discover-abilities
tool, filter by category `nexxen-checklist`).

## Standard QA session

1. `nexxen-checklist/get-operator-prompt` — returns the workflow plus the current
   checklist inventory for this site.
2. `nexxen-checklist/list-checklists` → pick one. The Nexxen process checklists
   are `nexxen-mockup-content`, `nexxen-initial-build`, `nexxen-final-delivery`,
   `nexxen-ecommerce` and `nexxen-legal-accessibility`; the general ones are
   `frontend-design-qa`, `plugins-backend-qa`, `go-live-launch`,
   `seo-content-qa` and `accessibility-basics`.
3. `nexxen-checklist/start-run` with `{ "checklist": "go-live-launch", "label": "Pre-launch 2026-08-11" }`.
3b. `nexxen-checklist/run-auto-checks` with the run_id — the plugin's own
   deterministic PHP engine settles the mechanical items (settings, SSL,
   sitemap/robots, staging URLs, meta tags, placeholder content…) and records
   evidence. Inconclusive checks are marked skipped, never guessed. You only
   handle what remains.
4. Loop until done:
   - `nexxen-checklist/get-next-items` with `{ "run_id": "...", "limit": 5 }` —
     each item includes `how_to_check` instructions.
   - Actually verify each item (HTTP fetches, browser checks, other site MCP
     abilities). Never mark pass without checking.
   - `nexxen-checklist/record-item-result` — single item or a `results[]` batch.
     Status: `pass | fail | na | skipped`. Always fill `notes` and `evidence`
     (URLs checked, values observed).
5. `nexxen-checklist/complete-run` — computes the weighted readiness score and
   verdict. Any blocker-severity failure forces `not-ready`.
6. `nexxen-checklist/get-run-report` — Markdown report, blockers first.

## Managing checklists

- `create-checklist` — new custom checklist; items need `title`, ideally also
  `section`, `how_to_check`, `severity` (blocker|major|minor), `check_type`
  (agent|browser|manual).

## Language

Checklist content is bilingual. `title`/`section` are English; `title_he` and
`section_he` carry the Hebrew shown when the dashboard is switched to Hebrew,
and `name_he` does the same for the checklist itself. When you create or edit
items for a Hebrew site, fill in both — an item with no Hebrew title falls back
to English in the Hebrew interface, which the client will notice.

`how_to_check` is always written in English: it is instructions for you, not
client-facing copy. Report results to the client in the language they are
working in.
- `update-checklist` — supports `add_items[]`, `update_item` (patch by id),
  `remove_item_ids[]`, or full `items[]` replace.
- `restore-builtin-checklists` — re-seeds the Nexxen Studio library; custom
  checklists and operator customisations (disabled items, edited severities)
  are preserved.

## Scoring model

pass/na earn full weight; weights are blocker=5, major=3, minor=1. `na` items
are excluded from the denominator. Verdict: `not-ready` if any blocker failed,
`ready` only when everything passed, otherwise `review`.
